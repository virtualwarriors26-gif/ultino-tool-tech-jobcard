import { Customer, Item, Job, BackupData } from '../types';

const DB_NAME = 'UltinoToolTechDB';
const DB_VERSION = 1;

// Stores: customers, items, jobs, meta
function openDB(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (typeof window === 'undefined' || !window.indexedDB) {
      reject(new Error('IndexedDB is not supported in this environment.'));
      return;
    }

    const request = window.indexedDB.open(DB_NAME, DB_VERSION);

    request.onupgradeneeded = (event) => {
      const db = (event.target as IDBOpenDBRequest).result;
      if (!db.objectStoreNames.contains('customers')) {
        db.createObjectStore('customers', { keyPath: 'id' });
      }
      if (!db.objectStoreNames.contains('items')) {
        db.createObjectStore('items', { keyPath: 'id' });
      }
      if (!db.objectStoreNames.contains('jobs')) {
        const jobStore = db.createObjectStore('jobs', { keyPath: 'id' });
        jobStore.createIndex('date', 'date', { unique: false });
        jobStore.createIndex('customerId', 'customerId', { unique: false });
        jobStore.createIndex('productionStatus', 'productionStatus', { unique: false });
        jobStore.createIndex('serialNumberIndex', 'serialNumberIndex', { unique: true });
      }
      if (!db.objectStoreNames.contains('meta')) {
        db.createObjectStore('meta', { keyPath: 'key' });
      }
    };

    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

async function getAllFromStore<T>(storeName: string): Promise<T[]> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(storeName, 'readonly');
    const store = tx.objectStore(storeName);
    const req = store.getAll();
    req.onsuccess = () => resolve((req.result as T[]) || []);
    req.onerror = () => reject(req.error);
  });
}

async function putToStore<T>(storeName: string, item: T): Promise<void> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(storeName, 'readwrite');
    const store = tx.objectStore(storeName);
    const req = store.put(item);
    req.onsuccess = () => resolve();
    req.onerror = () => reject(req.error);
  });
}

async function deleteFromStore(storeName: string, key: string): Promise<void> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(storeName, 'readwrite');
    const store = tx.objectStore(storeName);
    const req = store.delete(key);
    req.onsuccess = () => resolve();
    req.onerror = () => reject(req.error);
  });
}

async function clearStore(storeName: string): Promise<void> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(storeName, 'readwrite');
    const store = tx.objectStore(storeName);
    const req = store.clear();
    req.onsuccess = () => resolve();
    req.onerror = () => reject(req.error);
  });
}

// Format serial number as "JOB 001", "JOB 002"
export function formatJobNumber(serial: number): string {
  const padded = String(serial).padStart(3, '0');
  return `JOB ${padded}`;
}

// Calculate duration string from ISO timestamps
export function calculateDuration(startTimeIso?: string, endTimeIso?: string): { minutes: number; formatted: string } {
  if (!startTimeIso || !endTimeIso) {
    return { minutes: 0, formatted: '' };
  }
  const start = new Date(startTimeIso).getTime();
  const end = new Date(endTimeIso).getTime();
  if (isNaN(start) || isNaN(end) || end < start) {
    return { minutes: 0, formatted: '' };
  }

  const diffMs = end - start;
  const totalMinutes = Math.floor(diffMs / (1000 * 60));
  const hours = Math.floor(totalMinutes / 60);
  const minutes = totalMinutes % 60;

  let formatted = '';
  if (hours > 0) {
    formatted = `${hours} hr ${minutes} min`;
  } else {
    formatted = `${minutes} min`;
  }

  return { minutes: totalMinutes, formatted };
}

// Calculate live elapsed time string from start time to now
export function calculateLiveElapsed(startTimeIso?: string): string {
  if (!startTimeIso) return '';
  const start = new Date(startTimeIso).getTime();
  const now = Date.now();
  if (isNaN(start) || now < start) return '0 min';

  const diffMs = now - start;
  const totalMinutes = Math.floor(diffMs / (1000 * 60));
  const hours = Math.floor(totalMinutes / 60);
  const minutes = totalMinutes % 60;

  if (hours > 0) {
    return `${hours} hr ${minutes} min`;
  }
  return `${minutes} min`;
}

// Initial Sample Data for ULTINO TOOL TECH wire-cut toolroom
const INITIAL_CUSTOMERS: Customer[] = [
  {
    id: 'cust-abc-eng',
    name: 'ABC Engineering',
    phone: '+91 98450 12345',
    contactPerson: 'Mr. Rajesh Kumar',
    email: 'purchase@abceng.com',
    address: 'Plot 42, Peenya Industrial Area, Phase 2',
    notes: 'Regular wire-cut jobs for stamping die components and punches.',
    createdAt: new Date(Date.now() - 30 * 86400000).toISOString(),
    updatedAt: new Date(Date.now() - 30 * 86400000).toISOString(),
  },
  {
    id: 'cust-apex-tools',
    name: 'Apex Precision Tools',
    phone: '+91 94480 67890',
    contactPerson: 'Suresh Patil',
    email: 'quality@apextools.in',
    address: 'Bommasandra Industrial Area, Shed 18',
    notes: 'Requires 4-cut surface finish with 0.25mm Brass wire.',
    createdAt: new Date(Date.now() - 20 * 86400000).toISOString(),
    updatedAt: new Date(Date.now() - 20 * 86400000).toISOString(),
  },
  {
    id: 'cust-metro-dies',
    name: 'Metro Tool & Die Makers',
    phone: '+91 98860 11223',
    contactPerson: 'Anand Rao',
    email: 'info@metrodies.com',
    address: 'Whitefield Tech Park Road, Bengaluru',
    notes: 'D2 / HCHCR hardened material cutting (58-62 HRC).',
    createdAt: new Date(Date.now() - 15 * 86400000).toISOString(),
    updatedAt: new Date(Date.now() - 15 * 86400000).toISOString(),
  },
];

const INITIAL_ITEMS: Item[] = [
  {
    id: 'item-die-plate',
    name: 'Die Plate',
    customerId: 'cust-abc-eng',
    customerName: 'ABC Engineering',
    productionStatus: 'Completed',
    description: '12-cavity progressive punch die plate, D2 steel hardened',
    defaultPathLength: '640 mm',
    defaultThickness: '32 mm',
    createdAt: new Date(Date.now() - 25 * 86400000).toISOString(),
    updatedAt: new Date(Date.now() - 25 * 86400000).toISOString(),
  },
  {
    id: 'item-punch-insert',
    name: 'Punch Insert (Forming)',
    customerId: 'cust-abc-eng',
    customerName: 'ABC Engineering',
    productionStatus: 'Production',
    description: 'Precision contour wire EDM punch with 0.005mm tolerance',
    defaultPathLength: '185 mm',
    defaultThickness: '40 mm',
    createdAt: new Date(Date.now() - 20 * 86400000).toISOString(),
    updatedAt: new Date(Date.now() - 20 * 86400000).toISOString(),
  },
  {
    id: 'item-stripper-plate',
    name: 'Stripper Plate',
    customerId: 'cust-apex-tools',
    customerName: 'Apex Precision Tools',
    productionStatus: 'Pending',
    description: 'Guide stripper plate with 8 guide holes and window cut',
    defaultPathLength: '420 mm',
    defaultThickness: '20 mm',
    createdAt: new Date(Date.now() - 10 * 86400000).toISOString(),
    updatedAt: new Date(Date.now() - 10 * 86400000).toISOString(),
  },
  {
    id: 'item-core-pin',
    name: 'Core Pin Ejector Bush',
    customerId: 'cust-metro-dies',
    customerName: 'Metro Tool & Die Makers',
    productionStatus: 'Completed',
    description: 'Taper cut wire EDM (0.5 degree per side draft)',
    defaultPathLength: '120 mm',
    defaultThickness: '50 mm',
    createdAt: new Date(Date.now() - 8 * 86400000).toISOString(),
    updatedAt: new Date(Date.now() - 8 * 86400000).toISOString(),
  }
];

// Sample technical drawing SVG as data URL for sample jobs
const SAMPLE_DRAWING_SVG = `data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="600" height="400" viewBox="0 0 600 400" style="background:%230b1329;font-family:sans-serif">
  <rect x="20" y="20" width="560" height="360" fill="none" stroke="%2338bdf8" stroke-width="1.5" stroke-dasharray="4,4"/>
  <rect x="70" y="70" width="460" height="260" fill="%230f2347" stroke="%2338bdf8" stroke-width="2"/>
  <circle cx="150" cy="150" r="35" fill="%230b1329" stroke="%2338bdf8" stroke-width="2"/>
  <circle cx="450" cy="150" r="35" fill="%230b1329" stroke="%2338bdf8" stroke-width="2"/>
  <rect x="230" y="110" width="140" height="180" rx="8" fill="%230b1329" stroke="%23f59e0b" stroke-width="2"/>
  <line x1="230" y1="200" x2="370" y2="200" stroke="%23f59e0b" stroke-width="1" stroke-dasharray="2,2"/>
  <text x="300" y="55" fill="%2393c5fd" font-size="14" font-weight="bold" text-anchor="middle">ULTINO TOOL TECH - WIRE CUT CAD PROFILE</text>
  <text x="300" y="195" fill="%23f59e0b" font-size="12" font-weight="bold" text-anchor="middle">DIE CAVITY</text>
  <text x="150" y="155" fill="%2338bdf8" font-size="11" text-anchor="middle">Ø 70 mm</text>
  <text x="450" y="155" fill="%2338bdf8" font-size="11" text-anchor="middle">Ø 70 mm</text>
  <text x="300" y="360" fill="%2394a3b8" font-size="11" text-anchor="middle">ALL DIMENSIONS IN MM | TOL: ±0.005 | WIRE DIA: 0.25mm</text>
</svg>`;

const TODAY_DATE = new Date().toISOString().split('T')[0];

const INITIAL_JOBS: Job[] = [
  {
    id: 'job-001',
    jobNumber: 'JOB 001',
    serialNumberIndex: 1,
    date: TODAY_DATE,
    customerId: 'cust-abc-eng',
    customerName: 'ABC Engineering',
    itemId: 'item-die-plate',
    itemName: 'Die Plate',
    description: '12-cavity progressive punch die plate, D2 hardened',
    pathLength: '640 mm',
    thickness: '32 mm',
    quantity: 4,
    remarks: 'Finish cut required. Ra 0.4 µm. Material supplied by customer.',
    drawing: {
      dataUrl: SAMPLE_DRAWING_SVG,
      fileName: 'die_plate_dwg_rev2.svg',
      fileType: 'image/svg+xml',
      uploadedAt: new Date(Date.now() - 86400000).toISOString(),
    },
    productionStatus: 'Completed',
    startTime: new Date(new Date().setHours(8, 30, 0, 0) - 86400000).toISOString(),
    endTime: new Date(new Date().setHours(12, 55, 0, 0) - 86400000).toISOString(),
    totalTimeMinutes: 265,
    totalTimeFormatted: '4 hr 25 min',
    createdAt: new Date(Date.now() - 86400000).toISOString(),
    updatedAt: new Date(Date.now() - 86400000).toISOString(),
  },
  {
    id: 'job-002',
    jobNumber: 'JOB 002',
    serialNumberIndex: 2,
    date: TODAY_DATE,
    customerId: 'cust-abc-eng',
    customerName: 'ABC Engineering',
    itemId: 'item-punch-insert',
    itemName: 'Punch Insert (Forming)',
    description: 'Precision wire cut forming punch insert',
    pathLength: '185 mm',
    thickness: '40 mm',
    quantity: 2,
    remarks: '0.25mm Brass wire, 3-pass cut. Check core taper.',
    drawing: {
      dataUrl: SAMPLE_DRAWING_SVG,
      fileName: 'punch_cad_rev1.svg',
      fileType: 'image/svg+xml',
      uploadedAt: new Date().toISOString(),
    },
    productionStatus: 'Production',
    startTime: new Date(Date.now() - 75 * 60000).toISOString(), // started 1 hr 15 min ago
    endTime: undefined,
    totalTimeMinutes: 75,
    totalTimeFormatted: '1 hr 15 min',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'job-003',
    jobNumber: 'JOB 003',
    serialNumberIndex: 3,
    date: TODAY_DATE,
    customerId: 'cust-apex-tools',
    customerName: 'Apex Precision Tools',
    itemId: 'item-stripper-plate',
    itemName: 'Stripper Plate',
    description: 'Guide stripper plate with 8 guide holes and window cut',
    pathLength: '420 mm',
    thickness: '20 mm',
    quantity: 1,
    remarks: 'Machine after setting dial indicator alignment within 3 microns.',
    productionStatus: 'Pending',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  }
];

export class StorageService {
  private static isInitialized = false;

  public static async init(): Promise<void> {
    if (this.isInitialized) return;
    try {
      const customers = await getAllFromStore<Customer>('customers');
      if (customers.length === 0) {
        // First run seed
        for (const c of INITIAL_CUSTOMERS) {
          await putToStore('customers', c);
        }
        for (const item of INITIAL_ITEMS) {
          await putToStore('items', item);
        }
        for (const j of INITIAL_JOBS) {
          await putToStore('jobs', j);
        }
        await putToStore('meta', { key: 'nextJobSerial', value: 4 });
      }
      this.isInitialized = true;
    } catch (err) {
      console.warn('Storage initialization fallback:', err);
    }
  }

  // --- Customers ---
  public static async getCustomers(): Promise<Customer[]> {
    await this.init();
    const list = await getAllFromStore<Customer>('customers');
    return list.sort((a, b) => a.name.localeCompare(b.name));
  }

  public static async saveCustomer(customer: Customer): Promise<void> {
    await this.init();
    customer.updatedAt = new Date().toISOString();
    await putToStore('customers', customer);
  }

  public static async deleteCustomer(id: string): Promise<{ success: boolean; message?: string }> {
    await this.init();
    // Safety check: verify if customer has jobs
    const jobs = await this.getJobs();
    const hasJobs = jobs.some(j => j.customerId === id);
    if (hasJobs) {
      return {
        success: false,
        message: 'Cannot delete customer because historical job cards reference this customer. The records must remain intact for audit.'
      };
    }
    await deleteFromStore('customers', id);
    return { success: true };
  }

  // --- Items ---
  public static async getItems(): Promise<Item[]> {
    await this.init();
    const list = await getAllFromStore<Item>('items');
    return list.sort((a, b) => a.name.localeCompare(b.name));
  }

  public static async saveItem(item: Item): Promise<void> {
    await this.init();
    item.updatedAt = new Date().toISOString();
    await putToStore('items', item);
  }

  public static async deleteItem(id: string): Promise<{ success: boolean; message?: string }> {
    await this.init();
    // Safety check: verify if item has jobs
    const jobs = await this.getJobs();
    const hasJobs = jobs.some(j => j.itemId === id);
    if (hasJobs) {
      return {
        success: false,
        message: 'Cannot delete item because historical job cards are attached to it. Existing job records are permanently protected.'
      };
    }
    await deleteFromStore('items', id);
    return { success: true };
  }

  // --- Jobs ---
  public static async getJobs(): Promise<Job[]> {
    await this.init();
    const list = await getAllFromStore<Job>('jobs');
    // Sort descending by serial number index (newest first)
    return list.sort((a, b) => b.serialNumberIndex - a.serialNumberIndex);
  }

  public static async getJobById(id: string): Promise<Job | undefined> {
    await this.init();
    const list = await getAllFromStore<Job>('jobs');
    return list.find(j => j.id === id);
  }

  public static async getNextJobSerialNumber(): Promise<{ serialIndex: number; formatted: string }> {
    await this.init();
    const jobs = await getAllFromStore<Job>('jobs');
    let maxSerial = 0;
    for (const j of jobs) {
      if (j.serialNumberIndex && j.serialNumberIndex > maxSerial) {
        maxSerial = j.serialNumberIndex;
      }
    }
    const nextSerial = maxSerial + 1;
    return {
      serialIndex: nextSerial,
      formatted: formatJobNumber(nextSerial)
    };
  }

  public static async saveJob(job: Job): Promise<void> {
    await this.init();
    job.updatedAt = new Date().toISOString();
    await putToStore('jobs', job);

    // Update item status if appropriate
    if (job.itemId) {
      const items = await this.getItems();
      const item = items.find(i => i.id === job.itemId);
      if (item) {
        item.productionStatus = job.productionStatus;
        await putToStore('items', item);
      }
    }
  }

  public static async deleteJob(id: string): Promise<void> {
    await this.init();
    await deleteFromStore('jobs', id);
  }

  // --- Backup & Restore ---
  public static async exportBackup(): Promise<BackupData> {
    await this.init();
    const customers = await this.getCustomers();
    const items = await this.getItems();
    const jobs = await this.getJobs();
    const { serialIndex } = await this.getNextJobSerialNumber();

    return {
      version: '1.0.0',
      appName: 'ULTINO TOOL TECH - Job Card Management',
      exportedAt: new Date().toISOString(),
      customers,
      items,
      jobs,
      nextJobSerial: serialIndex,
    };
  }

  public static async restoreBackup(data: BackupData, mode: 'replace' | 'merge' = 'replace'): Promise<void> {
    await this.init();
    if (!data || !Array.isArray(data.jobs) || !Array.isArray(data.customers) || !Array.isArray(data.items)) {
      throw new Error('Invalid backup file format.');
    }

    if (mode === 'replace') {
      await clearStore('customers');
      await clearStore('items');
      await clearStore('jobs');
    }

    for (const c of data.customers) {
      await putToStore('customers', c);
    }
    for (const item of data.items) {
      await putToStore('items', item);
    }
    for (const j of data.jobs) {
      await putToStore('jobs', j);
    }
  }

  public static async resetToDefaultData(): Promise<void> {
    await clearStore('customers');
    await clearStore('items');
    await clearStore('jobs');
    this.isInitialized = false;
    await this.init();
  }
}
