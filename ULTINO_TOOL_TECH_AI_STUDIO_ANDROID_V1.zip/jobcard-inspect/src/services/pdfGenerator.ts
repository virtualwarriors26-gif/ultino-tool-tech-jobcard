import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import { Job } from '../types';

export interface MonthlySummary {
  monthName: string;
  year: number;
  totalJobs: number;
  totalQuantity: number;
  totalMinutes: number;
  completedJobs: number;
  inProductionJobs: number;
  pendingJobs: number;
}

export function formatTimeDisplay(isoString?: string): string {
  if (!isoString) return '-';
  try {
    const d = new Date(isoString);
    if (isNaN(d.getTime())) return '-';
    return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: true });
  } catch {
    return '-';
  }
}

export function formatDateDisplay(dateStr?: string): string {
  if (!dateStr) return '-';
  try {
    const parts = dateStr.split('-');
    if (parts.length === 3) {
      return `${parts[2]}-${parts[1]}-${parts[0]}`; // DD-MM-YYYY
    }
    return dateStr;
  } catch {
    return dateStr;
  }
}

export function generateMonthlyLedgerPdf(
  jobs: Job[],
  monthName: string,
  year: number,
  filterCustomerName?: string
): jsPDF {
  // A4 Landscape: 297mm x 210mm
  const doc = new jsPDF({
    orientation: 'landscape',
    unit: 'mm',
    format: 'a4',
  });

  // Industrial Styling Colors
  const primaryNavy = [15, 35, 71] as [number, number, number]; // #0f2347
  const accentAmber = [245, 158, 11] as [number, number, number]; // #f59e0b
  const slateText = [51, 65, 85] as [number, number, number]; // #334155

  // Header Banner - Formal White with Black and Gold Trim
  doc.setFillColor(255, 255, 255);
  doc.rect(0, 0, 297, 28, 'F');

  // Accent Line in Gold
  doc.setFillColor(217, 119, 6); // amber-600
  doc.rect(14, 27, 269, 1.2, 'F');

  // Header Title
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(18);
  doc.setTextColor(15, 23, 42); // deep slate/black
  doc.text('ULTINO TOOL TECH', 14, 13);

  doc.setFontSize(9.5);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(100, 116, 139);
  doc.text('PRECISION WIRE-CUT EDM & MANUFACTURING JOB LEDGER', 14, 20);

  // Month & Metadata right aligned
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(12);
  doc.setTextColor(180, 83, 9); // amber-700
  const monthText = `LEDGER: ${monthName.toUpperCase()} ${year}`;
  doc.text(monthText, 283, 13, { align: 'right' });

  doc.setFontSize(8.5);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(100, 116, 139);
  const filterText = filterCustomerName && filterCustomerName !== 'ALL'
    ? `Customer: ${filterCustomerName} | Date: ${new Date().toLocaleDateString()}`
    : `Total Jobs Listed: ${jobs.length} | Date: ${new Date().toLocaleDateString()}`;
  doc.text(filterText, 283, 20, { align: 'right' });

  // Compute Totals
  const totalQty = jobs.reduce((sum, j) => sum + (Number(j.quantity) || 0), 0);
  const totalMinutes = jobs.reduce((sum, j) => sum + (Number(j.totalTimeMinutes) || 0), 0);
  const totalHours = Math.floor(totalMinutes / 60);
  const remMinutes = totalMinutes % 60;
  const timeFormatted = totalHours > 0 ? `${totalHours} hr ${remMinutes} min` : `${remMinutes} min`;

  // Summary Metrics Bar
  doc.setFillColor(241, 245, 249);
  doc.roundedRect(14, 31, 269, 10, 1.5, 1.5, 'F');
  doc.setDrawColor(203, 213, 225);
  doc.roundedRect(14, 31, 269, 10, 1.5, 1.5, 'S');

  doc.setFontSize(9);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(slateText[0], slateText[1], slateText[2]);
  doc.text(`Total Records: ${jobs.length}`, 20, 37.5);
  doc.text(`Total Components Qty: ${totalQty} pcs`, 95, 37.5);
  doc.text(`Total Machining Time: ${timeFormatted}`, 180, 37.5);

  // Table Data Mapping
  const tableRows = jobs.map((job) => {
    return [
      job.jobNumber,
      formatDateDisplay(job.date),
      job.customerName || '-',
      job.itemName || '-',
      job.description || '-',
      job.pathLength || '-',
      job.thickness || '-',
      String(job.quantity || 1),
      job.productionStatus,
      formatTimeDisplay(job.startTime),
      formatTimeDisplay(job.endTime),
      job.totalTimeFormatted || '-',
      job.remarks || '-',
    ];
  });

  // AutoTable configuration
  autoTable(doc, {
    startY: 44,
    head: [
      [
        'Sl. No.',
        'Date',
        'Customer',
        'Item',
        'Description',
        'Path',
        'Thk',
        'Qty',
        'Status',
        'Start',
        'End',
        'Total Time',
        'Remarks',
      ],
    ],
    body: tableRows,
    theme: 'grid',
    headStyles: {
      fillColor: [15, 23, 42],
      textColor: [255, 255, 255],
      fontSize: 8.5,
      fontStyle: 'bold',
      halign: 'center',
      valign: 'middle',
    },
    bodyStyles: {
      fontSize: 8,
      textColor: [30, 41, 59],
      valign: 'middle',
      cellPadding: 2,
    },
    columnStyles: {
      0: { cellWidth: 18, fontStyle: 'bold', halign: 'center' }, // Sl. No
      1: { cellWidth: 20, halign: 'center' }, // Date
      2: { cellWidth: 32 }, // Customer
      3: { cellWidth: 28 }, // Item
      4: { cellWidth: 36 }, // Description
      5: { cellWidth: 16, halign: 'center' }, // Path
      6: { cellWidth: 14, halign: 'center' }, // Thk
      7: { cellWidth: 12, halign: 'center', fontStyle: 'bold' }, // Qty
      8: { cellWidth: 20, halign: 'center' }, // Status
      9: { cellWidth: 17, halign: 'center' }, // Start
      10: { cellWidth: 17, halign: 'center' }, // End
      11: { cellWidth: 20, halign: 'center', fontStyle: 'bold' }, // Total Time
      12: { cellWidth: 'auto' }, // Remarks
    },
    alternateRowStyles: {
      fillColor: [248, 250, 252],
    },
    margin: { left: 14, right: 14, bottom: 18 },
    didDrawCell: (data) => {
      // Color-code status cell text
      if (data.section === 'body' && data.column.index === 8) {
        const val = String(data.cell.raw);
        if (val === 'Completed') {
          doc.setTextColor(22, 101, 52); // green
        } else if (val === 'Production') {
          doc.setTextColor(180, 83, 9); // amber
        } else {
          doc.setTextColor(100, 116, 139); // slate
        }
      }
    },
    didDrawPage: (data) => {
      // Footer on every page
      const pageStr = `Page ${data.pageNumber} of ${doc.getNumberOfPages()}`;
      doc.setFontSize(8);
      doc.setFont('helvetica', 'normal');
      doc.setTextColor(148, 163, 184);
      doc.text(
        'ULTINO TOOL TECH — Wire-cut EDM & Production System',
        14,
        205
      );
      doc.text(pageStr, 283, 205, { align: 'right' });
    },
  });

  return doc;
}
