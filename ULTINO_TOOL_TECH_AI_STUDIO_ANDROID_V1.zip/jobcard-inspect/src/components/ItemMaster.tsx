import React, { useState } from 'react';
import {
  Layers,
  Search,
  PlusCircle,
  Building2,
  Edit3,
  Trash2,
  AlertTriangle,
} from 'lucide-react';
import { Item, Customer, Job } from '../types';
import { ItemModal } from './ItemModal';
import { CustomerModal } from './CustomerModal';

interface ItemMasterProps {
  items: Item[];
  customers: Customer[];
  jobs: Job[];
  onSaveItem: (item: Item) => Promise<void>;
  onDeleteItem: (itemId: string) => Promise<{ success: boolean; message?: string }>;
  onSaveCustomer: (customer: Customer) => Promise<void>;
  onSelectCustomerForNewJob: (customer: Customer, item?: Item) => void;
}

export const ItemMaster: React.FC<ItemMasterProps> = ({
  items,
  customers,
  jobs,
  onSaveItem,
  onDeleteItem,
  onSaveCustomer,
  onSelectCustomerForNewJob,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCustomerId, setSelectedCustomerId] = useState('');
  const [selectedStatus, setSelectedStatus] = useState<string>('ALL');

  const [isItemModalOpen, setIsItemModalOpen] = useState(false);
  const [itemToEdit, setItemToEdit] = useState<Item | null>(null);
  const [isCustomerModalOpen, setIsCustomerModalOpen] = useState(false);

  const [itemToDelete, setItemToDelete] = useState<Item | null>(null);
  const [deleteErrorMessage, setDeleteErrorMessage] = useState('');
  const [isDeleting, setIsDeleting] = useState(false);

  const filteredItems = items.filter((item) => {
    if (selectedCustomerId && item.customerId !== selectedCustomerId) return false;
    if (selectedStatus !== 'ALL' && item.productionStatus !== selectedStatus) return false;

    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const match =
        item.name.toLowerCase().includes(q) ||
        item.customerName.toLowerCase().includes(q) ||
        (item.description && item.description.toLowerCase().includes(q));
      if (!match) return false;
    }
    return true;
  });

  const handleOpenAdd = () => {
    setItemToEdit(null);
    setIsItemModalOpen(true);
  };

  const handleOpenEdit = (i: Item) => {
    setItemToEdit(i);
    setIsItemModalOpen(true);
  };

  const handleDeleteConfirm = async () => {
    if (!itemToDelete) return;
    try {
      setIsDeleting(true);
      setDeleteErrorMessage('');
      const res = await onDeleteItem(itemToDelete.id);
      if (res.success) {
        setItemToDelete(null);
      } else {
        setDeleteErrorMessage(res.message || 'Cannot delete item.');
      }
    } catch (err: any) {
      setDeleteErrorMessage(err?.message || 'Failed to delete item.');
    } finally {
      setIsDeleting(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 py-6 pb-24 space-y-5">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white border border-slate-200 rounded-2xl p-5 sm:p-6 shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2 py-0.5 text-xs font-black uppercase tracking-wider bg-slate-900 text-white rounded">
              MASTER DATA
            </span>
            <span className="text-xs text-slate-500 font-mono">REUSABLE COMPONENTS</span>
          </div>
          <h1 className="text-2xl font-black text-slate-900 tracking-tight mt-1 flex items-center gap-2">
            <Layers className="w-6 h-6 text-amber-600" />
            <span>Item Master</span>
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 font-medium">
            Permanent catalog of repeat manufacturing components, specs & recurring job profiles
          </p>
        </div>

        <button
          onClick={handleOpenAdd}
          className="flex items-center gap-2 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 text-slate-950 font-black px-4 py-2.5 rounded-xl text-xs sm:text-sm uppercase tracking-wider shadow-sm active:scale-95 transition"
        >
          <PlusCircle className="w-4 h-4 stroke-[2.5]" />
          <span>+ Add Item</span>
        </button>
      </div>

      {/* Filter and Search Bar (Formal White) */}
      <div className="bg-white border border-slate-200 rounded-xl p-4 space-y-3 shadow-2xs">
        <div className="relative">
          <Search className="w-4 h-4 absolute left-3.5 top-3.5 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search items by name, customer, spec or description..."
            className="w-full bg-slate-50 border border-slate-300 rounded-lg pl-10 pr-4 py-2.5 text-sm text-slate-900 placeholder-slate-400 focus:outline-none focus:border-amber-500"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-3.5 top-3 text-slate-400 hover:text-slate-600 text-xs"
            >
              ✕
            </button>
          )}
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
          <div>
            <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-600 mb-1">
              Filter by Customer
            </label>
            <select
              value={selectedCustomerId}
              onChange={(e) => setSelectedCustomerId(e.target.value)}
              className="w-full bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 text-xs text-slate-900 focus:outline-none focus:border-amber-500"
            >
              <option value="">All Customers</option>
              {customers.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-600 mb-1">
              Production Status
            </label>
            <select
              value={selectedStatus}
              onChange={(e) => setSelectedStatus(e.target.value)}
              className="w-full bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 text-xs text-slate-900 focus:outline-none focus:border-amber-500"
            >
              <option value="ALL">All Statuses</option>
              <option value="Not Started">Not Started</option>
              <option value="Pending">Pending</option>
              <option value="Production">Production</option>
              <option value="Completed">Completed</option>
            </select>
          </div>
        </div>
      </div>

      {/* Item Cards Grid (Formal White) */}
      {filteredItems.length === 0 ? (
        <div className="text-center py-12 bg-white border border-dashed border-slate-200 rounded-2xl">
          <Layers className="w-12 h-12 text-slate-400 mx-auto mb-2" />
          <h3 className="text-base font-bold text-slate-800">No Items Found</h3>
          <p className="text-xs text-slate-500 mt-1">
            {searchQuery ? 'Try clearing filters.' : 'Add your first reusable toolroom item.'}
          </p>
          <button
            onClick={handleOpenAdd}
            className="mt-4 px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs uppercase tracking-wider rounded-lg transition shadow-sm"
          >
            + Add New Item
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredItems.map((item) => {
            const itemJobs = jobs.filter((j) => j.itemId === item.id);
            const parentCustomer = customers.find((c) => c.id === item.customerId);

            return (
              <div
                key={item.id}
                className="bg-white border border-slate-200 hover:border-slate-300 rounded-xl p-5 shadow-2xs hover:shadow-xs flex flex-col justify-between transition group"
              >
                <div>
                  <div className="flex items-start justify-between gap-2 mb-2">
                    <span
                      className={`px-2 py-0.5 text-[10px] font-black uppercase tracking-wider rounded ${
                        item.productionStatus === 'Completed'
                          ? 'bg-emerald-50 text-emerald-800 border border-emerald-300'
                          : item.productionStatus === 'Production'
                          ? 'bg-amber-50 text-amber-800 border border-amber-300'
                          : item.productionStatus === 'Pending'
                          ? 'bg-blue-50 text-blue-800 border border-blue-300'
                          : 'bg-slate-100 text-slate-700 border border-slate-300'
                      }`}
                    >
                      {item.productionStatus}
                    </span>
                    <span className="text-[11px] font-bold text-amber-700">
                      {itemJobs.length} Orders
                    </span>
                  </div>

                  <h3 className="text-base font-bold text-slate-900 group-hover:text-amber-700 transition-colors">
                    {item.name}
                  </h3>

                  <div className="flex items-center gap-1.5 text-xs text-slate-500 font-semibold mt-1">
                    <Building2 className="w-3.5 h-3.5 text-slate-400" />
                    <span className="truncate">{item.customerName}</span>
                  </div>

                  {item.description && (
                    <p className="text-xs text-slate-600 line-clamp-2 mt-2 bg-slate-50 p-2.5 rounded-lg border border-slate-200">
                      {item.description}
                    </p>
                  )}

                  <div className="grid grid-cols-2 gap-2 text-center text-xs my-3 bg-slate-50 p-2 rounded-lg border border-slate-200">
                    <div>
                      <span className="text-[9px] uppercase font-bold text-slate-500 block">
                        Default Path
                      </span>
                      <span className="font-mono font-bold text-slate-800">
                        {item.defaultPathLength || '-'}
                      </span>
                    </div>
                    <div>
                      <span className="text-[9px] uppercase font-bold text-slate-500 block">
                        Default Thk
                      </span>
                      <span className="font-mono font-bold text-slate-800">
                        {item.defaultThickness || '-'}
                      </span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center justify-between gap-2 pt-3 border-t border-slate-100">
                  <button
                    onClick={() => {
                      if (parentCustomer) {
                        onSelectCustomerForNewJob(parentCustomer, item);
                      }
                    }}
                    className="flex-1 px-3 py-2 bg-slate-100 hover:bg-slate-900 hover:text-white text-slate-800 text-xs font-bold uppercase rounded-lg border border-slate-300 transition shadow-2xs"
                  >
                    + New Job for this Item
                  </button>

                  <div className="flex items-center gap-1">
                    <button
                      onClick={() => handleOpenEdit(item)}
                      className="p-2 text-slate-500 hover:text-amber-700 hover:bg-slate-100 rounded-lg transition"
                      title="Edit Item"
                    >
                      <Edit3 className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => {
                        setDeleteErrorMessage('');
                        setItemToDelete(item);
                      }}
                      className="p-2 text-slate-500 hover:text-red-600 hover:bg-slate-100 rounded-lg transition"
                      title="Delete Item"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Item Modal */}
      <ItemModal
        isOpen={isItemModalOpen}
        onClose={() => setIsItemModalOpen(false)}
        onSave={onSaveItem}
        itemToEdit={itemToEdit}
        customers={customers}
        onAddNewCustomer={() => {
          setIsItemModalOpen(false);
          setIsCustomerModalOpen(true);
        }}
      />

      {/* Inline Customer Modal */}
      <CustomerModal
        isOpen={isCustomerModalOpen}
        onClose={() => setIsCustomerModalOpen(false)}
        onSave={async (newCust) => {
          await onSaveCustomer(newCust);
          setIsItemModalOpen(true);
        }}
      />

      {/* Safe Delete Confirmation Modal */}
      {itemToDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 backdrop-blur-xs p-4">
          <div className="relative w-full max-w-md bg-white border border-slate-200 rounded-2xl p-6 shadow-xl space-y-4">
            <div className="flex items-center gap-3 text-red-600">
              <div className="p-2 bg-red-50 border border-red-200 rounded-xl">
                <AlertTriangle className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-base font-bold text-slate-900">Delete Item Record</h3>
                <p className="text-xs text-slate-500">Safety Verification</p>
              </div>
            </div>

            <p className="text-xs sm:text-sm text-slate-700">
              Are you sure you want to delete{' '}
              <strong className="text-slate-900">{itemToDelete.name}</strong> ({itemToDelete.customerName})?
            </p>

            {jobs.some((j) => j.itemId === itemToDelete.id) ? (
              <div className="p-3 bg-red-50 border border-red-200 rounded-lg text-xs text-red-800 space-y-1">
                <span className="font-bold block">⚠️ Deletion Prohibited:</span>
                <span>
                  This item is linked to{' '}
                  <strong>{jobs.filter((j) => j.itemId === itemToDelete.id).length} historical job cards</strong>.
                  Deleting it would corrupt production job records.
                </span>
              </div>
            ) : (
              <div className="p-3 bg-slate-50 border border-slate-200 rounded-lg text-xs text-slate-600">
                ✓ No existing job cards reference this item. It can be safely removed.
              </div>
            )}

            {deleteErrorMessage && (
              <div className="p-2.5 bg-red-50 text-red-700 text-xs rounded border border-red-200">
                {deleteErrorMessage}
              </div>
            )}

            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={() => setItemToDelete(null)}
                className="px-4 py-2 text-xs font-semibold uppercase text-slate-600 hover:text-slate-900 rounded-lg hover:bg-slate-100 transition"
              >
                Cancel
              </button>
              <button
                type="button"
                disabled={isDeleting || jobs.some((j) => j.itemId === itemToDelete.id)}
                onClick={handleDeleteConfirm}
                className="px-5 py-2.5 bg-red-600 hover:bg-red-500 text-white font-bold text-xs uppercase tracking-wider rounded-lg shadow-sm transition disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {isDeleting ? 'Deleting...' : 'Delete Item'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
