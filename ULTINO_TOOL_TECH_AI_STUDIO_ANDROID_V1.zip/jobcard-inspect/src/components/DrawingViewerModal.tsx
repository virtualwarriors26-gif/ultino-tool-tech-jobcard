import React, { useState } from 'react';
import { X, ZoomIn, ZoomOut, RotateCw, Download, Printer, Eye } from 'lucide-react';
import { JobDrawing } from '../types';

interface DrawingViewerModalProps {
  drawing?: JobDrawing;
  title: string;
  onClose: () => void;
}

export const DrawingViewerModal: React.FC<DrawingViewerModalProps> = ({
  drawing,
  title,
  onClose,
}) => {
  const [scale, setScale] = useState(1);
  const [rotation, setRotation] = useState(0);

  if (!drawing || !drawing.dataUrl) return null;

  const isPdf = drawing.fileType === 'application/pdf' || drawing.fileName.toLowerCase().endsWith('.pdf');

  const handleZoomIn = () => setScale((prev) => Math.min(prev + 0.25, 3.5));
  const handleZoomOut = () => setScale((prev) => Math.max(prev - 0.25, 0.5));
  const handleRotate = () => setRotation((prev) => (prev + 90) % 360);
  const handleReset = () => {
    setScale(1);
    setRotation(0);
  };

  const handlePrint = () => {
    const printWindow = window.open('', '_blank');
    if (!printWindow) return;
    printWindow.document.write(`
      <!DOCTYPE html>
      <html>
        <head>
          <title>${title} - Drawing</title>
          <style>
            body { margin: 0; display: flex; justify-content: center; align-items: center; min-height: 100vh; background: white; }
            img { max-width: 95vw; max-height: 95vh; object-fit: contain; }
            @page { size: auto; margin: 10mm; }
          </style>
        </head>
        <body>
          <img src="${drawing.dataUrl}" onload="window.print();window.close();" />
        </body>
      </html>
    `);
    printWindow.document.close();
  };

  const handleDownload = () => {
    const link = document.createElement('a');
    link.href = drawing.dataUrl;
    link.download = drawing.fileName || 'job_drawing';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/90 backdrop-blur-sm p-2 sm:p-4">
      <div className="relative w-full max-w-5xl h-[90vh] flex flex-col bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-2xl">
        {/* Header Bar */}
        <div className="flex items-center justify-between px-4 py-3 bg-slate-950 border-b border-slate-800 text-white">
          <div className="flex items-center gap-2 truncate">
            <Eye className="w-5 h-5 text-amber-400 shrink-0" />
            <div className="truncate">
              <h3 className="font-bold text-sm sm:text-base text-slate-100 truncate">{title}</h3>
              <p className="text-xs text-slate-400 truncate">{drawing.fileName}</p>
            </div>
          </div>

          {/* Action Toolbar */}
          <div className="flex items-center gap-1 sm:gap-2">
            {!isPdf && (
              <>
                <button
                  onClick={handleZoomOut}
                  title="Zoom Out"
                  className="p-1.5 sm:p-2 text-slate-300 hover:text-white hover:bg-slate-800 rounded-lg transition"
                >
                  <ZoomOut className="w-4 h-4" />
                </button>
                <span className="text-xs font-mono text-slate-400 px-1 hidden sm:inline">
                  {Math.round(scale * 100)}%
                </span>
                <button
                  onClick={handleZoomIn}
                  title="Zoom In"
                  className="p-1.5 sm:p-2 text-slate-300 hover:text-white hover:bg-slate-800 rounded-lg transition"
                >
                  <ZoomIn className="w-4 h-4" />
                </button>
                <button
                  onClick={handleRotate}
                  title="Rotate 90°"
                  className="p-1.5 sm:p-2 text-slate-300 hover:text-white hover:bg-slate-800 rounded-lg transition"
                >
                  <RotateCw className="w-4 h-4" />
                </button>
                <button
                  onClick={handleReset}
                  className="text-xs px-2 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded hidden sm:inline-block"
                >
                  Reset
                </button>
              </>
            )}

            <button
              onClick={handlePrint}
              title="Print Drawing"
              className="p-1.5 sm:p-2 text-slate-300 hover:text-white hover:bg-slate-800 rounded-lg transition"
            >
              <Printer className="w-4 h-4" />
            </button>
            <button
              onClick={handleDownload}
              title="Download File"
              className="p-1.5 sm:p-2 text-slate-300 hover:text-white hover:bg-slate-800 rounded-lg transition"
            >
              <Download className="w-4 h-4" />
            </button>
            <div className="h-4 w-px bg-slate-700 mx-1" />
            <button
              onClick={onClose}
              title="Close"
              className="p-1.5 sm:p-2 text-slate-400 hover:text-red-400 hover:bg-slate-800 rounded-lg transition"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Drawing Content Area */}
        <div className="flex-1 bg-slate-950 flex items-center justify-center p-4 overflow-auto select-none">
          {isPdf ? (
            <iframe
              src={drawing.dataUrl}
              title="PDF Drawing Document"
              className="w-full h-full rounded border border-slate-800"
            />
          ) : (
            <div
              className="transition-transform duration-150 ease-out flex items-center justify-center"
              style={{
                transform: `scale(${scale}) rotate(${rotation}deg)`,
              }}
            >
              <img
                src={drawing.dataUrl}
                alt={title}
                className="max-w-full max-h-[75vh] object-contain rounded shadow-lg border border-slate-800 pointer-events-auto"
              />
            </div>
          )}
        </div>

        {/* Footer info */}
        <div className="px-4 py-2 bg-slate-950 border-t border-slate-800 flex justify-between items-center text-xs text-slate-400">
          <span>ULTINO TOOL TECH • WIRE-CUT PRECISION DRAWING</span>
          <span>Uploaded: {new Date(drawing.uploadedAt).toLocaleDateString()}</span>
        </div>
      </div>
    </div>
  );
};
