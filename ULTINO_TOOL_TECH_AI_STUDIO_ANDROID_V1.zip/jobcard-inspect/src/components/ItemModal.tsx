import React, { useState, useEffect } from 'react';
import { X, Layers, Building2, FileText, CheckCircle2, Ruler, Box } from 'lucide-react';
import { Item, Customer, ProductionStatus } from '../types';
import { VoiceDescriptionController } from './VoiceDescriptionController';

interface ItemModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (item: Item) => Promise<void>;
  itemToEdit?: Item | null;
  customers: Customer[];
  defaultCustomerId?: string;
  onAddNewCustomer?: () => void;
}

export const ItemModal: React.FC<ItemModalProps> = ({
  isOpen,
  onClose,
  onSave,
  itemToEdit,
  customers,
  defaultCustomerId,
  onAddNewCustomer,
}) => {
  const [name, setName] = useState('');
  const [customerId, setCustomerId] = useState('');
  const [productionStatus, setProductionStatus] = useState<ProductionStatus>('Not Started');
  const [description, setDescription] = useState('');
  const [defaultPathLength, setDefaultPathLength] = useState('');
  const [defaultThickness, setDefaultThickness] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    if (itemToEdit) {
      setName(itemToEdit.name || '');
      setCustomerId(itemToEdit.customerId || '');
      setProductionStatus(itemToEdit.productionStatus || 'Not Started');
      setDescription(itemToEdit.description || '');
      setDefaultPathLength(itemToEdit.defaultPathLength || '');
      setDefaultThickness(itemToEdit.defaultThickness || '');
    } else {
      setName('');
      setCustomerId(defaultCustomerId || (customers[0]?.id ?? ''));
      setProductionStatus('Not Started');
      setDescription('');
      setDefaultPathLength('');
      setDefaultThickness('');
    }
    setError('');
  }, [itemToEdit, isOpen, defaultCustomerId, customers]);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      setError('Item name is required.');
      return;
    }
    if (!customerId) {
      setError('Please select a customer for this item.');
      return;
    }

    const matchedCustomer = customers.find((c) => c.id === customerId);
    if (!matchedCustomer) {
      setError('Selected customer is invalid.');
      return;
    }

    try {
      setIsSubmitting(true);
      setError('');
      const item: Item = {
        id: itemToEdit ? itemToEdit.id : `item-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
        name: name.trim(),
        customerId: matchedCustomer.id,
        customerName: matchedCustomer.name,
        productionStatus,
        description: description.trim() || undefined,
        defaultPathLength: defaultPathLength.trim() || undefined,
        defaultThickness: defaultThickness.trim() || undefined,
        createdAt: itemToEdit ? itemToEdit.createdAt : new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };

      await onSave(item);
      onClose();
    } catch (err: any) {
      setError(err?.message || 'Failed to save item.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 backdrop-blur-xs p-4">
      <div className="relative w-full max-w-lg bg-white border border-slate-200 rounded-2xl shadow-xl overflow-hidden text-slate-900">
        <div className="flex items-center justify-between px-6 py-4 bg-slate-50 border-b border-slate-200">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-amber-50 text-amber-700 rounded-lg border border-amber-200">
              <Layers className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900">
                {itemToEdit ? 'Edit Item' : 'Add New Item'}
              </h3>
              <p className="text-xs text-slate-500 font-medium">Item Master Record (Reusable Component)</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-700 p-1 rounded-lg hover:bg-slate-100 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          {error && (
            <div className="p-3 bg-red-50 border border-red-200 text-red-700 text-xs rounded-lg">
              {error}
            </div>
          )}

          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-xs font-bold text-slate-700 uppercase tracking-wider">
                Customer <span className="text-amber-600">*</span>
              </label>
              {onAddNewCustomer && (
                <button
                  type="button"
                  onClick={onAddNewCustomer}
                  className="text-xs text-amber-700 hover:text-amber-800 font-bold underline"
                >
                  + Add New Customer
                </button>
              )}
            </div>
            <div className="relative">
              <Building2 className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
              <select
                value={customerId}
                onChange={(e) => setCustomerId(e.target.value)}
                className="w-full bg-slate-50 border border-slate-300 rounded-lg pl-9 pr-3 py-2 text-sm text-slate-900 focus:outline-none focus:border-amber-500"
                required
              >
                <option value="">-- Select Customer --</option>
                {customers.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
              Item Name <span className="text-amber-600">*</span>
            </label>
            <div className="relative">
              <Box className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g. Die Plate, Punch Core, Stripper"
                className="w-full bg-slate-50 border border-slate-300 rounded-lg pl-9 pr-3 py-2 text-sm text-slate-900 placeholder-slate-400 focus:outline-none focus:border-amber-500"
                required
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
              Current Production Status
            </label>
            <select
              value={productionStatus}
              onChange={(e) => setProductionStatus(e.target.value as ProductionStatus)}
              className="w-full bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 text-sm text-slate-900 focus:outline-none focus:border-amber-500"
            >
              <option value="Not Started">Not Started</option>
              <option value="Pending">Pending</option>
              <option value="Production">Production</option>
              <option value="Completed">Completed</option>
            </select>
          </div>

          <VoiceDescriptionController
            value={description}
            onChange={setDescription}
            label="Description / Component Spec"
            placeholder="Dictate or type: e.g. 12-cavity progressive punch die plate, D2 steel hardened..."
          />

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                Default Path Length
              </label>
              <div className="relative">
                <Ruler className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
                <input
                  type="text"
                  value={defaultPathLength}
                  onChange={(e) => setDefaultPathLength(e.target.value)}
                  placeholder="e.g. 640 mm"
                  className="w-full bg-slate-50 border border-slate-300 rounded-lg pl-9 pr-3 py-2 text-sm text-slate-900 placeholder-slate-400 focus:outline-none focus:border-amber-500"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                Default Thickness
              </label>
              <div className="relative">
                <Ruler className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
                <input
                  type="text"
                  value={defaultThickness}
                  onChange={(e) => setDefaultThickness(e.target.value)}
                  placeholder="e.g. 32 mm"
                  className="w-full bg-slate-50 border border-slate-300 rounded-lg pl-9 pr-3 py-2 text-sm text-slate-900 placeholder-slate-400 focus:outline-none focus:border-amber-500"
                />
              </div>
            </div>
          </div>

          <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-100">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold text-slate-600 hover:text-slate-900 uppercase tracking-wider rounded-lg hover:bg-slate-100 transition"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="flex items-center gap-2 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 text-slate-950 font-bold px-5 py-2.5 rounded-lg text-xs uppercase tracking-wider shadow-sm transition disabled:opacity-50"
            >
              <CheckCircle2 className="w-4 h-4 stroke-[2.5]" />
              <span>{itemToEdit ? 'Update Item' : 'Save Item'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
