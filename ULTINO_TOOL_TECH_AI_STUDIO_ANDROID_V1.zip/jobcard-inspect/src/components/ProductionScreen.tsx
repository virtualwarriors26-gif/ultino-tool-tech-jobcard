import React, { useState, useEffect } from 'react';
import {
  Clock,
  Play,
  Square,
  Eye,
  CheckCircle2,
  AlertCircle,
  PlusCircle,
  Filter,
  Search,
} from 'lucide-react';
import { Job } from '../types';
import { calculateLiveElapsed } from '../services/storage';

interface ProductionScreenProps {
  jobs: Job[];
  onNewJobClick: () => void;
  onEditJob: (job: Job) => void;
  onViewJob: (job: Job) => void;
  onViewDrawing: (job: Job) => void;
  onStartJob: (job: Job) => void;
  onStopJob: (job: Job) => void;
  onStatusChange: (job: Job, newStatus: 'Pending' | 'Production' | 'Completed') => void;
}

export const ProductionScreen: React.FC<ProductionScreenProps> = ({
  jobs,
  onNewJobClick,
  onEditJob,
  onViewJob,
  onViewDrawing,
  onStartJob,
  onStopJob,
  onStatusChange,
}) => {
  const [filterMode, setFilterMode] = useState<'production' | 'pending' | 'all_active'>('production');
  const [searchQuery, setSearchQuery] = useState('');
  const [tick, setTick] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setTick((t) => t + 1);
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  const inProductionJobs = jobs.filter((j) => j.productionStatus === 'Production');
  const pendingJobs = jobs.filter((j) => j.productionStatus === 'Pending');

  const filteredJobs = jobs.filter((job) => {
    if (filterMode === 'production' && job.productionStatus !== 'Production') return false;
    if (filterMode === 'pending' && job.productionStatus !== 'Pending') return false;
    if (filterMode === 'all_active' && job.productionStatus === 'Completed') return false;

    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const match =
        job.jobNumber.toLowerCase().includes(q) ||
        job.customerName.toLowerCase().includes(q) ||
        job.itemName.toLowerCase().includes(q) ||
        (job.remarks && job.remarks.toLowerCase().includes(q));
      if (!match) return false;
    }
    return true;
  });

  return (
    <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 py-6 pb-24 space-y-5">
      {/* Formal White Header Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white border border-slate-200 rounded-2xl p-5 sm:p-6 shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2 py-0.5 text-xs font-black uppercase tracking-wider bg-slate-900 text-white rounded">
              SHOP FLOOR
            </span>
            <span className="text-xs text-slate-500 font-mono">OPERATOR CONSOLE</span>
          </div>
          <h1 className="text-2xl font-black text-slate-900 tracking-tight mt-1 flex items-center gap-2">
            <Clock className="w-6 h-6 text-amber-600" />
            <span>Production Tracking</span>
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 font-medium">
            Live wire-cut status, machine timings, and rapid floor execution
          </p>
        </div>

        <button
          onClick={onNewJobClick}
          className="flex items-center gap-2 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 text-slate-950 font-black px-4 py-2.5 rounded-xl text-xs sm:text-sm uppercase tracking-wider shadow-sm active:scale-95 transition"
        >
          <PlusCircle className="w-4 h-4 stroke-[2.5]" />
          <span>+ New Job Card</span>
        </button>
      </div>

      {/* Filter Tabs & Search Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white border border-slate-200 p-3 rounded-xl shadow-2xs">
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 sm:pb-0">
          <button
            onClick={() => setFilterMode('production')}
            className={`flex items-center gap-2 px-3 py-2 rounded-lg text-xs font-bold uppercase tracking-wider transition ${
              filterMode === 'production'
                ? 'bg-slate-900 text-white shadow-xs'
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
          >
            <span className="w-2 h-2 rounded-full bg-amber-400 animate-pulse" />
            <span>In Production ({inProductionJobs.length})</span>
          </button>

          <button
            onClick={() => setFilterMode('pending')}
            className={`flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-bold uppercase tracking-wider transition ${
              filterMode === 'pending'
                ? 'bg-slate-900 text-white shadow-xs'
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
          >
            <AlertCircle className="w-3.5 h-3.5" />
            <span>Pending Machine ({pendingJobs.length})</span>
          </button>

          <button
            onClick={() => setFilterMode('all_active')}
            className={`flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-bold uppercase tracking-wider transition ${
              filterMode === 'all_active'
                ? 'bg-slate-900 text-white shadow-xs'
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
          >
            <Filter className="w-3.5 h-3.5" />
            <span>All Floor ({inProductionJobs.length + pendingJobs.length})</span>
          </button>
        </div>

        {/* Search */}
        <div className="relative min-w-[240px]">
          <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search by Job No, Customer, Item..."
            className="w-full bg-slate-50 border border-slate-300 rounded-lg pl-9 pr-3 py-2 text-xs text-slate-900 placeholder-slate-400 focus:outline-none focus:border-amber-500"
          />
        </div>
      </div>

      {filteredJobs.length === 0 ? (
        <div className="text-center py-12 bg-white border border-dashed border-slate-200 rounded-2xl">
          <Clock className="w-12 h-12 text-slate-400 mx-auto mb-2" />
          <h3 className="text-base font-bold text-slate-800">
            {filterMode === 'production'
              ? 'No Jobs Currently In Production'
              : 'No Jobs Matching Selected Filter'}
          </h3>
          <p className="text-xs text-slate-500 mt-1">
            Tap "+ New Job Card" or start any pending job from below.
          </p>
        </div>
      ) : (
        <>
          {/* PC Table Layout (Formal White) */}
          <div className="hidden md:block bg-white border border-slate-200 rounded-xl overflow-hidden shadow-xs">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs text-slate-700">
                <thead className="bg-slate-50 text-slate-700 uppercase tracking-wider border-b border-slate-200 text-[11px] font-bold">
                  <tr>
                    <th className="py-3.5 px-4">JOB NO.</th>
                    <th className="py-3.5 px-4">CUSTOMER</th>
                    <th className="py-3.5 px-4">ITEM</th>
                    <th className="py-3.5 px-4 text-center">PATH / THK</th>
                    <th className="py-3.5 px-4 text-center">QTY</th>
                    <th className="py-3.5 px-4 text-center">START TIME</th>
                    <th className="py-3.5 px-4 text-center">ELAPSED TIME</th>
                    <th className="py-3.5 px-4 text-center">STATUS</th>
                    <th className="py-3.5 px-4 text-center">DRAWING</th>
                    <th className="py-3.5 px-4 text-right">OPERATOR ACTIONS</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filteredJobs.map((job) => {
                    const isRunning = job.productionStatus === 'Production';
                    return (
                      <tr
                        key={job.id}
                        className="hover:bg-slate-50/80 transition group"
                      >
                        {/* Job No */}
                        <td className="py-3.5 px-4 font-black text-slate-900 font-mono text-sm whitespace-nowrap">
                          {job.jobNumber}
                        </td>

                        {/* Customer */}
                        <td className="py-3.5 px-4 font-bold text-slate-900 whitespace-nowrap">
                          {job.customerName}
                        </td>

                        {/* Item */}
                        <td className="py-3.5 px-4">
                          <span className="font-bold text-slate-800 block truncate max-w-xs">
                            {job.itemName}
                          </span>
                          {job.description && (
                            <span className="text-[10px] text-slate-500 block truncate max-w-xs font-medium">
                              {job.description}
                            </span>
                          )}
                        </td>

                        {/* Path / Thk */}
                        <td className="py-3.5 px-4 text-center whitespace-nowrap font-mono text-[11px] text-slate-700">
                          <span>{job.pathLength || '-'}</span>
                          <span className="text-slate-400 mx-1">/</span>
                          <span>{job.thickness || '-'}</span>
                        </td>

                        {/* Qty */}
                        <td className="py-3.5 px-4 text-center font-bold text-amber-700 whitespace-nowrap">
                          {job.quantity} pcs
                        </td>

                        {/* Start Time */}
                        <td className="py-3.5 px-4 text-center whitespace-nowrap font-mono text-slate-600">
                          {job.startTime
                            ? new Date(job.startTime).toLocaleTimeString([], {
                                hour: '2-digit',
                                minute: '2-digit',
                                hour12: true,
                              })
                            : '-'}
                        </td>

                        {/* Elapsed Time */}
                        <td className="py-3.5 px-4 text-center whitespace-nowrap">
                          {isRunning ? (
                            <span className="px-2 py-0.5 rounded font-black text-amber-800 bg-amber-50 border border-amber-300 animate-pulse font-mono">
                              {calculateLiveElapsed(job.startTime)}
                            </span>
                          ) : (
                            <span className="text-slate-500 font-mono">{job.totalTimeFormatted || '-'}</span>
                          )}
                        </td>

                        {/* Status Badge */}
                        <td className="py-3.5 px-4 text-center whitespace-nowrap">
                          <span
                            className={`px-2.5 py-1 text-[10px] font-black uppercase tracking-wider rounded-full ${
                              job.productionStatus === 'Completed'
                                ? 'bg-emerald-50 text-emerald-800 border border-emerald-300'
                                : job.productionStatus === 'Production'
                                ? 'bg-amber-50 text-amber-800 border border-amber-300'
                                : 'bg-slate-100 text-slate-700 border border-slate-300'
                            }`}
                          >
                            {job.productionStatus}
                          </span>
                        </td>

                        {/* Drawing */}
                        <td className="py-3.5 px-4 text-center whitespace-nowrap">
                          {job.drawing ? (
                            <button
                              onClick={() => onViewDrawing(job)}
                              className="p-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 hover:text-amber-700 rounded-lg border border-slate-300 transition"
                              title="View Technical Drawing"
                            >
                              <Eye className="w-4 h-4" />
                            </button>
                          ) : (
                            <span className="text-slate-400 text-xs">None</span>
                          )}
                        </td>

                        {/* Actions */}
                        <td className="py-3.5 px-4 text-right whitespace-nowrap">
                          <div className="flex items-center justify-end gap-1.5">
                            {isRunning ? (
                              <button
                                onClick={() => onStopJob(job)}
                                className="flex items-center gap-1 bg-emerald-600 hover:bg-emerald-500 text-white font-bold px-3 py-1.5 rounded-lg text-xs uppercase tracking-wider transition shadow-2xs"
                              >
                                <Square className="w-3.5 h-3.5 fill-white" />
                                <span>Stop Job</span>
                              </button>
                            ) : (
                              <button
                                onClick={() => onStartJob(job)}
                                className="flex items-center gap-1 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 text-slate-950 font-bold px-3 py-1.5 rounded-lg text-xs uppercase tracking-wider transition shadow-2xs"
                              >
                                <Play className="w-3.5 h-3.5 fill-slate-950" />
                                <span>Start Job</span>
                              </button>
                            )}
                            <button
                              onClick={() => onEditJob(job)}
                              className="px-2.5 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold rounded-lg border border-slate-300 transition"
                            >
                              Edit
                            </button>
                            <button
                              onClick={() => onViewJob(job)}
                              className="px-2.5 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold rounded-lg border border-slate-300 transition"
                            >
                              Card
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>

          {/* Mobile Card Layout */}
          <div className="grid grid-cols-1 gap-3.5 md:hidden">
            {filteredJobs.map((job) => {
              const isRunning = job.productionStatus === 'Production';
              return (
                <div
                  key={job.id}
                  className={`bg-white border rounded-xl p-4 shadow-xs flex flex-col justify-between ${
                    isRunning ? 'border-amber-300 bg-amber-50/20' : 'border-slate-200'
                  }`}
                >
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <span className="px-2 py-0.5 text-xs font-black bg-slate-900 text-amber-400 rounded tracking-wider font-mono">
                          {job.jobNumber}
                        </span>
                        <span className="text-[11px] text-slate-500 font-medium">{job.date}</span>
                      </div>
                      <span
                        className={`px-2 py-0.5 text-[10px] font-black uppercase tracking-wider rounded ${
                          isRunning
                            ? 'bg-amber-100 text-amber-800 border border-amber-300'
                            : job.productionStatus === 'Completed'
                            ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                            : 'bg-slate-100 text-slate-700'
                        }`}
                      >
                        {job.productionStatus}
                      </span>
                    </div>

                    <h3 className="text-base font-bold text-slate-900 leading-tight">
                      {job.itemName}
                    </h3>
                    <p className="text-xs font-bold text-amber-700 mb-2">{job.customerName}</p>

                    <div className="grid grid-cols-3 gap-1 bg-slate-50 p-2 rounded-lg text-center border border-slate-200 my-2">
                      <div>
                        <span className="text-[9px] uppercase font-bold text-slate-500 block">
                          Path
                        </span>
                        <span className="text-xs font-bold text-slate-800">
                          {job.pathLength || '-'}
                        </span>
                      </div>
                      <div>
                        <span className="text-[9px] uppercase font-bold text-slate-500 block">
                          Thk
                        </span>
                        <span className="text-xs font-bold text-slate-800">
                          {job.thickness || '-'}
                        </span>
                      </div>
                      <div>
                        <span className="text-[9px] uppercase font-bold text-slate-500 block">
                          Qty
                        </span>
                        <span className="text-xs font-black text-amber-700">
                          {job.quantity} pcs
                        </span>
                      </div>
                    </div>

                    <div className="bg-slate-50 border border-slate-200 rounded-lg p-2.5 flex items-center justify-between mb-3">
                      <div className="flex items-center gap-1.5 text-xs text-slate-600 font-semibold">
                        <Clock className="w-3.5 h-3.5 text-amber-600" />
                        <span>{isRunning ? 'Machining Time:' : 'Recorded Time:'}</span>
                      </div>
                      <span className="text-sm font-black text-amber-800 font-mono">
                        {isRunning
                          ? calculateLiveElapsed(job.startTime)
                          : job.totalTimeFormatted || '0 min'}
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 pt-2 border-t border-slate-100">
                    {job.drawing && (
                      <button
                        onClick={() => onViewDrawing(job)}
                        className="p-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg border border-slate-300"
                        title="View Drawing"
                      >
                        <Eye className="w-5 h-5" />
                      </button>
                    )}

                    {isRunning ? (
                      <button
                        onClick={() => onStopJob(job)}
                        className="flex-1 flex items-center justify-center gap-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold py-2.5 rounded-lg text-xs uppercase tracking-wider shadow-2xs"
                      >
                        <Square className="w-4 h-4 fill-white" />
                        <span>Stop / Complete</span>
                      </button>
                    ) : (
                      <button
                        onClick={() => onStartJob(job)}
                        className="flex-1 flex items-center justify-center gap-2 bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950 font-black py-2.5 rounded-lg text-xs uppercase tracking-wider shadow-2xs"
                      >
                        <Play className="w-4 h-4 fill-slate-950" />
                        <span>Start Job</span>
                      </button>
                    )}

                    <button
                      onClick={() => onEditJob(job)}
                      className="px-3 py-2.5 bg-slate-100 text-slate-700 text-xs font-bold uppercase rounded-lg border border-slate-300"
                    >
                      Edit
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </>
      )}
    </div>
  );
};
