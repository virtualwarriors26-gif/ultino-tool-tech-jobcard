import React, { useState, useEffect, useRef } from 'react';
import {
  Camera,
  Upload,
  Play,
  Square,
  Clock,
  Calendar,
  Building2,
  Layers,
  FileText,
  Ruler,
  CheckCircle2,
  Trash2,
  Eye,
  PlusCircle,
  Hash,
  AlertTriangle,
  RotateCcw,
} from 'lucide-react';
import { Job, Customer, Item, JobDrawing } from '../types';
import { calculateDuration, calculateLiveElapsed } from '../services/storage';
import { CustomerModal } from './CustomerModal';
import { ItemModal } from './ItemModal';
import { DrawingViewerModal } from './DrawingViewerModal';
import { VoiceDescriptionController } from './VoiceDescriptionController';

interface JobCardFormProps {
  jobToEdit?: Job | null;
  customers: Customer[];
  items: Item[];
  nextSerialNumberFormatted: string;
  nextSerialNumberIndex: number;
  onSaveJob: (job: Job) => Promise<void>;
  onCancel: () => void;
  onSaveCustomer: (customer: Customer) => Promise<void>;
  onSaveItem: (item: Item) => Promise<void>;
}

export const JobCardForm: React.FC<JobCardFormProps> = ({
  jobToEdit,
  customers,
  items,
  nextSerialNumberFormatted,
  nextSerialNumberIndex,
  onSaveJob,
  onCancel,
  onSaveCustomer,
  onSaveItem,
}) => {
  // Form State
  const [jobNumber, setJobNumber] = useState(
    jobToEdit ? jobToEdit.jobNumber : nextSerialNumberFormatted
  );
  const [serialIndex] = useState(
    jobToEdit ? jobToEdit.serialNumberIndex : nextSerialNumberIndex
  );
  const [date, setDate] = useState(
    jobToEdit ? jobToEdit.date : new Date().toISOString().split('T')[0]
  );
  const [customerId, setCustomerId] = useState(jobToEdit?.customerId || '');
  const [customerSearch, setCustomerSearch] = useState(jobToEdit?.customerName || '');
  const [isCustomerDropdownOpen, setIsCustomerDropdownOpen] = useState(false);

  const [itemId, setItemId] = useState(jobToEdit?.itemId || '');
  const [itemSearch, setItemSearch] = useState(jobToEdit?.itemName || '');
  const [isItemDropdownOpen, setIsItemDropdownOpen] = useState(false);

  const [description, setDescription] = useState(jobToEdit?.description || '');
  const [pathLength, setPathLength] = useState(jobToEdit?.pathLength || '');
  const [thickness, setThickness] = useState(jobToEdit?.thickness || '');
  const [quantity, setQuantity] = useState<number>(jobToEdit?.quantity || 1);
  const [remarks, setRemarks] = useState(jobToEdit?.remarks || '');

  // Drawing
  const [drawing, setDrawing] = useState<JobDrawing | undefined>(jobToEdit?.drawing);
  const [isViewerOpen, setIsViewerOpen] = useState(false);

  // Status & Timings
  const [productionStatus, setProductionStatus] = useState<'Pending' | 'Production' | 'Completed'>(
    jobToEdit?.productionStatus || 'Pending'
  );
  const [startTime, setStartTime] = useState<string | undefined>(jobToEdit?.startTime);
  const [endTime, setEndTime] = useState<string | undefined>(jobToEdit?.endTime);
  const [totalTimeFormatted, setTotalTimeFormatted] = useState<string>(
    jobToEdit?.totalTimeFormatted || ''
  );
  const [totalTimeMinutes, setTotalTimeMinutes] = useState<number>(
    jobToEdit?.totalTimeMinutes || 0
  );
  const [liveElapsed, setLiveElapsed] = useState<string>('');
  const [showManualTimeEdit, setShowManualTimeEdit] = useState(false);

  // Modals inside workflow
  const [isAddCustomerModalOpen, setIsAddCustomerModalOpen] = useState(false);
  const [isAddItemModalOpen, setIsAddItemModalOpen] = useState(false);

  // File Inputs
  const cameraInputRef = useRef<HTMLInputElement>(null);
  const galleryInputRef = useRef<HTMLInputElement>(null);

  // Errors & submission
  const [formError, setFormError] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Live timer tick when in Production
  useEffect(() => {
    let timer: NodeJS.Timeout | null = null;
    if (productionStatus === 'Production' && startTime && !endTime) {
      setLiveElapsed(calculateLiveElapsed(startTime));
      timer = setInterval(() => {
        setLiveElapsed(calculateLiveElapsed(startTime));
      }, 5000);
    } else {
      setLiveElapsed('');
    }
    return () => {
      if (timer) clearInterval(timer);
    };
  }, [productionStatus, startTime, endTime]);

  // Recalculate duration whenever start or end time changes
  const updateTimes = (newStart?: string, newEnd?: string) => {
    setStartTime(newStart);
    setEndTime(newEnd);
    if (newStart && newEnd) {
      const { minutes, formatted } = calculateDuration(newStart, newEnd);
      setTotalTimeMinutes(minutes);
      setTotalTimeFormatted(formatted);
    } else if (newStart && !newEnd) {
      setTotalTimeFormatted('');
      setTotalTimeMinutes(0);
    }
  };

  const handleStartJob = () => {
    const nowIso = new Date().toISOString();
    updateTimes(nowIso, undefined);
    setProductionStatus('Production');
  };

  const handleStopJob = () => {
    const currentStart = startTime || new Date().toISOString();
    const nowIso = new Date().toISOString();
    updateTimes(currentStart, nowIso);
    setProductionStatus('Completed');
  };

  const handleResetTiming = () => {
    updateTimes(undefined, undefined);
    setProductionStatus('Pending');
  };

  const handleSelectCustomer = (c: Customer) => {
    setCustomerId(c.id);
    setCustomerSearch(c.name);
    setIsCustomerDropdownOpen(false);

    const customerItems = items.filter((i) => i.customerId === c.id);
    if (customerItems.length === 1 && !itemId) {
      handleSelectItem(customerItems[0]);
    }
  };

  const handleSelectItem = (item: Item) => {
    setItemId(item.id);
    setItemSearch(item.name);
    setIsItemDropdownOpen(false);

    if (!customerId || customerId !== item.customerId) {
      setCustomerId(item.customerId);
      setCustomerSearch(item.customerName);
    }

    if (item.description && !description) {
      setDescription(item.description);
    }
    if (item.defaultPathLength && !pathLength) {
      setPathLength(item.defaultPathLength);
    }
    if (item.defaultThickness && !thickness) {
      setThickness(item.defaultThickness);
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 15 * 1024 * 1024) {
      setFormError('Drawing file size should be under 15MB.');
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      const dataUrl = event.target?.result as string;
      setDrawing({
        dataUrl,
        fileName: file.name,
        fileType: file.type || 'image/jpeg',
        fileSize: file.size,
        uploadedAt: new Date().toISOString(),
      });
      setFormError('');
    };
    reader.onerror = () => {
      setFormError('Failed to read file.');
    };
    reader.readAsDataURL(file);
    e.target.value = '';
  };

  const handleRemoveDrawing = () => {
    setDrawing(undefined);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError('');

    if (!customerSearch.trim()) {
      setFormError('Please select or enter a Customer Name.');
      return;
    }
    if (!itemSearch.trim()) {
      setFormError('Please select or enter an Item Name.');
      return;
    }
    if (quantity <= 0) {
      setFormError('Quantity must be at least 1.');
      return;
    }

    try {
      setIsSubmitting(true);

      let finalCustomerId = customerId;
      let finalCustomerName = customerSearch.trim();
      let matchedCust = customers.find(
        (c) => c.name.toLowerCase() === finalCustomerName.toLowerCase()
      );
      if (!matchedCust) {
        const newCust: Customer = {
          id: `cust-${Date.now()}`,
          name: finalCustomerName,
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
        };
        await onSaveCustomer(newCust);
        finalCustomerId = newCust.id;
      } else {
        finalCustomerId = matchedCust.id;
        finalCustomerName = matchedCust.name;
      }

      let finalItemId = itemId;
      let finalItemName = itemSearch.trim();
      let matchedItem = items.find(
        (i) =>
          i.name.toLowerCase() === finalItemName.toLowerCase() &&
          i.customerId === finalCustomerId
      );
      if (!matchedItem) {
        const newItem: Item = {
          id: `item-${Date.now()}`,
          name: finalItemName,
          customerId: finalCustomerId,
          customerName: finalCustomerName,
          productionStatus: productionStatus,
          description: description || undefined,
          defaultPathLength: pathLength || undefined,
          defaultThickness: thickness || undefined,
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
        };
        await onSaveItem(newItem);
        finalItemId = newItem.id;
      } else {
        finalItemId = matchedItem.id;
        finalItemName = matchedItem.name;
      }

      const job: Job = {
        id: jobToEdit ? jobToEdit.id : `job-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`,
        jobNumber: jobNumber.trim() || nextSerialNumberFormatted,
        serialNumberIndex: serialIndex,
        date: date,
        customerId: finalCustomerId,
        customerName: finalCustomerName,
        itemId: finalItemId,
        itemName: finalItemName,
        description: description.trim(),
        pathLength: pathLength.trim(),
        thickness: thickness.trim(),
        quantity: Number(quantity) || 1,
        remarks: remarks.trim(),
        drawing: drawing,
        productionStatus: productionStatus,
        startTime: startTime,
        endTime: endTime,
        totalTimeMinutes: totalTimeMinutes,
        totalTimeFormatted: totalTimeFormatted,
        createdAt: jobToEdit ? jobToEdit.createdAt : new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };

      await onSaveJob(job);
    } catch (err: any) {
      setFormError(err?.message || 'Failed to save job card.');
      setIsSubmitting(false);
    }
  };

  const filteredCustomers = customers.filter((c) =>
    c.name.toLowerCase().includes(customerSearch.toLowerCase())
  );

  const availableItems = customerId
    ? items.filter((i) => i.customerId === customerId)
    : items;

  const filteredItems = availableItems.filter((i) =>
    i.name.toLowerCase().includes(itemSearch.toLowerCase())
  );

  return (
    <div className="max-w-4xl mx-auto pb-20 pt-2 px-3 sm:px-6">
      {/* Formal White Card Container */}
      <div className="bg-white border border-slate-200 rounded-2xl p-5 sm:p-7 shadow-xs mb-5 text-slate-900">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 pb-5">
          <div className="flex items-center gap-3">
            <div>
              <div className="flex items-center gap-2">
                <span className="px-2 py-0.5 text-xs font-black uppercase tracking-wider bg-slate-900 text-white rounded">
                  ULTINO TOOL TECH
                </span>
                <span className="text-xs text-slate-500 font-mono">FORMAL JOB CARD</span>
              </div>
              <h1 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight mt-1">
                {jobToEdit ? `Edit Job Card: ${jobToEdit.jobNumber}` : 'New Digital Job Card'}
              </h1>
              <p className="text-xs text-slate-500">
                Wire EDM component parameters, drawing & timing records
              </p>
            </div>
          </div>

          {/* Auto Generated Sl. No. & Date Badges */}
          <div className="flex flex-wrap items-center gap-2">
            <div className="bg-amber-50/80 border border-amber-300 px-3.5 py-1.5 rounded-lg flex items-center gap-2">
              <Hash className="w-4 h-4 text-amber-700" />
              <div>
                <span className="text-[10px] uppercase font-bold text-amber-900 block -mb-0.5">
                  Job Number (Auto)
                </span>
                <span className="text-sm font-black text-amber-800 tracking-wider font-mono">
                  {jobNumber}
                </span>
              </div>
            </div>

            <div className="bg-slate-50 border border-slate-300 px-3.5 py-1.5 rounded-lg flex items-center gap-2">
              <Calendar className="w-4 h-4 text-slate-500" />
              <div>
                <span className="text-[10px] uppercase font-bold text-slate-500 block -mb-0.5">
                  Job Date
                </span>
                <input
                  type="date"
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  className="bg-transparent text-xs sm:text-sm font-semibold text-slate-800 focus:outline-none focus:text-slate-950"
                />
              </div>
            </div>
          </div>
        </div>

        {formError && (
          <div className="mt-4 p-3 bg-red-50 border border-red-200 text-red-700 text-xs sm:text-sm rounded-lg flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-red-600 shrink-0" />
            <span>{formError}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="mt-5 space-y-5">
          {/* Row 1: Customer & Item Selection */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Customer Field with Searchable Autocomplete */}
            <div className="relative">
              <div className="flex items-center justify-between mb-1.5">
                <label className="text-xs font-bold uppercase tracking-wider text-slate-700">
                  Customer Name <span className="text-amber-600">*</span>
                </label>
                <button
                  type="button"
                  onClick={() => setIsAddCustomerModalOpen(true)}
                  className="text-xs font-bold text-amber-700 hover:text-amber-800 flex items-center gap-1"
                >
                  <PlusCircle className="w-3.5 h-3.5" />
                  <span>+ Add New Customer</span>
                </button>
              </div>

              <div className="relative">
                <Building2 className="w-4 h-4 absolute left-3 top-3.5 text-slate-400" />
                <input
                  type="text"
                  value={customerSearch}
                  onChange={(e) => {
                    setCustomerSearch(e.target.value);
                    setIsCustomerDropdownOpen(true);
                  }}
                  onFocus={() => setIsCustomerDropdownOpen(true)}
                  placeholder="Type to search customer (e.g. ABC Eng)"
                  className="w-full bg-white border border-slate-300 rounded-lg pl-9 pr-8 py-2.5 text-sm text-slate-900 placeholder-slate-400 focus:outline-none focus:border-amber-500 focus:ring-1 focus:ring-amber-500"
                  required
                />
                {customerSearch && (
                  <button
                    type="button"
                    onClick={() => {
                      setCustomerSearch('');
                      setCustomerId('');
                    }}
                    className="absolute right-2.5 top-2.5 text-slate-400 hover:text-slate-600 text-xs"
                  >
                    ✕
                  </button>
                )}
              </div>

              {/* Autocomplete Dropdown */}
              {isCustomerDropdownOpen && filteredCustomers.length > 0 && (
                <div className="absolute z-20 left-0 right-0 mt-1 bg-white border border-slate-200 rounded-lg shadow-xl max-h-48 overflow-y-auto">
                  {filteredCustomers.map((c) => (
                    <div
                      key={c.id}
                      onClick={() => handleSelectCustomer(c)}
                      className="px-3.5 py-2.5 text-sm text-slate-800 hover:bg-amber-50 hover:text-amber-800 cursor-pointer border-b border-slate-100 last:border-b-0 flex items-center justify-between"
                    >
                      <span className="font-semibold">{c.name}</span>
                      {c.contactPerson && (
                        <span className="text-xs text-slate-500">{c.contactPerson}</span>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Item Field with Searchable Autocomplete */}
            <div className="relative">
              <div className="flex items-center justify-between mb-1.5">
                <label className="text-xs font-bold uppercase tracking-wider text-slate-700">
                  Item / Component <span className="text-amber-600">*</span>
                </label>
                <button
                  type="button"
                  onClick={() => setIsAddItemModalOpen(true)}
                  className="text-xs font-bold text-amber-700 hover:text-amber-800 flex items-center gap-1"
                >
                  <PlusCircle className="w-3.5 h-3.5" />
                  <span>+ Add New Item</span>
                </button>
              </div>

              <div className="relative">
                <Layers className="w-4 h-4 absolute left-3 top-3.5 text-slate-400" />
                <input
                  type="text"
                  value={itemSearch}
                  onChange={(e) => {
                    setItemSearch(e.target.value);
                    setIsItemDropdownOpen(true);
                  }}
                  onFocus={() => setIsItemDropdownOpen(true)}
                  placeholder="Select or enter item (e.g. Die Plate)"
                  className="w-full bg-white border border-slate-300 rounded-lg pl-9 pr-8 py-2.5 text-sm text-slate-900 placeholder-slate-400 focus:outline-none focus:border-amber-500 focus:ring-1 focus:ring-amber-500"
                  required
                />
                {itemSearch && (
                  <button
                    type="button"
                    onClick={() => {
                      setItemSearch('');
                      setItemId('');
                    }}
                    className="absolute right-2.5 top-2.5 text-slate-400 hover:text-slate-600 text-xs"
                  >
                    ✕
                  </button>
                )}
              </div>

              {/* Autocomplete Dropdown */}
              {isItemDropdownOpen && filteredItems.length > 0 && (
                <div className="absolute z-20 left-0 right-0 mt-1 bg-white border border-slate-200 rounded-lg shadow-xl max-h-48 overflow-y-auto">
                  {filteredItems.map((item) => (
                    <div
                      key={item.id}
                      onClick={() => handleSelectItem(item)}
                      className="px-3.5 py-2.5 text-sm text-slate-800 hover:bg-amber-50 hover:text-amber-800 cursor-pointer border-b border-slate-100 last:border-b-0 flex items-center justify-between"
                    >
                      <div>
                        <span className="font-semibold block">{item.name}</span>
                        {item.description && (
                          <span className="text-xs text-slate-500 block truncate max-w-xs">
                            {item.description}
                          </span>
                        )}
                      </div>
                      <span className="text-[10px] uppercase font-bold text-slate-600 px-1.5 py-0.5 bg-slate-100 rounded">
                        {item.customerName}
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Description with Voice Controller */}
          <VoiceDescriptionController
            value={description}
            onChange={setDescription}
            label="Description / Job Details"
            placeholder="Speak with voice controller or type: e.g. 12-cavity progressive punch die plate, D2 hardened steel..."
          />

          {/* Tech Specs: Path Length, Thickness, Quantity */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1.5">
                Path Length
              </label>
              <div className="relative">
                <Ruler className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
                <input
                  type="text"
                  value={pathLength}
                  onChange={(e) => setPathLength(e.target.value)}
                  placeholder="e.g. 640 mm"
                  className="w-full bg-white border border-slate-300 rounded-lg pl-9 pr-3 py-2 text-sm text-slate-900 placeholder-slate-400 focus:outline-none focus:border-amber-500"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1.5">
                Thickness
              </label>
              <div className="relative">
                <Ruler className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
                <input
                  type="text"
                  value={thickness}
                  onChange={(e) => setThickness(e.target.value)}
                  placeholder="e.g. 32 mm"
                  className="w-full bg-white border border-slate-300 rounded-lg pl-9 pr-3 py-2 text-sm text-slate-900 placeholder-slate-400 focus:outline-none focus:border-amber-500"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1.5">
                Quantity (Pcs) <span className="text-amber-600">*</span>
              </label>
              <div className="flex items-center">
                <button
                  type="button"
                  onClick={() => setQuantity((q) => Math.max(1, q - 1))}
                  className="w-10 h-10 flex items-center justify-center bg-slate-100 border border-slate-300 text-slate-700 rounded-l-lg hover:bg-slate-200 font-bold text-base"
                >
                  -
                </button>
                <input
                  type="number"
                  min="1"
                  value={quantity}
                  onChange={(e) => setQuantity(Math.max(1, parseInt(e.target.value) || 1))}
                  className="w-full bg-white border-y border-slate-300 py-2 text-center text-sm font-bold text-amber-700 focus:outline-none"
                  required
                />
                <button
                  type="button"
                  onClick={() => setQuantity((q) => q + 1)}
                  className="w-10 h-10 flex items-center justify-center bg-slate-100 border border-slate-300 text-slate-700 rounded-r-lg hover:bg-slate-200 font-bold text-base"
                >
                  +
                </button>
              </div>
            </div>
          </div>

          {/* Technical Drawing Attachment Section */}
          <div className="bg-slate-50 border border-slate-200 rounded-xl p-4">
            <div className="flex items-center justify-between mb-3">
              <div>
                <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider flex items-center gap-2">
                  <Camera className="w-4 h-4 text-amber-600" />
                  <span>Technical Drawing / Workpiece Photo</span>
                </h3>
                <p className="text-xs text-slate-500">
                  Attach blueprint, camera capture, or component photo
                </p>
              </div>
            </div>

            <input
              type="file"
              ref={cameraInputRef}
              accept="image/*"
              capture="environment"
              onChange={handleFileUpload}
              className="hidden"
            />
            <input
              type="file"
              ref={galleryInputRef}
              accept="image/*,application/pdf"
              onChange={handleFileUpload}
              className="hidden"
            />

            {drawing ? (
              <div className="flex flex-col sm:flex-row items-center gap-4 bg-white border border-slate-300 rounded-lg p-3">
                <div
                  onClick={() => setIsViewerOpen(true)}
                  className="relative group cursor-pointer w-32 h-24 sm:w-40 sm:h-28 bg-slate-100 rounded-md overflow-hidden border border-slate-300 flex items-center justify-center shrink-0"
                >
                  {drawing.fileType === 'application/pdf' ? (
                    <div className="flex flex-col items-center justify-center text-center p-2">
                      <FileText className="w-8 h-8 text-amber-600 mb-1" />
                      <span className="text-[10px] text-slate-700 truncate max-w-[120px]">
                        {drawing.fileName}
                      </span>
                      <span className="text-[9px] text-amber-700 font-bold">PDF DOCUMENT</span>
                    </div>
                  ) : (
                    <img
                      src={drawing.dataUrl}
                      alt="Drawing"
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                    />
                  )}
                  <div className="absolute inset-0 bg-slate-900/40 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity">
                    <Eye className="w-6 h-6 text-white" />
                  </div>
                </div>

                <div className="flex-1 w-full space-y-1">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-slate-900 truncate max-w-xs">
                      {drawing.fileName}
                    </span>
                    <span className="text-[10px] text-slate-500 uppercase">
                      {drawing.fileType.split('/')[1] || 'drawing'}
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-500">
                    Uploaded: {new Date(drawing.uploadedAt).toLocaleString()}
                  </p>
                  <div className="flex flex-wrap items-center gap-2 pt-2">
                    <button
                      type="button"
                      onClick={() => setIsViewerOpen(true)}
                      className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold rounded-md flex items-center gap-1.5 transition border border-slate-300"
                    >
                      <Eye className="w-3.5 h-3.5 text-amber-700" />
                      <span>Full View / Zoom</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => cameraInputRef.current?.click()}
                      className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-semibold rounded-md flex items-center gap-1.5 transition border border-slate-300"
                    >
                      <Camera className="w-3.5 h-3.5" />
                      <span>Retake</span>
                    </button>
                    <button
                      type="button"
                      onClick={handleRemoveDrawing}
                      className="px-3 py-1.5 bg-red-50 hover:bg-red-100 text-red-700 text-xs font-semibold rounded-md flex items-center gap-1.5 transition border border-red-200"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>Remove</span>
                    </button>
                  </div>
                </div>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <button
                  type="button"
                  onClick={() => cameraInputRef.current?.click()}
                  className="flex flex-col items-center justify-center p-4 bg-white hover:bg-slate-50 border border-dashed border-amber-400 hover:border-amber-600 rounded-lg group transition shadow-2xs"
                >
                  <div className="w-12 h-12 rounded-full bg-amber-50 flex items-center justify-center text-amber-600 group-hover:scale-110 transition-transform mb-2">
                    <Camera className="w-6 h-6 stroke-[2.2]" />
                  </div>
                  <span className="text-xs font-bold uppercase tracking-wider text-slate-800">
                    Take Photo with Camera
                  </span>
                  <span className="text-[11px] text-slate-500 mt-0.5">
                    Fast workshop phone camera capture
                  </span>
                </button>

                <button
                  type="button"
                  onClick={() => galleryInputRef.current?.click()}
                  className="flex flex-col items-center justify-center p-4 bg-white hover:bg-slate-50 border border-dashed border-slate-300 hover:border-slate-400 rounded-lg group transition shadow-2xs"
                >
                  <div className="w-12 h-12 rounded-full bg-slate-100 flex items-center justify-center text-slate-600 group-hover:scale-110 transition-transform mb-2">
                    <Upload className="w-6 h-6 stroke-[2.2]" />
                  </div>
                  <span className="text-xs font-bold uppercase tracking-wider text-slate-800">
                    Select Gallery or PDF Drawing
                  </span>
                  <span className="text-[11px] text-slate-500 mt-0.5">
                    Images (JPG, PNG, SVG) or CAD PDF
                  </span>
                </button>
              </div>
            )}
          </div>

          {/* Remarks */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1.5">
              Remarks & Workshop Notes
            </label>
            <input
              type="text"
              value={remarks}
              onChange={(e) => setRemarks(e.target.value)}
              placeholder="e.g. 0.25mm Brass wire, 4-pass cut, tolerance ±0.005mm, inspect surface Ra"
              className="w-full bg-white border border-slate-300 rounded-lg px-3.5 py-2.5 text-sm text-slate-900 placeholder-slate-400 focus:outline-none focus:border-amber-500"
            />
          </div>

          {/* Job Timing & Production Status */}
          <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 sm:p-5">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-200 pb-3 mb-4">
              <div>
                <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider flex items-center gap-2">
                  <Clock className="w-4 h-4 text-amber-600" />
                  <span>Production Status & Workshop Timing</span>
                </h3>
                <p className="text-xs text-slate-500">
                  Track machine running hours and mark completion
                </p>
              </div>

              {/* Status Radio / Badges */}
              <div className="flex items-center gap-1.5 bg-white p-1 rounded-lg border border-slate-300">
                {(['Pending', 'Production', 'Completed'] as const).map((st) => (
                  <button
                    key={st}
                    type="button"
                    onClick={() => {
                      setProductionStatus(st);
                      if (st === 'Production' && !startTime) {
                        setStartTime(new Date().toISOString());
                      }
                      if (st === 'Completed' && !endTime) {
                        setEndTime(new Date().toISOString());
                        if (startTime) {
                          const { formatted, minutes } = calculateDuration(startTime, new Date().toISOString());
                          setTotalTimeFormatted(formatted);
                          setTotalTimeMinutes(minutes);
                        }
                      }
                    }}
                    className={`px-3 py-1 text-xs font-bold uppercase rounded-md transition-all ${
                      productionStatus === st
                        ? st === 'Completed'
                          ? 'bg-emerald-600 text-white shadow-xs'
                          : st === 'Production'
                          ? 'bg-amber-500 text-slate-950 shadow-xs'
                          : 'bg-slate-900 text-white shadow-xs'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    {st}
                  </button>
                ))}
              </div>
            </div>

            {/* Quick Action Start / Stop Job Buttons */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-4">
              <button
                type="button"
                onClick={handleStartJob}
                disabled={productionStatus === 'Production' && !!startTime && !endTime}
                className="flex items-center justify-center gap-2 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-black py-3 rounded-lg text-xs sm:text-sm uppercase tracking-wider shadow-sm transition disabled:opacity-50"
              >
                <Play className="w-4 h-4 fill-slate-950" />
                <span>START JOB</span>
              </button>

              <button
                type="button"
                onClick={handleStopJob}
                disabled={productionStatus === 'Completed' && !!endTime}
                className="flex items-center justify-center gap-2 bg-gradient-to-r from-emerald-600 to-emerald-500 hover:from-emerald-500 hover:to-emerald-400 text-white font-black py-3 rounded-lg text-xs sm:text-sm uppercase tracking-wider shadow-sm transition disabled:opacity-50"
              >
                <Square className="w-4 h-4 fill-white" />
                <span>STOP JOB</span>
              </button>
            </div>

            {/* Timing Information Display */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 bg-white border border-slate-200 rounded-lg p-3">
              <div>
                <span className="text-[10px] uppercase font-bold text-slate-500 block mb-1">
                  Start Time
                </span>
                <span className="text-xs font-bold text-slate-800 font-mono">
                  {startTime ? new Date(startTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: true }) : 'Not Started'}
                </span>
              </div>

              <div>
                <span className="text-[10px] uppercase font-bold text-slate-500 block mb-1">
                  End Time
                </span>
                <span className="text-xs font-bold text-slate-800 font-mono">
                  {endTime ? new Date(endTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: true }) : (productionStatus === 'Production' ? 'Running...' : 'Not Ended')}
                </span>
              </div>

              <div>
                <span className="text-[10px] uppercase font-bold text-slate-500 block mb-1">
                  Total Production Time
                </span>
                <span className="text-sm font-black text-amber-700 font-mono">
                  {totalTimeFormatted || liveElapsed || '0 min'}
                </span>
              </div>
            </div>

            {/* Manual Correction Toggle */}
            <div className="mt-3 flex items-center justify-between">
              <button
                type="button"
                onClick={() => setShowManualTimeEdit(!showManualTimeEdit)}
                className="text-xs font-bold text-slate-600 hover:text-amber-700 underline"
              >
                {showManualTimeEdit ? 'Hide Manual Time Adjustment' : '✎ Manual Correction of Start/End Time'}
              </button>

              {(startTime || endTime) && (
                <button
                  type="button"
                  onClick={handleResetTiming}
                  className="text-xs text-red-600 hover:text-red-700 flex items-center gap-1 font-semibold"
                >
                  <RotateCcw className="w-3 h-3" />
                  <span>Reset Times</span>
                </button>
              )}
            </div>

            {showManualTimeEdit && (
              <div className="mt-3 grid grid-cols-1 sm:grid-cols-2 gap-3 bg-white p-3 rounded-lg border border-slate-300">
                <div>
                  <label className="block text-[10px] uppercase font-bold text-slate-600 mb-1">
                    Manual Start Date & Time
                  </label>
                  <input
                    type="datetime-local"
                    value={startTime ? startTime.slice(0, 16) : ''}
                    onChange={(e) => {
                      const iso = e.target.value ? new Date(e.target.value).toISOString() : undefined;
                      updateTimes(iso, endTime);
                    }}
                    className="w-full bg-slate-50 border border-slate-300 text-xs text-slate-900 rounded p-2 focus:outline-none focus:border-amber-500"
                  />
                </div>

                <div>
                  <label className="block text-[10px] uppercase font-bold text-slate-600 mb-1">
                    Manual End Date & Time
                  </label>
                  <input
                    type="datetime-local"
                    value={endTime ? endTime.slice(0, 16) : ''}
                    onChange={(e) => {
                      const iso = e.target.value ? new Date(e.target.value).toISOString() : undefined;
                      updateTimes(startTime, iso);
                    }}
                    className="w-full bg-slate-50 border border-slate-300 text-xs text-slate-900 rounded p-2 focus:outline-none focus:border-amber-500"
                  />
                </div>
              </div>
            )}
          </div>

          {/* Form Action Buttons */}
          <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-200">
            <button
              type="button"
              onClick={onCancel}
              className="px-5 py-2.5 text-xs sm:text-sm font-bold uppercase tracking-wider text-slate-600 hover:text-slate-900 rounded-lg hover:bg-slate-100 transition"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="flex items-center gap-2 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-black px-7 py-3 rounded-lg text-xs sm:text-sm uppercase tracking-wider shadow-sm active:scale-95 transition disabled:opacity-50"
            >
              <CheckCircle2 className="w-5 h-5 stroke-[2.5]" />
              <span>{jobToEdit ? 'Save Changes' : 'Create & Save Job Card'}</span>
            </button>
          </div>
        </form>
      </div>

      <CustomerModal
        isOpen={isAddCustomerModalOpen}
        onClose={() => setIsAddCustomerModalOpen(false)}
        onSave={async (newCust) => {
          await onSaveCustomer(newCust);
          handleSelectCustomer(newCust);
        }}
      />

      <ItemModal
        isOpen={isAddItemModalOpen}
        onClose={() => setIsAddItemModalOpen(false)}
        onSave={async (newItem) => {
          await onSaveItem(newItem);
          handleSelectItem(newItem);
        }}
        customers={customers}
        defaultCustomerId={customerId}
        onAddNewCustomer={() => {
          setIsAddItemModalOpen(false);
          setIsAddCustomerModalOpen(true);
        }}
      />

      {isViewerOpen && drawing && (
        <DrawingViewerModal
          drawing={drawing}
          title={`${jobNumber} - ${customerSearch || 'Job Drawing'}`}
          onClose={() => setIsViewerOpen(false)}
        />
      )}
    </div>
  );
};
