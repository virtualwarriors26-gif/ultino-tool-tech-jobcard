import React, { useState } from 'react';
import {
  Search,
  Eye,
  Edit3,
  Trash2,
  Printer,
  Calendar,
  Layers,
  Building2,
  PlusCircle,
  FileText,
  AlertTriangle,
} from 'lucide-react';
import { Job, Customer, Item } from '../types';
import { formatDateDisplay } from '../services/pdfGenerator';

interface JobHistoryProps {
  jobs: Job[];
  customers: Customer[];
  items: Item[];
  onNewJobClick: () => void;
  onEditJob: (job: Job) => void;
  onViewJob: (job: Job) => void;
  onDeleteJob: (jobId: string) => Promise<void>;
  onStatusChange: (job: Job, newStatus: 'Pending' | 'Production' | 'Completed') => void;
  onViewDrawing: (job: Job) => void;
  onPrintJob: (job: Job) => void;
}

export const JobHistory: React.FC<JobHistoryProps> = ({
  jobs,
  customers,
  items,
  onNewJobClick,
  onEditJob,
  onViewJob,
  onDeleteJob,
  onStatusChange,
  onViewDrawing,
  onPrintJob,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCustomerId, setSelectedCustomerId] = useState('');
  const [selectedItemId, setSelectedItemId] = useState('');
  const [selectedStatus, setSelectedStatus] = useState<string>('ALL');
  const [selectedMonth, setSelectedMonth] = useState<string>('ALL');
  const [selectedYear, setSelectedYear] = useState<string>('ALL');

  const [jobToDelete, setJobToDelete] = useState<Job | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);

  const years = Array.from(
    new Set(
      jobs
        .map((j) => (j.date ? j.date.split('-')[0] : null))
        .filter((y): y is string => Boolean(y))
    )
  ).sort((a, b) => b.localeCompare(a));

  const months = [
    { num: '01', name: 'January' },
    { num: '02', name: 'February' },
    { num: '03', name: 'March' },
    { num: '04', name: 'April' },
    { num: '05', name: 'May' },
    { num: '06', name: 'June' },
    { num: '07', name: 'July' },
    { num: '08', name: 'August' },
    { num: '09', name: 'September' },
    { num: '10', name: 'October' },
    { num: '11', name: 'November' },
    { num: '12', name: 'December' },
  ];

  const filteredJobs = jobs.filter((job) => {
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const match =
        job.jobNumber.toLowerCase().includes(q) ||
        job.customerName.toLowerCase().includes(q) ||
        job.itemName.toLowerCase().includes(q) ||
        job.description.toLowerCase().includes(q) ||
        job.remarks.toLowerCase().includes(q);
      if (!match) return false;
    }

    if (selectedCustomerId && job.customerId !== selectedCustomerId) return false;
    if (selectedItemId && job.itemId !== selectedItemId) return false;
    if (selectedStatus !== 'ALL' && job.productionStatus !== selectedStatus) return false;

    if (selectedYear !== 'ALL' && job.date) {
      const y = job.date.split('-')[0];
      if (y !== selectedYear) return false;
    }

    if (selectedMonth !== 'ALL' && job.date) {
      const m = job.date.split('-')[1];
      if (m !== selectedMonth) return false;
    }

    return true;
  });

  const handleDeleteConfirm = async () => {
    if (!jobToDelete) return;
    try {
      setIsDeleting(true);
      await onDeleteJob(jobToDelete.id);
      setJobToDelete(null);
    } finally {
      setIsDeleting(false);
    }
  };

  const handleResetFilters = () => {
    setSearchQuery('');
    setSelectedCustomerId('');
    setSelectedItemId('');
    setSelectedStatus('ALL');
    setSelectedMonth('ALL');
    setSelectedYear('ALL');
  };

  const hasActiveFilters =
    searchQuery ||
    selectedCustomerId ||
    selectedItemId ||
    selectedStatus !== 'ALL' ||
    selectedMonth !== 'ALL' ||
    selectedYear !== 'ALL';

  return (
    <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 py-6 pb-24 space-y-5">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white border border-slate-200 rounded-2xl p-5 sm:p-6 shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2 py-0.5 text-xs font-black uppercase tracking-wider bg-slate-900 text-white rounded">
              REGISTRY
            </span>
            <span className="text-xs text-slate-500 font-mono">COMPLETE ARCHIVE</span>
          </div>
          <h1 className="text-2xl font-black text-slate-900 tracking-tight mt-1">
            Job Cards History
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 font-medium">
            Search, filter, view parameters, print travel cards & update statuses
          </p>
        </div>

        <button
          onClick={onNewJobClick}
          className="flex items-center gap-2 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 text-slate-950 font-black px-4 py-2.5 rounded-xl text-xs sm:text-sm uppercase tracking-wider shadow-sm active:scale-95 transition"
        >
          <PlusCircle className="w-4 h-4 stroke-[2.5]" />
          <span>+ New Job</span>
        </button>
      </div>

      {/* Filter and Search Bar (Formal White) */}
      <div className="bg-white border border-slate-200 rounded-xl p-4 space-y-3 shadow-xs">
        <div className="relative">
          <Search className="w-4 h-4 absolute left-3.5 top-3.5 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search by Job Number (e.g. JOB 001), Customer, Item name, Description..."
            className="w-full bg-slate-50 border border-slate-300 rounded-lg pl-10 pr-4 py-2.5 text-sm text-slate-900 placeholder-slate-400 focus:outline-none focus:border-amber-500"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-3 top-3 text-slate-400 hover:text-slate-600 text-xs"
            >
              ✕
            </button>
          )}
        </div>

        {/* Filter Selectors */}
        <div className="grid grid-cols-2 sm:grid-cols-5 gap-2.5 pt-1">
          <div>
            <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-600 mb-1">
              Customer
            </label>
            <select
              value={selectedCustomerId}
              onChange={(e) => setSelectedCustomerId(e.target.value)}
              className="w-full bg-slate-50 border border-slate-300 rounded-lg px-2.5 py-2 text-xs text-slate-900 focus:outline-none focus:border-amber-500"
            >
              <option value="">All Customers</option>
              {customers.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-600 mb-1">
              Item
            </label>
            <select
              value={selectedItemId}
              onChange={(e) => setSelectedItemId(e.target.value)}
              className="w-full bg-slate-50 border border-slate-300 rounded-lg px-2.5 py-2 text-xs text-slate-900 focus:outline-none focus:border-amber-500"
            >
              <option value="">All Items</option>
              {items.map((i) => (
                <option key={i.id} value={i.id}>
                  {i.name}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-600 mb-1">
              Status
            </label>
            <select
              value={selectedStatus}
              onChange={(e) => setSelectedStatus(e.target.value)}
              className="w-full bg-slate-50 border border-slate-300 rounded-lg px-2.5 py-2 text-xs text-slate-900 focus:outline-none focus:border-amber-500"
            >
              <option value="ALL">All Statuses</option>
              <option value="Pending">Pending</option>
              <option value="Production">Production</option>
              <option value="Completed">Completed</option>
            </select>
          </div>

          <div>
            <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-600 mb-1">
              Month
            </label>
            <select
              value={selectedMonth}
              onChange={(e) => setSelectedMonth(e.target.value)}
              className="w-full bg-slate-50 border border-slate-300 rounded-lg px-2.5 py-2 text-xs text-slate-900 focus:outline-none focus:border-amber-500"
            >
              <option value="ALL">All Months</option>
              {months.map((m) => (
                <option key={m.num} value={m.num}>
                  {m.name}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-600 mb-1">
              Year
            </label>
            <select
              value={selectedYear}
              onChange={(e) => setSelectedYear(e.target.value)}
              className="w-full bg-slate-50 border border-slate-300 rounded-lg px-2.5 py-2 text-xs text-slate-900 focus:outline-none focus:border-amber-500"
            >
              <option value="ALL">All Years</option>
              {years.map((y) => (
                <option key={y} value={y}>
                  {y}
                </option>
              ))}
            </select>
          </div>
        </div>

        {hasActiveFilters && (
          <div className="flex items-center justify-between pt-2 border-t border-slate-100 text-xs">
            <span className="text-slate-500">
              Showing <span className="font-bold text-amber-700">{filteredJobs.length}</span> of{' '}
              {jobs.length} jobs
            </span>
            <button
              onClick={handleResetFilters}
              className="text-amber-700 hover:text-amber-800 font-bold underline"
            >
              Reset Filters
            </button>
          </div>
        )}
      </div>

      {filteredJobs.length === 0 ? (
        <div className="text-center py-12 bg-white border border-dashed border-slate-200 rounded-2xl">
          <FileText className="w-12 h-12 text-slate-400 mx-auto mb-2" />
          <h3 className="text-base font-bold text-slate-800">No Job Cards Found</h3>
          <p className="text-xs text-slate-500 mt-1">Try clearing filters or search query.</p>
          <button
            onClick={onNewJobClick}
            className="mt-4 px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs uppercase tracking-wider rounded-lg transition"
          >
            + Create New Job
          </button>
        </div>
      ) : (
        <>
          {/* PC Table Layout (Formal White) */}
          <div className="hidden md:block bg-white border border-slate-200 rounded-xl overflow-hidden shadow-xs">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs text-slate-700">
                <thead className="bg-slate-50 text-slate-700 uppercase tracking-wider border-b border-slate-200 text-[11px] font-bold">
                  <tr>
                    <th className="py-3 px-4">SL. NO.</th>
                    <th className="py-3 px-4">DATE</th>
                    <th className="py-3 px-4">CUSTOMER</th>
                    <th className="py-3 px-4">ITEM / SPEC</th>
                    <th className="py-3 px-4 text-center">PATH</th>
                    <th className="py-3 px-4 text-center">THK</th>
                    <th className="py-3 px-4 text-center">QTY</th>
                    <th className="py-3 px-4 text-center">TIME</th>
                    <th className="py-3 px-4 text-center">STATUS</th>
                    <th className="py-3 px-4 text-center">DWG</th>
                    <th className="py-3 px-4 text-right">ACTIONS</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filteredJobs.map((job) => (
                    <tr
                      key={job.id}
                      className="hover:bg-slate-50 transition group cursor-pointer"
                      onClick={() => onViewJob(job)}
                    >
                      <td className="py-3 px-4 font-black text-slate-900 font-mono text-sm whitespace-nowrap">
                        {job.jobNumber}
                      </td>

                      <td className="py-3 px-4 whitespace-nowrap text-slate-600 font-mono text-[11px]">
                        {formatDateDisplay(job.date)}
                      </td>

                      <td className="py-3 px-4 font-bold text-slate-900 whitespace-nowrap">
                        {job.customerName}
                      </td>

                      <td className="py-3 px-4">
                        <span className="font-bold text-slate-800 block truncate max-w-xs">
                          {job.itemName}
                        </span>
                        {job.description && (
                          <span className="text-[10px] text-slate-500 block truncate max-w-xs font-medium">
                            {job.description}
                          </span>
                        )}
                      </td>

                      <td className="py-3 px-4 text-center whitespace-nowrap font-mono text-slate-700">
                        {job.pathLength || '-'}
                      </td>

                      <td className="py-3 px-4 text-center whitespace-nowrap font-mono text-slate-700">
                        {job.thickness || '-'}
                      </td>

                      <td className="py-3 px-4 text-center font-bold text-amber-700 whitespace-nowrap">
                        {job.quantity}
                      </td>

                      <td className="py-3 px-4 text-center whitespace-nowrap font-mono text-[11px] text-slate-700">
                        {job.totalTimeFormatted || '-'}
                      </td>

                      <td
                        className="py-3 px-4 text-center whitespace-nowrap"
                        onClick={(e) => e.stopPropagation()}
                      >
                        <select
                          value={job.productionStatus}
                          onChange={(e) =>
                            onStatusChange(
                              job,
                              e.target.value as 'Pending' | 'Production' | 'Completed'
                            )
                          }
                          className={`text-[10px] font-bold uppercase rounded px-2 py-1 border focus:outline-none ${
                            job.productionStatus === 'Completed'
                              ? 'bg-emerald-50 text-emerald-800 border-emerald-300'
                              : job.productionStatus === 'Production'
                              ? 'bg-amber-50 text-amber-800 border-amber-300'
                              : 'bg-slate-100 text-slate-700 border-slate-300'
                          }`}
                        >
                          <option value="Pending">Pending</option>
                          <option value="Production">Production</option>
                          <option value="Completed">Completed</option>
                        </select>
                      </td>

                      <td
                        className="py-3 px-4 text-center whitespace-nowrap"
                        onClick={(e) => e.stopPropagation()}
                      >
                        {job.drawing ? (
                          <button
                            onClick={() => onViewDrawing(job)}
                            className="p-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 hover:text-amber-700 rounded-md border border-slate-300 transition"
                            title="View Drawing"
                          >
                            <Eye className="w-3.5 h-3.5" />
                          </button>
                        ) : (
                          <span className="text-slate-400 text-xs">-</span>
                        )}
                      </td>

                      <td
                        className="py-3 px-4 text-right whitespace-nowrap"
                        onClick={(e) => e.stopPropagation()}
                      >
                        <div className="flex items-center justify-end gap-1">
                          <button
                            onClick={() => onPrintJob(job)}
                            className="p-1.5 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded transition"
                            title="Print Work Order Card"
                          >
                            <Printer className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => onEditJob(job)}
                            className="p-1.5 text-slate-600 hover:text-amber-700 hover:bg-slate-100 rounded transition"
                            title="Edit Job Card"
                          >
                            <Edit3 className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => setJobToDelete(job)}
                            className="p-1.5 text-slate-600 hover:text-red-600 hover:bg-slate-100 rounded transition"
                            title="Delete Job"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Mobile Cards (Formal White) */}
          <div className="grid grid-cols-1 gap-3 md:hidden">
            {filteredJobs.map((job) => (
              <div
                key={job.id}
                onClick={() => onViewJob(job)}
                className="bg-white border border-slate-200 hover:border-slate-300 rounded-xl p-4 shadow-2xs cursor-pointer active:scale-[0.99] transition"
              >
                <div className="flex items-center justify-between mb-1.5">
                  <span className="px-2 py-0.5 text-xs font-black bg-slate-900 text-amber-400 rounded tracking-wider font-mono">
                    {job.jobNumber}
                  </span>
                  <div className="flex items-center gap-2">
                    <span className="text-[11px] font-mono text-slate-500">
                      {formatDateDisplay(job.date)}
                    </span>
                    <span
                      className={`px-2 py-0.5 text-[10px] font-black uppercase rounded ${
                        job.productionStatus === 'Completed'
                          ? 'bg-emerald-50 text-emerald-800 border border-emerald-300'
                          : job.productionStatus === 'Production'
                          ? 'bg-amber-50 text-amber-800 border border-amber-300'
                          : 'bg-slate-100 text-slate-700 border border-slate-300'
                      }`}
                    >
                      {job.productionStatus}
                    </span>
                  </div>
                </div>

                <h3 className="text-base font-bold text-slate-900 leading-snug">{job.itemName}</h3>
                <p className="text-xs font-bold text-amber-700">{job.customerName}</p>

                {job.description && (
                  <p className="text-xs text-slate-500 line-clamp-1 mt-1">{job.description}</p>
                )}

                <div className="flex items-center justify-between text-xs text-slate-700 bg-slate-50 px-3 py-2 rounded-lg border border-slate-200 my-2.5">
                  <span>
                    Path: <b className="text-slate-900">{job.pathLength || '-'}</b>
                  </span>
                  <span>
                    Thk: <b className="text-slate-900">{job.thickness || '-'}</b>
                  </span>
                  <span>
                    Qty: <b className="text-amber-700">{job.quantity}</b>
                  </span>
                  <span>
                    Time: <b className="text-slate-900">{job.totalTimeFormatted || '-'}</b>
                  </span>
                </div>

                <div
                  className="flex items-center justify-between pt-2 border-t border-slate-100 text-xs text-slate-600"
                  onClick={(e) => e.stopPropagation()}
                >
                  <div className="flex items-center gap-2">
                    {job.drawing && (
                      <button
                        onClick={() => onViewDrawing(job)}
                        className="px-2 py-1 bg-slate-100 text-amber-800 font-bold rounded flex items-center gap-1 text-[11px] border border-slate-200"
                      >
                        <Eye className="w-3 h-3" />
                        <span>Drawing</span>
                      </button>
                    )}
                    <button
                      onClick={() => onPrintJob(job)}
                      className="px-2 py-1 bg-slate-100 text-slate-700 hover:text-slate-900 font-semibold rounded flex items-center gap-1 text-[11px] border border-slate-200"
                    >
                      <Printer className="w-3 h-3" />
                      <span>Print</span>
                    </button>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => onEditJob(job)}
                      className="px-3 py-1 bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold rounded text-xs uppercase border border-slate-200"
                    >
                      Edit
                    </button>
                    <button
                      onClick={() => setJobToDelete(job)}
                      className="p-1.5 text-slate-500 hover:text-red-600 rounded hover:bg-slate-100"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </>
      )}

      {/* Safety Confirmation Modal (Formal White) */}
      {jobToDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 backdrop-blur-xs p-4">
          <div className="relative w-full max-w-md bg-white border border-slate-200 rounded-2xl p-6 shadow-xl space-y-4">
            <div className="flex items-center gap-3 text-red-600">
              <div className="p-2 bg-red-50 border border-red-200 rounded-xl">
                <AlertTriangle className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-base font-bold text-slate-900">Delete Job Card</h3>
                <p className="text-xs text-slate-500">Confirmation Required</p>
              </div>
            </div>

            <p className="text-xs sm:text-sm text-slate-700">
              Are you sure you want to delete{' '}
              <strong className="text-slate-900 font-mono">{jobToDelete.jobNumber}</strong> (
              {jobToDelete.customerName} - {jobToDelete.itemName})?
            </p>

            <div className="p-3 bg-slate-50 border border-slate-200 rounded-lg text-xs text-slate-600">
              ✓ Customer and Item master database records will <strong>remain safe</strong>.
              <br />
              ✕ This specific job card and its attached drawing will be deleted.
            </div>

            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={() => setJobToDelete(null)}
                className="px-4 py-2 text-xs font-semibold uppercase text-slate-600 hover:text-slate-900 rounded-lg hover:bg-slate-100 transition"
              >
                Cancel
              </button>
              <button
                type="button"
                disabled={isDeleting}
                onClick={handleDeleteConfirm}
                className="px-5 py-2.5 bg-red-600 hover:bg-red-500 text-white font-bold text-xs uppercase tracking-wider rounded-lg shadow-sm transition disabled:opacity-50"
              >
                {isDeleting ? 'Deleting...' : 'Confirm Delete'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
