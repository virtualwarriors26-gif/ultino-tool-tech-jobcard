import React, { useState, useRef } from 'react';
import {
  Database,
  Download,
  Upload,
  CheckCircle2,
  AlertTriangle,
  Copy,
  Check,
  ShieldCheck,
  Smartphone,
  Laptop,
  FolderArchive,
  Terminal,
  FileCode,
} from 'lucide-react';
import { BackupData, Customer, Item, Job } from '../types';
import { StorageService } from '../services/storage';

interface BackupSettingsProps {
  customers: Customer[];
  items: Item[];
  jobs: Job[];
  onRefreshData: () => Promise<void>;
}

export const BackupSettings: React.FC<BackupSettingsProps> = ({
  customers,
  items,
  jobs,
  onRefreshData,
}) => {
  const [isExporting, setIsExporting] = useState(false);
  const [successMessage, setSuccessMessage] = useState('');
  const [errorMessage, setErrorMessage] = useState('');

  const [pendingBackup, setPendingBackup] = useState<BackupData | null>(null);
  const [restoreMode, setRestoreMode] = useState<'replace' | 'merge'>('replace');
  const [isRestoring, setIsRestoring] = useState(false);

  const [isCopied, setIsCopied] = useState(false);
  const [showSyncCodeModal, setShowSyncCodeModal] = useState(false);
  const [syncCodeInput, setSyncCodeInput] = useState('');

  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleExportBackup = async () => {
    try {
      setIsExporting(true);
      setErrorMessage('');
      const backupData = await StorageService.exportBackup();
      const jsonString = JSON.stringify(backupData, null, 2);
      const blob = new Blob([jsonString], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      const dateStr = new Date().toISOString().split('T')[0];
      link.href = url;
      link.download = `ULTINO_TOOL_TECH_Backup_${dateStr}.json`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);

      setSuccessMessage(
        `Backup exported successfully! Contains ${backupData.customers.length} customers, ${backupData.items.length} items, and ${backupData.jobs.length} jobs with drawings.`
      );
    } catch (err: any) {
      setErrorMessage(err?.message || 'Failed to export backup.');
    } finally {
      setIsExporting(false);
    }
  };

  const handleFileSelected = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const parsed = JSON.parse(event.target?.result as string) as BackupData;
        if (!parsed || !Array.isArray(parsed.jobs) || !Array.isArray(parsed.customers)) {
          throw new Error('Selected file is not a valid ULTINO TOOL TECH backup JSON.');
        }
        setPendingBackup(parsed);
        setErrorMessage('');
      } catch (err: any) {
        setErrorMessage(err?.message || 'Invalid backup JSON file.');
      }
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  const handleConfirmRestore = async () => {
    if (!pendingBackup) return;
    try {
      setIsRestoring(true);
      setErrorMessage('');
      await StorageService.restoreBackup(pendingBackup, restoreMode);
      await onRefreshData();
      setSuccessMessage(
        `Successfully restored database! Active records: ${pendingBackup.customers.length} customers, ${pendingBackup.items.length} items, ${pendingBackup.jobs.length} jobs.`
      );
      setPendingBackup(null);
    } catch (err: any) {
      setErrorMessage(err?.message || 'Failed to restore backup.');
    } finally {
      setIsRestoring(false);
    }
  };

  const handleResetToSample = async () => {
    if (
      !window.confirm(
        'Are you sure you want to reset the database to initial workshop sample data? All current custom records will be replaced.'
      )
    ) {
      return;
    }
    try {
      await StorageService.resetToDefaultData();
      await onRefreshData();
      setSuccessMessage('Database reset to initial ULTINO TOOL TECH workshop configuration.');
    } catch (err: any) {
      setErrorMessage(err?.message || 'Failed to reset database.');
    }
  };

  const handleCopySyncText = async () => {
    try {
      const backupData = await StorageService.exportBackup();
      const json = JSON.stringify(backupData);
      await navigator.clipboard.writeText(json);
      setIsCopied(true);
      setTimeout(() => setIsCopied(false), 3000);
    } catch {
      setErrorMessage('Could not copy to clipboard.');
    }
  };

  const handleApplySyncText = async () => {
    if (!syncCodeInput.trim()) return;
    try {
      const parsed = JSON.parse(syncCodeInput.trim()) as BackupData;
      if (!parsed || !Array.isArray(parsed.jobs)) {
        throw new Error('Invalid sync code format.');
      }
      setPendingBackup(parsed);
      setShowSyncCodeModal(false);
      setSyncCodeInput('');
    } catch (err: any) {
      setErrorMessage(err?.message || 'Invalid sync text.');
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-3 sm:px-6 py-6 pb-24 space-y-6">
      {/* Header Banner */}
      <div className="bg-white border border-slate-200 rounded-2xl p-5 sm:p-6 shadow-xs">
        <div className="flex items-center gap-2">
          <span className="px-2 py-0.5 text-xs font-black uppercase tracking-wider bg-slate-900 text-white rounded">
            DATA SAFETY
          </span>
          <span className="text-xs text-slate-500 font-mono">PERMANENT STORAGE & SYNC</span>
        </div>
        <h1 className="text-2xl font-black text-slate-900 tracking-tight mt-1 flex items-center gap-2">
          <Database className="w-6 h-6 text-emerald-600" />
          <span>Backup & Database Storage</span>
        </h1>
        <p className="text-xs sm:text-sm text-slate-500 mt-0.5 font-medium">
          Permanent browser IndexedDB storage engine, offline resilience, and cross-device sync
        </p>
      </div>

      {/* Notifications */}
      {successMessage && (
        <div className="p-4 bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs sm:text-sm rounded-xl flex items-center gap-2 shadow-2xs">
          <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
          <span>{successMessage}</span>
        </div>
      )}

      {errorMessage && (
        <div className="p-4 bg-red-50 border border-red-200 text-red-700 text-xs sm:text-sm rounded-xl flex items-center gap-2 shadow-2xs">
          <AlertTriangle className="w-5 h-5 text-red-600 shrink-0" />
          <span>{errorMessage}</span>
        </div>
      )}

      {/* Storage Health Indicator Card */}
      <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-emerald-50 text-emerald-700 rounded-lg border border-emerald-200">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider">
                Permanent Local Database Engine
              </h3>
              <p className="text-xs text-slate-500">IndexedDB Storage (Client-side Persistent)</p>
            </div>
          </div>
          <span className="px-2.5 py-1 text-[10px] font-black uppercase tracking-wider bg-emerald-100 text-emerald-800 border border-emerald-300 rounded-full flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-emerald-600" />
            Storage Active
          </span>
        </div>

        <p className="text-xs text-slate-600 leading-relaxed">
          Your customer master, item master, job cards, timestamps, and attached drawing photos
          are permanently persisted in your browser's dedicated IndexedDB storage.
          Data remains permanently intact after closing the app, refreshing the page, or restarting
          your phone or laptop.
        </p>

        <div className="grid grid-cols-3 gap-2 pt-2 text-center">
          <div className="bg-slate-50 p-2.5 rounded-lg border border-slate-200">
            <span className="text-[10px] uppercase font-bold text-slate-500 block">Customers</span>
            <span className="text-base font-black text-slate-900">{customers.length} records</span>
          </div>
          <div className="bg-slate-50 p-2.5 rounded-lg border border-slate-200">
            <span className="text-[10px] uppercase font-bold text-slate-500 block">Items</span>
            <span className="text-base font-black text-slate-900">{items.length} records</span>
          </div>
          <div className="bg-slate-50 p-2.5 rounded-lg border border-slate-200">
            <span className="text-[10px] uppercase font-bold text-slate-500 block">Job Cards</span>
            <span className="text-base font-black text-amber-700">{jobs.length} records</span>
          </div>
        </div>
      </div>

      {/* Online & Multi-Device Status */}
      <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-emerald-50 border border-emerald-200 flex items-center justify-center shrink-0 text-emerald-600">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-bold text-slate-900">Online Cloud & Device Readiness</h3>
                <span className="px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider bg-emerald-100 text-emerald-800 border border-emerald-300 rounded-full flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-600 animate-pulse" />
                  Live Online
                </span>
              </div>
              <p className="text-xs text-slate-500 mt-1 max-w-xl">
                This application is deployed and works live online in any web browser on smartphones, tablets, and desktop computers across your workshop without installing any software.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 text-xs font-semibold text-slate-600 bg-slate-50 px-3 py-2 rounded-lg border border-slate-200">
            <Smartphone className="w-4 h-4 text-slate-500" />
            <Laptop className="w-4 h-4 text-slate-500" />
            <span>Mobile & Desktop Compatible</span>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-3 pt-2 border-t border-slate-100 text-xs text-slate-600">
          <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
            <p className="font-bold text-slate-900 mb-0.5">🌐 Instant Online Access</p>
            <p className="text-slate-500">Open the URL from any machine or phone connected to the internet.</p>
          </div>
          <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
            <p className="font-bold text-slate-900 mb-0.5">⚡ Offline Tolerance</p>
            <p className="text-slate-500">Runs smoothly even if workshop Wi-Fi or mobile data temporarily drops.</p>
          </div>
          <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
            <p className="font-bold text-slate-900 mb-0.5">💾 1-Click JSON Backup</p>
            <p className="text-slate-500">Export your complete database anytime to transfer between workshop computers.</p>
          </div>
        </div>
      </div>

      {/* Export / Restore Actions */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs flex flex-col justify-between space-y-4">
          <div>
            <div className="flex items-center gap-2 mb-2 text-amber-700 font-bold uppercase text-xs tracking-wider">
              <Download className="w-4 h-4" />
              <span>Export Full Backup</span>
            </div>
            <h3 className="text-base font-bold text-slate-900">Download Backup File (.json)</h3>
            <p className="text-xs text-slate-500 mt-1">
              Exports all customers, items, job cards, drawings/photos and machining timings into a
              portable JSON file. Save this to your phone, Google Drive or PC.
            </p>
          </div>

          <button
            onClick={handleExportBackup}
            disabled={isExporting}
            className="w-full flex items-center justify-center gap-2 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 text-slate-950 font-black py-3 rounded-xl text-xs uppercase tracking-wider shadow-sm transition disabled:opacity-50"
          >
            <Download className="w-4 h-4 stroke-[2.5]" />
            <span>{isExporting ? 'Exporting...' : 'Export Backup File'}</span>
          </button>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs flex flex-col justify-between space-y-4">
          <div>
            <div className="flex items-center gap-2 mb-2 text-emerald-700 font-bold uppercase text-xs tracking-wider">
              <Upload className="w-4 h-4" />
              <span>Restore Backup</span>
            </div>
            <h3 className="text-base font-bold text-slate-900">Import Backup File (.json)</h3>
            <p className="text-xs text-slate-500 mt-1">
              Select an exported backup file to restore records. We will show a preview and ask for
              confirmation before any changes are applied.
            </p>
          </div>

          <input
            type="file"
            ref={fileInputRef}
            accept=".json,application/json"
            onChange={handleFileSelected}
            className="hidden"
          />

          <button
            onClick={() => fileInputRef.current?.click()}
            className="w-full flex items-center justify-center gap-2 bg-slate-100 hover:bg-slate-200 text-slate-800 font-black py-3 rounded-xl text-xs uppercase tracking-wider border border-slate-300 transition shadow-2xs"
          >
            <Upload className="w-4 h-4" />
            <span>Select File to Restore</span>
          </button>
        </div>
      </div>

      {/* Complete Project Source Code (.ZIP) Download Section */}
      <div className="bg-gradient-to-br from-slate-900 via-slate-950 to-slate-900 border border-slate-800 rounded-xl p-5 sm:p-6 text-white shadow-md relative overflow-hidden">
        {/* Subtle decorative background glow */}
        <div className="absolute top-0 right-0 -mt-10 -mr-10 w-44 h-44 bg-amber-500/10 rounded-full blur-2xl pointer-events-none" />

        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6 relative z-10">
          <div className="space-y-2 max-w-2xl">
            <div className="flex items-center gap-2 text-amber-400 font-bold uppercase text-xs tracking-wider">
              <FolderArchive className="w-4 h-4" />
              <span>Full Application Source Code Package</span>
            </div>
            <h3 className="text-lg sm:text-xl font-black text-white tracking-tight flex items-center gap-2">
              <span>Download Project ZIP</span>
              <span className="px-2 py-0.5 text-[10px] font-bold bg-amber-400/20 text-amber-400 border border-amber-400/30 rounded uppercase tracking-wider">
                Ready to Run (~989 KB)
              </span>
            </h3>
            <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
              Contains the complete, uncompiled source code for ULTINO TOOL TECH: React 19, TypeScript,
              Vite, Tailwind CSS, real-time Voice Controller (Audio-to-Words), Wire-Cut EDM calculations,
              production floor timers, and PDF billing generator.
            </p>
            <div className="flex flex-wrap gap-2 pt-1 text-[11px] text-slate-400 font-mono">
              <span className="bg-slate-800/80 px-2 py-1 rounded border border-slate-700/60 flex items-center gap-1.5">
                <FileCode className="w-3.5 h-3.5 text-amber-400" />
                src/ & public/
              </span>
              <span className="bg-slate-800/80 px-2 py-1 rounded border border-slate-700/60 flex items-center gap-1.5">
                <Terminal className="w-3.5 h-3.5 text-emerald-400" />
                npm install && npm run dev
              </span>
              <span className="bg-slate-800/80 px-2 py-1 rounded border border-slate-700/60">
                README.md instructions
              </span>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row lg:flex-col gap-3 shrink-0">
            <a
              href="/jobcard-app.zip"
              download="ultino-tool-tech-jobcard-app.zip"
              className="flex items-center justify-center gap-2.5 bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 active:scale-95 text-slate-950 font-black px-6 py-3.5 rounded-xl text-xs sm:text-sm uppercase tracking-wider shadow-lg shadow-amber-500/20 transition-all text-center"
            >
              <Download className="w-4 h-4 stroke-[2.5]" />
              <span>Download ZIP (.zip)</span>
            </a>
            <a
              href="/ultino-jobcard-app.zip"
              download="ultino-jobcard-backup.zip"
              className="text-center text-[11px] font-semibold text-slate-400 hover:text-amber-400 underline decoration-slate-600 underline-offset-4 transition"
            >
              Alternative Mirror Link
            </a>
          </div>
        </div>
      </div>

      {/* Phone <-> PC Sync Section */}
      <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs space-y-4">
        <div className="flex items-center gap-3">
          <div className="flex items-center -space-x-2 text-amber-600">
            <Smartphone className="w-6 h-6" />
            <Laptop className="w-6 h-6 text-slate-400" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider">
              Phone ⇄ PC Browser Sync Guide
            </h3>
            <p className="text-xs text-slate-500">How to sync data between workshop phone and PC</p>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs text-slate-700">
          <div className="bg-slate-50 p-3 rounded-lg border border-slate-200 space-y-1">
            <span className="font-bold text-amber-800 block">Method A: Backup File Transfer</span>
            <p className="text-slate-600 leading-relaxed">
              1. Tap <strong>Export Backup File</strong> on your phone.
              <br />
              2. Send the downloaded JSON to your PC via WhatsApp Web, Email, or USB.
              <br />
              3. Open this app on PC and click <strong>Select File to Restore</strong>.
            </p>
          </div>

          <div className="bg-slate-50 p-3 rounded-lg border border-slate-200 space-y-1">
            <span className="font-bold text-emerald-800 block">Method B: Direct Clipboard Code</span>
            <p className="text-slate-600 leading-relaxed">
              Copy complete database text directly to paste across devices.
            </p>
            <div className="pt-2 flex items-center gap-2">
              <button
                onClick={handleCopySyncText}
                className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-800 text-[11px] font-bold uppercase rounded flex items-center gap-1 transition border border-slate-300"
              >
                {isCopied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{isCopied ? 'Copied to Clipboard!' : 'Copy Sync Text'}</span>
              </button>
              <button
                onClick={() => setShowSyncCodeModal(true)}
                className="px-3 py-1.5 bg-amber-50 hover:bg-amber-100 text-amber-800 text-[11px] font-bold uppercase rounded transition border border-amber-200"
              >
                Paste Sync Text
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Reset Demo Data */}
      <div className="bg-white border border-red-200 rounded-xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-2xs">
        <div>
          <span className="text-xs font-bold text-red-700 uppercase tracking-wider block">
            Reset Demo Data
          </span>
          <p className="text-xs text-slate-500">
            Re-populates default toolroom sample customers and job cards for testing.
          </p>
        </div>
        <button
          onClick={handleResetToSample}
          className="px-4 py-2 bg-red-50 hover:bg-red-100 text-red-700 text-xs font-bold uppercase tracking-wider rounded-lg border border-red-300 transition"
        >
          Reset to Sample Data
        </button>
      </div>

      {/* Restore Confirmation Modal */}
      {pendingBackup && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 backdrop-blur-xs p-4">
          <div className="relative w-full max-w-lg bg-white border border-slate-200 rounded-2xl p-6 shadow-xl space-y-4">
            <div className="flex items-center gap-3 text-amber-600">
              <div className="p-2 bg-amber-50 border border-amber-200 rounded-xl">
                <AlertTriangle className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-base font-bold text-slate-900">Confirm Database Restore</h3>
                <p className="text-xs text-slate-500">Review backup summary before restoring</p>
              </div>
            </div>

            <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 space-y-2 text-xs">
              <div className="flex justify-between text-slate-600">
                <span>Backup Created:</span>
                <span className="font-mono text-slate-900">
                  {new Date(pendingBackup.exportedAt).toLocaleString()}
                </span>
              </div>
              <div className="flex justify-between text-slate-600">
                <span>Customers:</span>
                <span className="font-bold text-slate-900">{pendingBackup.customers.length}</span>
              </div>
              <div className="flex justify-between text-slate-600">
                <span>Items:</span>
                <span className="font-bold text-slate-900">{pendingBackup.items.length}</span>
              </div>
              <div className="flex justify-between text-slate-600">
                <span>Job Cards:</span>
                <span className="font-bold text-amber-700">{pendingBackup.jobs.length}</span>
              </div>
            </div>

            <div className="space-y-2">
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider">
                Restore Mode
              </label>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => setRestoreMode('replace')}
                  className={`p-3 rounded-lg border text-left text-xs transition ${
                    restoreMode === 'replace'
                      ? 'bg-amber-50 border-amber-400 text-slate-900'
                      : 'bg-white border-slate-200 text-slate-500 hover:text-slate-800'
                  }`}
                >
                  <span className="font-bold block text-amber-800 mb-0.5">Replace Entire Data</span>
                  <span className="text-[11px] text-slate-500 block">
                    Wipes current database and replaces with this backup.
                  </span>
                </button>

                <button
                  type="button"
                  onClick={() => setRestoreMode('merge')}
                  className={`p-3 rounded-lg border text-left text-xs transition ${
                    restoreMode === 'merge'
                      ? 'bg-emerald-50 border-emerald-400 text-slate-900'
                      : 'bg-white border-slate-200 text-slate-500 hover:text-slate-800'
                  }`}
                >
                  <span className="font-bold block text-emerald-800 mb-0.5">Merge with Existing</span>
                  <span className="text-[11px] text-slate-500 block">
                    Keeps current jobs and inserts new ones from backup.
                  </span>
                </button>
              </div>
            </div>

            <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setPendingBackup(null)}
                className="px-4 py-2 text-xs font-semibold uppercase text-slate-600 hover:text-slate-900 rounded-lg hover:bg-slate-100 transition"
              >
                Cancel
              </button>
              <button
                type="button"
                disabled={isRestoring}
                onClick={handleConfirmRestore}
                className="px-5 py-2.5 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 text-slate-950 font-black text-xs uppercase tracking-wider rounded-lg shadow-sm transition disabled:opacity-50"
              >
                {isRestoring ? 'Restoring...' : 'Confirm & Apply Restore'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Paste Sync Text Modal */}
      {showSyncCodeModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 backdrop-blur-xs p-4">
          <div className="relative w-full max-w-lg bg-white border border-slate-200 rounded-2xl p-6 shadow-xl space-y-4">
            <h3 className="text-base font-bold text-slate-900">Paste Sync Text</h3>
            <p className="text-xs text-slate-500">
              Paste the JSON data exported or copied from another phone or PC:
            </p>
            <textarea
              rows={6}
              value={syncCodeInput}
              onChange={(e) => setSyncCodeInput(e.target.value)}
              placeholder="Paste JSON text here..."
              className="w-full bg-slate-50 border border-slate-300 rounded-lg p-3 text-xs text-slate-900 font-mono focus:outline-none focus:border-amber-500"
            />
            <div className="flex items-center justify-end gap-2">
              <button
                type="button"
                onClick={() => setShowSyncCodeModal(false)}
                className="px-4 py-2 text-xs font-semibold uppercase text-slate-600 hover:text-slate-900"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleApplySyncText}
                className="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs uppercase rounded-lg shadow-sm"
              >
                Verify & Load Backup
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
