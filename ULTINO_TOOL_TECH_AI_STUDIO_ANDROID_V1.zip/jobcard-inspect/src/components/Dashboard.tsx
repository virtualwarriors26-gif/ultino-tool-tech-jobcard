import React from 'react';
import {
  Users,
  Layers,
  FileText,
  Clock,
  CheckCircle2,
  AlertCircle,
  PlusCircle,
  Square,
  Eye,
  ArrowRight,
  History,
  FileSpreadsheet,
  Database,
  Building2,
} from 'lucide-react';
import { Job, Customer, Item } from '../types';
import { NavTab } from './Navbar';
import { calculateLiveElapsed } from '../services/storage';

interface DashboardProps {
  jobs: Job[];
  customers: Customer[];
  items: Item[];
  setActiveTab: (tab: NavTab) => void;
  onNewJobClick: () => void;
  onViewJob: (job: Job) => void;
  onEditJob: (job: Job) => void;
  onStatusChange: (job: Job, newStatus: 'Pending' | 'Production' | 'Completed') => void;
  onViewDrawing: (job: Job) => void;
}

export const Dashboard: React.FC<DashboardProps> = ({
  jobs,
  customers,
  items,
  setActiveTab,
  onNewJobClick,
  onViewJob,
  onEditJob,
  onStatusChange,
  onViewDrawing,
}) => {
  // Compute summary stats
  const totalCustomers = customers.length;
  const totalItems = items.length;
  const totalJobs = jobs.length;
  const pendingJobs = jobs.filter((j) => j.productionStatus === 'Pending').length;
  const inProductionJobs = jobs.filter((j) => j.productionStatus === 'Production');
  const completedJobs = jobs.filter((j) => j.productionStatus === 'Completed').length;

  return (
    <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 py-6 pb-24 space-y-6">
      {/* Formal White Hero Card */}
      <div className="relative overflow-hidden bg-white border border-slate-200 rounded-2xl p-5 sm:p-7 shadow-xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="flex items-start sm:items-center gap-4">
            <div>
              <div className="inline-flex items-center gap-2 px-2.5 py-0.5 bg-amber-50 border border-amber-200 rounded-full mb-1.5">
                <span className="w-2 h-2 rounded-full bg-amber-500 animate-pulse" />
                <span className="text-[10px] font-black uppercase tracking-wider text-amber-800">
                  ULTINO TOOL TECH • WIRE-CUT EDM WORKSHOP
                </span>
              </div>
              <h1 className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight">
                Digital Job Card Dashboard
              </h1>
              <p className="text-xs sm:text-sm text-slate-500 max-w-xl mt-0.5 font-medium">
                Production tracking, precision wire-cut job registry, and monthly ledger records.
              </p>
            </div>
          </div>

          {/* Quick Actions */}
          <div className="flex flex-wrap items-center gap-2.5">
            <button
              onClick={onNewJobClick}
              className="flex items-center gap-2 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-black px-5 py-3 rounded-xl text-xs sm:text-sm uppercase tracking-wider shadow-sm active:scale-95 transition-all"
            >
              <PlusCircle className="w-4 h-4 stroke-[2.5]" />
              <span>+ New Job</span>
            </button>

            <button
              onClick={() => setActiveTab('production')}
              className="flex items-center gap-2 bg-white hover:bg-slate-50 text-slate-800 font-bold px-4 py-3 rounded-xl text-xs sm:text-sm uppercase tracking-wider border border-slate-300 shadow-2xs transition"
            >
              <Clock className="w-4 h-4 text-amber-600" />
              <span>Production Board</span>
            </button>
          </div>
        </div>
      </div>

      {/* 6 Summary Cards (Formal White Background) */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 sm:gap-4">
        {/* Total Customers */}
        <div
          onClick={() => setActiveTab('customers')}
          className="bg-white border border-slate-200 hover:border-slate-300 rounded-xl p-4 cursor-pointer transition shadow-2xs hover:shadow-xs group"
        >
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-bold uppercase tracking-wider group-hover:text-amber-600">
              Customers
            </span>
            <Users className="w-4 h-4 text-slate-400 group-hover:text-amber-600" />
          </div>
          <div className="text-2xl sm:text-3xl font-black text-slate-900">{totalCustomers}</div>
          <span className="text-[10px] text-slate-500 font-medium mt-1 block">Saved in Master</span>
        </div>

        {/* Total Items */}
        <div
          onClick={() => setActiveTab('items')}
          className="bg-white border border-slate-200 hover:border-slate-300 rounded-xl p-4 cursor-pointer transition shadow-2xs hover:shadow-xs group"
        >
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-bold uppercase tracking-wider group-hover:text-amber-600">
              Items
            </span>
            <Layers className="w-4 h-4 text-slate-400 group-hover:text-amber-600" />
          </div>
          <div className="text-2xl sm:text-3xl font-black text-slate-900">{totalItems}</div>
          <span className="text-[10px] text-slate-500 font-medium mt-1 block">Reusable Parts</span>
        </div>

        {/* Total Jobs */}
        <div
          onClick={() => setActiveTab('job_history')}
          className="bg-white border border-slate-200 hover:border-slate-300 rounded-xl p-4 cursor-pointer transition shadow-2xs hover:shadow-xs group"
        >
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-bold uppercase tracking-wider group-hover:text-amber-600">
              Total Jobs
            </span>
            <FileText className="w-4 h-4 text-slate-400 group-hover:text-amber-600" />
          </div>
          <div className="text-2xl sm:text-3xl font-black text-slate-900">{totalJobs}</div>
          <span className="text-[10px] text-slate-500 font-medium mt-1 block">All Time Records</span>
        </div>

        {/* Pending Jobs */}
        <div
          onClick={() => setActiveTab('job_history')}
          className="bg-white border border-slate-200 hover:border-slate-300 rounded-xl p-4 cursor-pointer transition shadow-2xs hover:shadow-xs group"
        >
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-600">
              Pending
            </span>
            <AlertCircle className="w-4 h-4 text-slate-400" />
          </div>
          <div className="text-2xl sm:text-3xl font-black text-slate-700">{pendingJobs}</div>
          <span className="text-[10px] text-slate-500 font-medium mt-1 block">Awaiting Machine</span>
        </div>

        {/* Jobs in Production (Active highlight) */}
        <div
          onClick={() => setActiveTab('production')}
          className="bg-amber-50/70 border border-amber-300/80 hover:border-amber-400 rounded-xl p-4 cursor-pointer transition shadow-2xs hover:shadow-xs group"
        >
          <div className="flex items-center justify-between text-amber-700 mb-2">
            <span className="text-xs font-black uppercase tracking-wider flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-amber-500 animate-ping" />
              Production
            </span>
            <Clock className="w-4 h-4 text-amber-600" />
          </div>
          <div className="text-2xl sm:text-3xl font-black text-amber-700">
            {inProductionJobs.length}
          </div>
          <span className="text-[10px] text-amber-800 font-bold mt-1 block">
            Running on Machines
          </span>
        </div>

        {/* Completed Jobs */}
        <div
          onClick={() => setActiveTab('job_history')}
          className="bg-white border border-slate-200 hover:border-slate-300 rounded-xl p-4 cursor-pointer transition shadow-2xs hover:shadow-xs group"
        >
          <div className="flex items-center justify-between text-emerald-700 mb-2">
            <span className="text-xs font-bold uppercase tracking-wider text-emerald-700">
              Completed
            </span>
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-2xl sm:text-3xl font-black text-emerald-700">{completedJobs}</div>
          <span className="text-[10px] text-slate-500 font-medium mt-1 block">Finished Orders</span>
        </div>
      </div>

      {/* Main Section: Currently in Production Floor View */}
      <div className="bg-white border border-slate-200 rounded-2xl p-4 sm:p-6 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-4 mb-4">
          <div>
            <h2 className="text-base sm:text-lg font-black text-slate-900 flex items-center gap-2">
              <Clock className="w-5 h-5 text-amber-600" />
              <span>Jobs In Production (Shop Floor)</span>
            </h2>
            <p className="text-xs text-slate-500">
              Active wire-cutting machines and running job cards
            </p>
          </div>
          <button
            onClick={() => setActiveTab('production')}
            className="text-xs font-bold text-amber-700 hover:text-amber-800 flex items-center gap-1 uppercase tracking-wider"
          >
            <span>Open Production Screen</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>

        {inProductionJobs.length === 0 ? (
          <div className="text-center py-10 bg-slate-50 rounded-xl border border-dashed border-slate-200">
            <Clock className="w-10 h-10 text-slate-400 mx-auto mb-2" />
            <p className="text-sm font-bold text-slate-700">No jobs currently in production</p>
            <p className="text-xs text-slate-500 mt-1">
              Select a pending job and tap "START JOB" to begin machine timer.
            </p>
            <button
              onClick={onNewJobClick}
              className="mt-4 px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs uppercase tracking-wider rounded-lg shadow-2xs transition"
            >
              + Create New Job
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {inProductionJobs.map((job) => (
              <div
                key={job.id}
                className="bg-white border border-amber-300 rounded-xl p-4 shadow-xs flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="px-2 py-0.5 text-xs font-black bg-slate-900 text-amber-400 rounded tracking-wider font-mono">
                      {job.jobNumber}
                    </span>
                    <span className="text-[11px] font-bold text-amber-700 flex items-center gap-1">
                      <span className="w-2 h-2 rounded-full bg-amber-500 animate-ping" />
                      Running
                    </span>
                  </div>

                  <h3 className="text-base font-bold text-slate-900 truncate">{job.itemName}</h3>
                  <p className="text-xs text-slate-600 font-semibold truncate">
                    {job.customerName}
                  </p>

                  <div className="grid grid-cols-3 gap-1 my-3 bg-slate-50 p-2 rounded-lg text-center border border-slate-200">
                    <div>
                      <span className="text-[9px] uppercase font-bold text-slate-500 block">
                        Path
                      </span>
                      <span className="text-xs font-bold text-slate-800">
                        {job.pathLength || '-'}
                      </span>
                    </div>
                    <div>
                      <span className="text-[9px] uppercase font-bold text-slate-500 block">
                        Thk
                      </span>
                      <span className="text-xs font-bold text-slate-800">
                        {job.thickness || '-'}
                      </span>
                    </div>
                    <div>
                      <span className="text-[9px] uppercase font-bold text-slate-500 block">
                        Qty
                      </span>
                      <span className="text-xs font-black text-amber-700">
                        {job.quantity} pcs
                      </span>
                    </div>
                  </div>

                  {/* Machining Elapsed Time */}
                  <div className="bg-amber-50 border border-amber-200 rounded-lg p-2.5 flex items-center justify-between mb-3">
                    <span className="text-xs text-amber-800 font-bold uppercase">
                      Elapsed Time:
                    </span>
                    <span className="text-sm font-black text-amber-700 font-mono">
                      {calculateLiveElapsed(job.startTime)}
                    </span>
                  </div>
                </div>

                {/* Card Actions */}
                <div className="flex items-center gap-2 pt-2 border-t border-slate-100">
                  {job.drawing && (
                    <button
                      onClick={() => onViewDrawing(job)}
                      className="p-2 bg-slate-100 hover:bg-slate-200 text-slate-700 hover:text-amber-700 rounded-lg border border-slate-200 transition"
                      title="View Drawing"
                    >
                      <Eye className="w-4 h-4" />
                    </button>
                  )}
                  <button
                    onClick={() => onStatusChange(job, 'Completed')}
                    className="flex-1 flex items-center justify-center gap-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold py-2 rounded-lg text-xs uppercase tracking-wider transition shadow-2xs"
                  >
                    <Square className="w-3.5 h-3.5 fill-white" />
                    <span>Stop / Complete</span>
                  </button>
                  <button
                    onClick={() => onEditJob(job)}
                    className="px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold uppercase rounded-lg border border-slate-200 transition"
                  >
                    Edit
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Navigation Quick Shortcut Cards (Formal White) */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 sm:gap-4">
        <button
          onClick={() => setActiveTab('job_history')}
          className="flex flex-col items-start p-4 bg-white hover:bg-slate-50 border border-slate-200 hover:border-slate-300 rounded-xl text-left transition group shadow-2xs"
        >
          <div className="p-2.5 bg-amber-50 text-amber-600 rounded-lg mb-2 group-hover:scale-105 transition-transform border border-amber-100">
            <History className="w-5 h-5" />
          </div>
          <span className="text-sm font-bold text-slate-900 group-hover:text-amber-600">
            Job History
          </span>
          <span className="text-xs text-slate-500 mt-0.5">Search & filter all jobs</span>
        </button>

        <button
          onClick={() => setActiveTab('monthly_ledger')}
          className="flex flex-col items-start p-4 bg-white hover:bg-slate-50 border border-slate-200 hover:border-slate-300 rounded-xl text-left transition group shadow-2xs"
        >
          <div className="p-2.5 bg-blue-50 text-blue-600 rounded-lg mb-2 group-hover:scale-105 transition-transform border border-blue-100">
            <FileSpreadsheet className="w-5 h-5" />
          </div>
          <span className="text-sm font-bold text-slate-900 group-hover:text-blue-600">
            Monthly Ledger
          </span>
          <span className="text-xs text-slate-500 mt-0.5">A4 Reports & Monthly PDF</span>
        </button>

        <button
          onClick={() => setActiveTab('customers')}
          className="flex flex-col items-start p-4 bg-white hover:bg-slate-50 border border-slate-200 hover:border-slate-300 rounded-xl text-left transition group shadow-2xs"
        >
          <div className="p-2.5 bg-purple-50 text-purple-600 rounded-lg mb-2 group-hover:scale-105 transition-transform border border-purple-100">
            <Users className="w-5 h-5" />
          </div>
          <span className="text-sm font-bold text-slate-900 group-hover:text-purple-600">
            Customers
          </span>
          <span className="text-xs text-slate-500 mt-0.5">Permanent customer master</span>
        </button>

        <button
          onClick={() => setActiveTab('backup')}
          className="flex flex-col items-start p-4 bg-white hover:bg-slate-50 border border-slate-200 hover:border-slate-300 rounded-xl text-left transition group shadow-2xs"
        >
          <div className="p-2.5 bg-emerald-50 text-emerald-600 rounded-lg mb-2 group-hover:scale-105 transition-transform border border-emerald-100">
            <Database className="w-5 h-5" />
          </div>
          <span className="text-sm font-bold text-slate-900 group-hover:text-emerald-600">
            Backup & Settings
          </span>
          <span className="text-xs text-slate-500 mt-0.5">Export / Restore JSON</span>
        </button>
      </div>
    </div>
  );
};
