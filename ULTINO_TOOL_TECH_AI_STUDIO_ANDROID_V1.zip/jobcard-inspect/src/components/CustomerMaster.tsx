import React, { useState } from 'react';
import {
  Users,
  Search,
  PlusCircle,
  Building2,
  Phone,
  Mail,
  MapPin,
  FileText,
  Edit3,
  Trash2,
  AlertTriangle,
} from 'lucide-react';
import { Customer, Job, Item } from '../types';
import { CustomerModal } from './CustomerModal';

interface CustomerMasterProps {
  customers: Customer[];
  items: Item[];
  jobs: Job[];
  onSaveCustomer: (customer: Customer) => Promise<void>;
  onDeleteCustomer: (customerId: string) => Promise<{ success: boolean; message?: string }>;
  onSelectCustomerForNewJob: (customer: Customer) => void;
}

export const CustomerMaster: React.FC<CustomerMasterProps> = ({
  customers,
  items,
  jobs,
  onSaveCustomer,
  onDeleteCustomer,
  onSelectCustomerForNewJob,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [customerToEdit, setCustomerToEdit] = useState<Customer | null>(null);

  const [customerToDelete, setCustomerToDelete] = useState<Customer | null>(null);
  const [deleteErrorMessage, setDeleteErrorMessage] = useState('');
  const [isDeleting, setIsDeleting] = useState(false);

  const filteredCustomers = customers.filter((c) => {
    if (!searchQuery.trim()) return true;
    const q = searchQuery.toLowerCase();
    return (
      c.name.toLowerCase().includes(q) ||
      (c.contactPerson && c.contactPerson.toLowerCase().includes(q)) ||
      (c.phone && c.phone.toLowerCase().includes(q)) ||
      (c.address && c.address.toLowerCase().includes(q))
    );
  });

  const handleOpenAdd = () => {
    setCustomerToEdit(null);
    setIsModalOpen(true);
  };

  const handleOpenEdit = (c: Customer) => {
    setCustomerToEdit(c);
    setIsModalOpen(true);
  };

  const handleDeleteConfirm = async () => {
    if (!customerToDelete) return;
    try {
      setIsDeleting(true);
      setDeleteErrorMessage('');
      const res = await onDeleteCustomer(customerToDelete.id);
      if (res.success) {
        setCustomerToDelete(null);
      } else {
        setDeleteErrorMessage(res.message || 'Cannot delete customer.');
      }
    } catch (err: any) {
      setDeleteErrorMessage(err?.message || 'Failed to delete customer.');
    } finally {
      setIsDeleting(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 py-6 pb-24 space-y-5">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white border border-slate-200 rounded-2xl p-5 sm:p-6 shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2 py-0.5 text-xs font-black uppercase tracking-wider bg-slate-900 text-white rounded">
              MASTER DATA
            </span>
            <span className="text-xs text-slate-500 font-mono">CLIENT DIRECTORY</span>
          </div>
          <h1 className="text-2xl font-black text-slate-900 tracking-tight mt-1 flex items-center gap-2">
            <Users className="w-6 h-6 text-amber-600" />
            <span>Customer Master</span>
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 font-medium">
            Permanent customer registry reusable across multiple recurring manufacturing jobs
          </p>
        </div>

        <button
          onClick={handleOpenAdd}
          className="flex items-center gap-2 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 text-slate-950 font-black px-4 py-2.5 rounded-xl text-xs sm:text-sm uppercase tracking-wider shadow-sm active:scale-95 transition"
        >
          <PlusCircle className="w-4 h-4 stroke-[2.5]" />
          <span>+ Add Customer</span>
        </button>
      </div>

      {/* Search Input */}
      <div className="relative">
        <Search className="w-4 h-4 absolute left-3.5 top-3.5 text-slate-400" />
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="Search customer by name, contact person, phone or address..."
          className="w-full bg-white border border-slate-200 rounded-xl pl-10 pr-4 py-3 text-sm text-slate-900 placeholder-slate-400 focus:outline-none focus:border-amber-500 shadow-2xs"
        />
        {searchQuery && (
          <button
            onClick={() => setSearchQuery('')}
            className="absolute right-3.5 top-3 text-slate-400 hover:text-slate-600 text-xs"
          >
            ✕
          </button>
        )}
      </div>

      {/* Customer Cards Grid (Formal White) */}
      {filteredCustomers.length === 0 ? (
        <div className="text-center py-12 bg-white border border-dashed border-slate-200 rounded-2xl">
          <Building2 className="w-12 h-12 text-slate-400 mx-auto mb-2" />
          <h3 className="text-base font-bold text-slate-800">No Customers Found</h3>
          <p className="text-xs text-slate-500 mt-1">
            {searchQuery ? 'Try a different search keyword.' : 'Add your first customer to begin.'}
          </p>
          <button
            onClick={handleOpenAdd}
            className="mt-4 px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs uppercase tracking-wider rounded-lg transition shadow-sm"
          >
            + Add New Customer
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredCustomers.map((cust) => {
            const customerJobs = jobs.filter((j) => j.customerId === cust.id);
            const customerItems = items.filter((i) => i.customerId === cust.id);

            return (
              <div
                key={cust.id}
                className="bg-white border border-slate-200 hover:border-slate-300 rounded-xl p-5 shadow-2xs hover:shadow-xs flex flex-col justify-between transition group"
              >
                <div>
                  <div className="flex items-start justify-between gap-2 mb-3">
                    <div className="flex items-center gap-2.5">
                      <div className="p-2.5 bg-amber-50 text-amber-700 rounded-lg border border-amber-200 group-hover:scale-105 transition-transform">
                        <Building2 className="w-5 h-5" />
                      </div>
                      <div>
                        <h3 className="text-base font-bold text-slate-900 group-hover:text-amber-700 transition-colors">
                          {cust.name}
                        </h3>
                        {cust.contactPerson && (
                          <p className="text-xs text-slate-500 font-semibold">
                            Contact: {cust.contactPerson}
                          </p>
                        )}
                      </div>
                    </div>
                  </div>

                  <div className="space-y-1.5 text-xs text-slate-600 my-3">
                    {cust.phone && (
                      <div className="flex items-center gap-2">
                        <Phone className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                        <span>{cust.phone}</span>
                      </div>
                    )}
                    {cust.email && (
                      <div className="flex items-center gap-2">
                        <Mail className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                        <span className="truncate">{cust.email}</span>
                      </div>
                    )}
                    {cust.address && (
                      <div className="flex items-center gap-2">
                        <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                        <span className="truncate">{cust.address}</span>
                      </div>
                    )}
                    {cust.notes && (
                      <div className="flex items-start gap-2 pt-1 text-[11px] text-slate-500 italic">
                        <FileText className="w-3.5 h-3.5 text-slate-400 shrink-0 mt-0.5" />
                        <span className="line-clamp-2">{cust.notes}</span>
                      </div>
                    )}
                  </div>

                  <div className="grid grid-cols-2 gap-2 my-3 p-2 bg-slate-50 rounded-lg text-center border border-slate-200">
                    <div>
                      <span className="text-[10px] text-slate-500 font-bold uppercase block">
                        Associated Items
                      </span>
                      <span className="text-xs font-black text-slate-800">
                        {customerItems.length}
                      </span>
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-500 font-bold uppercase block">
                        Job Cards
                      </span>
                      <span className="text-xs font-black text-amber-700">
                        {customerJobs.length}
                      </span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center justify-between gap-2 pt-3 border-t border-slate-100">
                  <button
                    onClick={() => onSelectCustomerForNewJob(cust)}
                    className="flex-1 px-3 py-2 bg-slate-100 hover:bg-slate-900 hover:text-white text-slate-800 text-xs font-bold uppercase rounded-lg border border-slate-300 transition shadow-2xs"
                  >
                    + Create Job
                  </button>

                  <div className="flex items-center gap-1">
                    <button
                      onClick={() => handleOpenEdit(cust)}
                      className="p-2 text-slate-500 hover:text-amber-700 hover:bg-slate-100 rounded-lg transition"
                      title="Edit Customer"
                    >
                      <Edit3 className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => {
                        setDeleteErrorMessage('');
                        setCustomerToDelete(cust);
                      }}
                      className="p-2 text-slate-500 hover:text-red-600 hover:bg-slate-100 rounded-lg transition"
                      title="Delete Customer"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Add / Edit Customer Modal */}
      <CustomerModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        onSave={onSaveCustomer}
        customerToEdit={customerToEdit}
      />

      {/* Safe Delete Confirmation Modal */}
      {customerToDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 backdrop-blur-xs p-4">
          <div className="relative w-full max-w-md bg-white border border-slate-200 rounded-2xl p-6 shadow-xl space-y-4">
            <div className="flex items-center gap-3 text-red-600">
              <div className="p-2 bg-red-50 border border-red-200 rounded-xl">
                <AlertTriangle className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-base font-bold text-slate-900">Delete Customer</h3>
                <p className="text-xs text-slate-500">Safety Verification</p>
              </div>
            </div>

            <p className="text-xs sm:text-sm text-slate-700">
              Are you sure you want to delete{' '}
              <strong className="text-slate-900">{customerToDelete.name}</strong> from customer master?
            </p>

            {jobs.some((j) => j.customerId === customerToDelete.id) ? (
              <div className="p-3 bg-red-50 border border-red-200 rounded-lg text-xs text-red-800 space-y-1">
                <span className="font-bold block">⚠️ Deletion Prohibited:</span>
                <span>
                  This customer is referenced by{' '}
                  <strong>
                    {jobs.filter((j) => j.customerId === customerToDelete.id).length} historical job cards
                  </strong>
                  . Deleting it would damage production audit history.
                </span>
              </div>
            ) : (
              <div className="p-3 bg-slate-50 border border-slate-200 rounded-lg text-xs text-slate-600">
                ✓ No historical job cards reference this customer. It is safe to remove.
              </div>
            )}

            {deleteErrorMessage && (
              <div className="p-2.5 bg-red-50 text-red-700 text-xs rounded border border-red-200">
                {deleteErrorMessage}
              </div>
            )}

            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={() => setCustomerToDelete(null)}
                className="px-4 py-2 text-xs font-semibold uppercase text-slate-600 hover:text-slate-900 rounded-lg hover:bg-slate-100 transition"
              >
                Cancel
              </button>
              <button
                type="button"
                disabled={
                  isDeleting || jobs.some((j) => j.customerId === customerToDelete.id)
                }
                onClick={handleDeleteConfirm}
                className="px-5 py-2.5 bg-red-600 hover:bg-red-500 text-white font-bold text-xs uppercase tracking-wider rounded-lg shadow-sm transition disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {isDeleting ? 'Deleting...' : 'Delete Customer'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
