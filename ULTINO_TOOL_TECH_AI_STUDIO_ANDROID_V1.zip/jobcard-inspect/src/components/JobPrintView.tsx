import React from 'react';
import { Printer, X } from 'lucide-react';
import { Job } from '../types';
import { formatDateDisplay, formatTimeDisplay } from '../services/pdfGenerator';

interface JobPrintViewProps {
  job: Job | null;
  onClose: () => void;
}

export const JobPrintView: React.FC<JobPrintViewProps> = ({ job, onClose }) => {
  if (!job) return null;

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 backdrop-blur-xs p-2 sm:p-4 overflow-y-auto">
      {/* Container */}
      <div className="relative w-full max-w-3xl bg-white text-slate-900 rounded-xl shadow-2xl p-6 sm:p-8 my-auto print:p-0 print:shadow-none print:max-w-none print:w-full">
        {/* Print Control Toolbar - Hidden in Print */}
        <div className="flex items-center justify-between border-b pb-4 mb-6 print:hidden">
          <span className="text-sm font-bold text-slate-700">
            Print Preview: Work Order Job Card
          </span>
          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="flex items-center gap-1.5 px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs uppercase rounded-lg shadow-sm transition"
            >
              <Printer className="w-4 h-4" />
              <span>Print Job Card</span>
            </button>
            <button
              onClick={onClose}
              className="p-2 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-slate-100 transition"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Card Area */}
        <div className="border-2 border-slate-900 p-4 sm:p-6 rounded-lg font-sans bg-white">
          {/* Header */}
          <div className="flex justify-between items-center border-b-2 border-slate-900 pb-3 mb-4">
            <div>
              <h1 className="text-2xl font-black tracking-wider text-slate-950">
                ULTINO TOOL TECH
              </h1>
              <p className="text-xs font-bold text-slate-700 tracking-wide uppercase">
                Precision Wire-Cut EDM & Tool Manufacturing
              </p>
              <p className="text-[11px] text-slate-600">
                Plot 42, Peenya Industrial Area, Bengaluru • Ph: +91 98450 00000
              </p>
            </div>
            <div className="text-right">
              <span className="inline-block px-3 py-1 bg-slate-950 text-white font-mono font-black text-lg rounded">
                {job.jobNumber}
              </span>
              <p className="text-xs font-bold text-slate-700 mt-1">
                Date: {formatDateDisplay(job.date)}
              </p>
            </div>
          </div>

          <div className="text-center bg-slate-100 py-1 font-bold text-xs uppercase tracking-widest border border-slate-300 mb-4">
            WORKSHOP PRODUCTION JOB CARD / MACHINE TRAVEL TAG
          </div>

          {/* Job Details Grid */}
          <table className="w-full text-xs border-collapse border border-slate-300 mb-4">
            <tbody>
              <tr className="border-b border-slate-300">
                <td className="p-2 bg-slate-100 font-bold w-1/4">CUSTOMER NAME:</td>
                <td className="p-2 font-bold text-sm w-1/4" colSpan={3}>
                  {job.customerName}
                </td>
              </tr>
              <tr className="border-b border-slate-300">
                <td className="p-2 bg-slate-100 font-bold">ITEM / COMPONENT:</td>
                <td className="p-2 font-bold text-sm" colSpan={3}>
                  {job.itemName}
                </td>
              </tr>
              <tr className="border-b border-slate-300">
                <td className="p-2 bg-slate-100 font-bold">SPECIFICATION:</td>
                <td className="p-2" colSpan={3}>
                  {job.description || '-'}
                </td>
              </tr>
              <tr className="border-b border-slate-300">
                <td className="p-2 bg-slate-100 font-bold">PATH LENGTH:</td>
                <td className="p-2 font-mono font-bold">{job.pathLength || '-'}</td>
                <td className="p-2 bg-slate-100 font-bold">THICKNESS:</td>
                <td className="p-2 font-mono font-bold">{job.thickness || '-'}</td>
              </tr>
              <tr className="border-b border-slate-300">
                <td className="p-2 bg-slate-100 font-bold">QUANTITY:</td>
                <td className="p-2 font-bold text-base">{job.quantity} pcs</td>
                <td className="p-2 bg-slate-100 font-bold">CURRENT STATUS:</td>
                <td className="p-2 font-bold uppercase">{job.productionStatus}</td>
              </tr>
              <tr className="border-b border-slate-300">
                <td className="p-2 bg-slate-100 font-bold">START TIME:</td>
                <td className="p-2 font-mono">{formatTimeDisplay(job.startTime)}</td>
                <td className="p-2 bg-slate-100 font-bold">END TIME:</td>
                <td className="p-2 font-mono">{formatTimeDisplay(job.endTime)}</td>
              </tr>
              <tr className="border-b border-slate-300">
                <td className="p-2 bg-slate-100 font-bold">TOTAL MACHINING TIME:</td>
                <td className="p-2 font-bold text-sm font-mono" colSpan={3}>
                  {job.totalTimeFormatted || '-'}
                </td>
              </tr>
              <tr>
                <td className="p-2 bg-slate-100 font-bold">REMARKS / NOTES:</td>
                <td className="p-2" colSpan={3}>
                  {job.remarks || 'Standard machining parameters.'}
                </td>
              </tr>
            </tbody>
          </table>

          {/* Drawing Attachment Section */}
          {job.drawing && job.drawing.fileType !== 'application/pdf' && (
            <div className="border border-slate-300 p-2 mb-4 rounded text-center">
              <span className="block text-[10px] font-bold text-slate-500 uppercase mb-1">
                ATTACHED TECHNICAL DRAWING PROFILE
              </span>
              <div className="h-48 flex items-center justify-center bg-slate-50 rounded">
                <img
                  src={job.drawing.dataUrl}
                  alt="Workpiece Drawing"
                  className="max-h-full max-w-full object-contain"
                />
              </div>
            </div>
          )}

          {/* Signatures Footer */}
          <div className="grid grid-cols-3 gap-4 pt-6 text-center text-xs text-slate-700">
            <div className="border-t border-slate-400 pt-1">
              <span className="font-bold block">OPERATOR SIGN</span>
              <span className="text-[10px] text-slate-500">(Machine In-Charge)</span>
            </div>
            <div className="border-t border-slate-400 pt-1">
              <span className="font-bold block">INSPECTION / QC SIGN</span>
              <span className="text-[10px] text-slate-500">(Dimensional Check)</span>
            </div>
            <div className="border-t border-slate-400 pt-1">
              <span className="font-bold block">DISPATCH / STORE SIGN</span>
              <span className="text-[10px] text-slate-500">(Received & Cleared)</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
