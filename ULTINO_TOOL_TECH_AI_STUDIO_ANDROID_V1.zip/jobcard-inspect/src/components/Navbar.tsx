import React from 'react';
import {
  LayoutDashboard,
  PlusCircle,
  Clock,
  History,
  Users,
  Layers,
  FileSpreadsheet,
  Database,
  Menu,
  X,
} from 'lucide-react';

export type NavTab =
  | 'dashboard'
  | 'new_job'
  | 'production'
  | 'job_history'
  | 'customers'
  | 'items'
  | 'monthly_ledger'
  | 'backup';

interface NavbarProps {
  activeTab: NavTab;
  setActiveTab: (tab: NavTab) => void;
  productionCount: number;
  onNewJobClick: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  productionCount,
  onNewJobClick,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = React.useState(false);

  const navItems = [
    { id: 'dashboard' as NavTab, label: 'Dashboard', icon: LayoutDashboard },
    { id: 'production' as NavTab, label: 'Production', icon: Clock, badge: productionCount },
    { id: 'job_history' as NavTab, label: 'Job History', icon: History },
    { id: 'customers' as NavTab, label: 'Customers', icon: Users },
    { id: 'items' as NavTab, label: 'Items', icon: Layers },
    { id: 'monthly_ledger' as NavTab, label: 'Monthly Ledger', icon: FileSpreadsheet },
    { id: 'backup' as NavTab, label: 'Backup', icon: Database },
  ];

  const handleTabClick = (tab: NavTab) => {
    setActiveTab(tab);
    setMobileMenuOpen(false);
  };

  return (
    <header className="sticky top-0 z-30 bg-white border-b border-slate-200 text-slate-900 shadow-xs">
      {/* Top Main Navigation Bar */}
      <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 sm:h-20">
          {/* Company Title */}
          <div
            onClick={() => handleTabClick('dashboard')}
            className="flex items-center gap-3 cursor-pointer select-none group py-1"
          >
            <div className="w-10 h-10 sm:w-11 sm:h-11 rounded-xl bg-slate-950 text-amber-400 flex items-center justify-center font-black text-lg sm:text-xl tracking-wider shadow-xs group-hover:scale-105 transition-transform border border-slate-800">
              U
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-base sm:text-xl font-black tracking-wide text-slate-950">
                  ULTINO <span className="text-amber-600">TOOL TECH</span>
                </span>
                <span className="hidden sm:inline-block px-2 py-0.5 text-[10px] font-bold tracking-widest uppercase bg-slate-100 text-slate-700 border border-slate-300 rounded">
                  WIRE-CUT EDM
                </span>
              </div>
              <p className="text-[11px] text-slate-500 font-semibold tracking-tight">
                Digital Job Card & Production Management
              </p>
            </div>
          </div>

          {/* Desktop Navigation Links */}
          <nav className="hidden lg:flex items-center space-x-1">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => handleTabClick(item.id)}
                  className={`relative flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-bold tracking-wider uppercase transition-all ${
                    isActive
                      ? 'bg-slate-900 text-white shadow-sm'
                      : 'text-slate-600 hover:text-slate-950 hover:bg-slate-100'
                  }`}
                >
                  <Icon className={`w-4 h-4 ${isActive ? 'text-amber-400' : 'text-slate-500'}`} />
                  <span>{item.label}</span>
                  {typeof item.badge === 'number' && item.badge > 0 && (
                    <span
                      className={`ml-1 px-1.5 py-0.2 text-[10px] font-black rounded-full ${
                        isActive ? 'bg-amber-400 text-slate-950' : 'bg-amber-500 text-white'
                      }`}
                    >
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </nav>

          {/* Right Action: Desktop + New Job Button & Mobile Hamburger */}
          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                onNewJobClick();
                setMobileMenuOpen(false);
              }}
              className="flex items-center gap-2 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 active:scale-95 text-slate-950 font-black px-3.5 sm:px-4 py-2 sm:py-2.5 rounded-lg text-xs sm:text-sm uppercase tracking-wider shadow-sm transition-all"
            >
              <PlusCircle className="w-4 h-4 text-slate-950 stroke-[2.5]" />
              <span>New Job</span>
            </button>

            {/* Mobile Menu Button */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden p-2 rounded-lg text-slate-600 hover:text-slate-900 hover:bg-slate-100 focus:outline-none"
              aria-label="Toggle Navigation Menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Dropdown Drawer */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-white border-b border-slate-200 px-4 pt-3 pb-5 space-y-1.5 shadow-lg">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => handleTabClick(item.id)}
                className={`w-full flex items-center justify-between px-3.5 py-3 rounded-lg text-sm font-bold tracking-wide uppercase transition-colors ${
                  isActive
                    ? 'bg-slate-900 text-white'
                    : 'text-slate-700 hover:bg-slate-100'
                }`}
              >
                <div className="flex items-center gap-3">
                  <Icon className={`w-5 h-5 ${isActive ? 'text-amber-400' : 'text-slate-500'}`} />
                  <span>{item.label}</span>
                </div>
                {typeof item.badge === 'number' && item.badge > 0 && (
                  <span
                    className={`px-2 py-0.5 text-xs font-bold rounded-full ${
                      isActive ? 'bg-amber-400 text-slate-950' : 'bg-amber-500 text-white'
                    }`}
                  >
                    {item.badge} Running
                  </span>
                )}
              </button>
            );
          })}
        </div>
      )}

      {/* Mobile Sticky Quick Navigation Bottom Bar for Workshop ergonomics */}
      <div className="lg:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-slate-200 px-2 py-1.5 flex justify-around items-center shadow-lg">
        <button
          onClick={() => handleTabClick('dashboard')}
          className={`flex flex-col items-center py-1 px-2 rounded ${
            activeTab === 'dashboard' ? 'text-amber-600 font-bold' : 'text-slate-500'
          }`}
        >
          <LayoutDashboard className="w-5 h-5" />
          <span className="text-[10px] mt-0.5">Home</span>
        </button>

        <button
          onClick={() => handleTabClick('production')}
          className={`relative flex flex-col items-center py-1 px-2 rounded ${
            activeTab === 'production' ? 'text-amber-600 font-bold' : 'text-slate-500'
          }`}
        >
          <Clock className="w-5 h-5" />
          <span className="text-[10px] mt-0.5">Production</span>
          {productionCount > 0 && (
            <span className="absolute top-0.5 right-1 w-2.5 h-2.5 bg-amber-500 rounded-full animate-pulse" />
          )}
        </button>

        {/* Center Floating Action for New Job */}
        <button
          onClick={onNewJobClick}
          className="flex flex-col items-center justify-center -mt-5 w-12 h-12 rounded-full bg-gradient-to-tr from-amber-500 to-amber-400 text-slate-950 shadow-md shadow-amber-500/30 active:scale-95"
          aria-label="Create New Job"
        >
          <PlusCircle className="w-7 h-7 stroke-[2.2]" />
        </button>

        <button
          onClick={() => handleTabClick('job_history')}
          className={`flex flex-col items-center py-1 px-2 rounded ${
            activeTab === 'job_history' ? 'text-amber-600 font-bold' : 'text-slate-500'
          }`}
        >
          <History className="w-5 h-5" />
          <span className="text-[10px] mt-0.5">History</span>
        </button>

        <button
          onClick={() => handleTabClick('monthly_ledger')}
          className={`flex flex-col items-center py-1 px-2 rounded ${
            activeTab === 'monthly_ledger' ? 'text-amber-600 font-bold' : 'text-slate-500'
          }`}
        >
          <FileSpreadsheet className="w-5 h-5" />
          <span className="text-[10px] mt-0.5">Ledger</span>
        </button>
      </div>
    </header>
  );
};
