import React, { useState } from 'react';
import {
  FileSpreadsheet,
  Download,
  Printer,
  Eye,
  Calendar,
  Building2,
  X,
} from 'lucide-react';
import { Job, Customer } from '../types';
import { generateMonthlyLedgerPdf, formatDateDisplay, formatTimeDisplay } from '../services/pdfGenerator';

interface MonthlyLedgerProps {
  jobs: Job[];
  customers: Customer[];
  onViewJob: (job: Job) => void;
  onViewDrawing: (job: Job) => void;
}

export const MonthlyLedger: React.FC<MonthlyLedgerProps> = ({
  jobs,
  customers,
  onViewJob,
  onViewDrawing,
}) => {
  const currentDate = new Date();
  const currentMonthNum = String(currentDate.getMonth() + 1).padStart(2, '0');
  const currentYearNum = currentDate.getFullYear();

  const [selectedMonth, setSelectedMonth] = useState<string>(currentMonthNum);
  const [selectedYear, setSelectedYear] = useState<number>(currentYearNum);
  const [selectedCustomerId, setSelectedCustomerId] = useState<string>('ALL');

  const [pdfPreviewUrl, setPdfPreviewUrl] = useState<string | null>(null);
  const [isGeneratingPdf, setIsGeneratingPdf] = useState(false);

  const months = [
    { num: '01', name: 'January' },
    { num: '02', name: 'February' },
    { num: '03', name: 'March' },
    { num: '04', name: 'April' },
    { num: '05', name: 'May' },
    { num: '06', name: 'June' },
    { num: '07', name: 'July' },
    { num: '08', name: 'August' },
    { num: '09', name: 'September' },
    { num: '10', name: 'October' },
    { num: '11', name: 'November' },
    { num: '12', name: 'December' },
  ];

  const currentMonthObj = months.find((m) => m.num === selectedMonth) || months[0];

  const availableYears = Array.from(
    new Set([
      currentYearNum,
      ...jobs.map((j) => (j.date ? parseInt(j.date.split('-')[0]) : currentYearNum)),
    ])
  ).sort((a, b) => b - a);

  const monthlyJobs = jobs.filter((job) => {
    if (!job.date) return false;
    const [y, m] = job.date.split('-');
    if (parseInt(y) !== selectedYear || m !== selectedMonth) return false;

    if (selectedCustomerId !== 'ALL' && job.customerId !== selectedCustomerId) {
      return false;
    }
    return true;
  }).sort((a, b) => a.serialNumberIndex - b.serialNumberIndex);

  const totalQty = monthlyJobs.reduce((sum, j) => sum + (Number(j.quantity) || 0), 0);
  const totalMinutes = monthlyJobs.reduce((sum, j) => sum + (Number(j.totalTimeMinutes) || 0), 0);
  const totalHours = Math.floor(totalMinutes / 60);
  const remMinutes = totalMinutes % 60;
  const machiningTimeFormatted = totalHours > 0 ? `${totalHours} hr ${remMinutes} min` : `${remMinutes} min`;

  const filterCustName =
    selectedCustomerId !== 'ALL'
      ? customers.find((c) => c.id === selectedCustomerId)?.name || 'Filtered Customer'
      : undefined;

  const handleDownloadPdf = () => {
    try {
      setIsGeneratingPdf(true);
      const doc = generateMonthlyLedgerPdf(
        monthlyJobs,
        currentMonthObj.name,
        selectedYear,
        filterCustName
      );
      const safeCustomerPart = filterCustName ? `_${filterCustName.replace(/\s+/g, '_')}` : '';
      doc.save(`ULTINO_TOOL_TECH_Ledger_${currentMonthObj.name}_${selectedYear}${safeCustomerPart}.pdf`);
    } finally {
      setIsGeneratingPdf(false);
    }
  };

  const handlePreviewPdf = () => {
    try {
      setIsGeneratingPdf(true);
      const doc = generateMonthlyLedgerPdf(
        monthlyJobs,
        currentMonthObj.name,
        selectedYear,
        filterCustName
      );
      const blob = doc.output('blob');
      const url = URL.createObjectURL(blob);
      setPdfPreviewUrl(url);
    } finally {
      setIsGeneratingPdf(false);
    }
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 py-6 pb-24 space-y-5">
      {/* Header */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 bg-white border border-slate-200 rounded-2xl p-5 sm:p-6 shadow-xs">
        <div className="flex items-center gap-3">
          <div>
            <div className="flex items-center gap-2">
              <span className="px-2 py-0.5 text-xs font-black uppercase tracking-wider bg-slate-900 text-white rounded">
                MONTHLY REGISTER
              </span>
              <span className="text-xs text-slate-500 font-mono">AUDIT & PRODUCTION REPORT</span>
            </div>
            <h1 className="text-2xl font-black text-slate-900 tracking-tight mt-1 flex items-center gap-2">
              <FileSpreadsheet className="w-6 h-6 text-amber-600" />
              <span>Monthly Production Ledger</span>
            </h1>
            <p className="text-xs sm:text-sm text-slate-500 font-medium">
              Official workshop register for ULTINO TOOL TECH • Ready for A4 preview, print & PDF export
            </p>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={handlePreviewPdf}
            className="flex items-center gap-1.5 px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold uppercase rounded-xl border border-slate-300 transition shadow-2xs"
          >
            <Eye className="w-4 h-4 text-amber-600" />
            <span>Preview PDF</span>
          </button>

          <button
            onClick={handleDownloadPdf}
            disabled={isGeneratingPdf}
            className="flex items-center gap-2 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 text-slate-950 font-black px-4 py-2.5 rounded-xl text-xs uppercase tracking-wider shadow-sm transition disabled:opacity-50"
          >
            <Download className="w-4 h-4 stroke-[2.5]" />
            <span>Generate Monthly PDF</span>
          </button>

          <button
            onClick={handlePrint}
            className="flex items-center gap-1.5 px-3 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold uppercase rounded-xl border border-slate-300 transition"
            title="Print Current View"
          >
            <Printer className="w-4 h-4" />
            <span>Print</span>
          </button>
        </div>
      </div>

      {/* Selectors */}
      <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-2xs">
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div>
            <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-600 mb-1 flex items-center gap-1">
              <Calendar className="w-3.5 h-3.5 text-amber-600" />
              <span>Select Month</span>
            </label>
            <select
              value={selectedMonth}
              onChange={(e) => setSelectedMonth(e.target.value)}
              className="w-full bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 text-sm font-semibold text-slate-900 focus:outline-none focus:border-amber-500"
            >
              {months.map((m) => (
                <option key={m.num} value={m.num}>
                  {m.name}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-600 mb-1 flex items-center gap-1">
              <Calendar className="w-3.5 h-3.5 text-amber-600" />
              <span>Select Year</span>
            </label>
            <select
              value={selectedYear}
              onChange={(e) => setSelectedYear(parseInt(e.target.value))}
              className="w-full bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 text-sm font-semibold text-slate-900 focus:outline-none focus:border-amber-500"
            >
              {availableYears.map((y) => (
                <option key={y} value={y}>
                  {y}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-600 mb-1 flex items-center gap-1">
              <Building2 className="w-3.5 h-3.5 text-amber-600" />
              <span>Filter by Customer</span>
            </label>
            <select
              value={selectedCustomerId}
              onChange={(e) => setSelectedCustomerId(e.target.value)}
              className="w-full bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 text-sm font-semibold text-slate-900 focus:outline-none focus:border-amber-500"
            >
              <option value="ALL">All Customers</option>
              {customers.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Selected Month Summary KPIs */}
        <div className="grid grid-cols-3 gap-3 mt-4 pt-4 border-t border-slate-100 text-center">
          <div className="bg-slate-50 p-2.5 rounded-lg border border-slate-200">
            <span className="text-[10px] uppercase font-bold text-slate-500 block">
              Jobs In {currentMonthObj.name}
            </span>
            <span className="text-lg sm:text-xl font-black text-slate-900">
              {monthlyJobs.length}
            </span>
          </div>
          <div className="bg-slate-50 p-2.5 rounded-lg border border-slate-200">
            <span className="text-[10px] uppercase font-bold text-slate-500 block">
              Total Components
            </span>
            <span className="text-lg sm:text-xl font-black text-amber-700">
              {totalQty} pcs
            </span>
          </div>
          <div className="bg-slate-50 p-2.5 rounded-lg border border-slate-200">
            <span className="text-[10px] uppercase font-bold text-slate-500 block">
              Machining Time
            </span>
            <span className="text-lg sm:text-xl font-black text-slate-800 font-mono">
              {machiningTimeFormatted}
            </span>
          </div>
        </div>
      </div>

      {/* Ledger Table (Formal White) */}
      <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-xs">
        <div className="px-5 py-3.5 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="font-bold text-sm text-slate-900 uppercase tracking-wider">
              {currentMonthObj.name.toUpperCase()} {selectedYear} PRODUCTION TABLE
            </span>
            {filterCustName && (
              <span className="px-2 py-0.5 text-xs font-bold bg-amber-50 text-amber-800 border border-amber-300 rounded">
                {filterCustName}
              </span>
            )}
          </div>
          <span className="text-xs text-slate-500 font-mono font-semibold">
            {monthlyJobs.length} records recorded
          </span>
        </div>

        {monthlyJobs.length === 0 ? (
          <div className="text-center py-16 bg-white">
            <FileSpreadsheet className="w-12 h-12 text-slate-400 mx-auto mb-2" />
            <h3 className="text-base font-bold text-slate-800">
              No Jobs Recorded For {currentMonthObj.name} {selectedYear}
            </h3>
            <p className="text-xs text-slate-500 mt-1">
              Select a different month or create a job with a date in this month.
            </p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-slate-700 border-collapse">
              <thead className="bg-slate-50 text-slate-700 uppercase tracking-wider border-b border-slate-200 text-[10px] font-bold">
                <tr>
                  <th className="py-3 px-3">SL. NO.</th>
                  <th className="py-3 px-3">DATE</th>
                  <th className="py-3 px-3">CUSTOMER</th>
                  <th className="py-3 px-3">ITEM</th>
                  <th className="py-3 px-3">DESCRIPTION</th>
                  <th className="py-3 px-3 text-center">PATH</th>
                  <th className="py-3 px-3 text-center">THK</th>
                  <th className="py-3 px-3 text-center">QTY</th>
                  <th className="py-3 px-3 text-center">STATUS</th>
                  <th className="py-3 px-3 text-center">START</th>
                  <th className="py-3 px-3 text-center">END</th>
                  <th className="py-3 px-3 text-center">TOTAL TIME</th>
                  <th className="py-3 px-3">REMARKS</th>
                  <th className="py-3 px-3 text-center">DWG</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 font-sans">
                {monthlyJobs.map((job) => (
                  <tr
                    key={job.id}
                    onClick={() => onViewJob(job)}
                    className="hover:bg-slate-50 transition cursor-pointer"
                  >
                    <td className="py-2.5 px-3 font-mono font-black text-slate-900 whitespace-nowrap">
                      {job.jobNumber}
                    </td>

                    <td className="py-2.5 px-3 font-mono whitespace-nowrap text-slate-600">
                      {formatDateDisplay(job.date)}
                    </td>

                    <td className="py-2.5 px-3 font-semibold text-slate-900 whitespace-nowrap">
                      {job.customerName}
                    </td>

                    <td className="py-2.5 px-3 font-semibold text-slate-800 whitespace-nowrap">
                      {job.itemName}
                    </td>

                    <td className="py-2.5 px-3 text-slate-600 max-w-xs truncate">
                      {job.description || '-'}
                    </td>

                    <td className="py-2.5 px-3 text-center font-mono text-slate-700 whitespace-nowrap">
                      {job.pathLength || '-'}
                    </td>

                    <td className="py-2.5 px-3 text-center font-mono text-slate-700 whitespace-nowrap">
                      {job.thickness || '-'}
                    </td>

                    <td className="py-2.5 px-3 text-center font-bold text-amber-700 whitespace-nowrap">
                      {job.quantity}
                    </td>

                    <td className="py-2.5 px-3 text-center whitespace-nowrap">
                      <span
                        className={`px-2 py-0.5 text-[9px] font-black uppercase rounded ${
                          job.productionStatus === 'Completed'
                            ? 'bg-emerald-50 text-emerald-800 border border-emerald-300'
                            : job.productionStatus === 'Production'
                            ? 'bg-amber-50 text-amber-800 border border-amber-300'
                            : 'bg-slate-100 text-slate-700 border border-slate-300'
                        }`}
                      >
                        {job.productionStatus}
                      </span>
                    </td>

                    <td className="py-2.5 px-3 text-center font-mono text-slate-600 whitespace-nowrap">
                      {formatTimeDisplay(job.startTime)}
                    </td>

                    <td className="py-2.5 px-3 text-center font-mono text-slate-600 whitespace-nowrap">
                      {formatTimeDisplay(job.endTime)}
                    </td>

                    <td className="py-2.5 px-3 text-center font-mono font-bold text-slate-900 whitespace-nowrap">
                      {job.totalTimeFormatted || '-'}
                    </td>

                    <td className="py-2.5 px-3 text-slate-600 max-w-xs truncate">
                      {job.remarks || '-'}
                    </td>

                    <td
                      className="py-2.5 px-3 text-center whitespace-nowrap"
                      onClick={(e) => e.stopPropagation()}
                    >
                      {job.drawing ? (
                        <button
                          onClick={() => onViewDrawing(job)}
                          className="p-1 text-amber-700 hover:text-amber-800 hover:bg-slate-100 rounded"
                          title="View Technical Drawing"
                        >
                          <Eye className="w-3.5 h-3.5" />
                        </button>
                      ) : (
                        <span className="text-slate-400">-</span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* In-App PDF Preview Dialog (Formal White) */}
      {pdfPreviewUrl && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 backdrop-blur-xs p-3 sm:p-5">
          <div className="relative w-full max-w-5xl h-[92vh] flex flex-col bg-white border border-slate-200 rounded-2xl shadow-2xl overflow-hidden">
            <div className="flex items-center justify-between px-5 py-3.5 bg-slate-50 border-b border-slate-200">
              <div className="flex items-center gap-2">
                <FileSpreadsheet className="w-5 h-5 text-amber-600" />
                <div>
                  <h3 className="font-bold text-slate-900 text-sm sm:text-base">
                    Monthly Job Ledger PDF Preview (A4 Format)
                  </h3>
                  <p className="text-xs text-slate-500">
                    ULTINO TOOL TECH • {currentMonthObj.name.toUpperCase()} {selectedYear}
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={handleDownloadPdf}
                  className="flex items-center gap-1.5 px-3 py-1.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs uppercase rounded-lg shadow-sm transition"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Download PDF</span>
                </button>
                <button
                  onClick={() => {
                    URL.revokeObjectURL(pdfPreviewUrl);
                    setPdfPreviewUrl(null);
                  }}
                  className="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-slate-100 transition"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            <div className="flex-1 bg-slate-100 p-2">
              <iframe
                src={pdfPreviewUrl}
                title="Monthly Ledger PDF"
                className="w-full h-full rounded border border-slate-300"
              />
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
