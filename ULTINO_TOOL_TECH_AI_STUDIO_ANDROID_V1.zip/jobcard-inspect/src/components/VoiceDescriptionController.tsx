import React, { useState, useEffect, useRef } from 'react';
import {
  Mic,
  MicOff,
  Square,
  Play,
  Pause,
  RotateCcw,
  Sparkles,
  Check,
  Copy,
  Trash2,
  Volume2,
  VolumeX,
  ChevronDown,
  ChevronUp,
  Settings2,
  HelpCircle,
  Radio,
  FileText,
  CornerDownLeft,
} from 'lucide-react';

interface VoiceDescriptionControllerProps {
  value: string;
  onChange: (newValue: string) => void;
  label?: string;
  placeholder?: string;
  helperText?: string;
  autoExpand?: boolean;
}

// Common languages for machine shop & manufacturing operations
const SUPPORTED_LANGUAGES = [
  { code: 'en-IN', name: 'English (India)', flag: '🇮🇳' },
  { code: 'en-US', name: 'English (US)', flag: '🇺🇸' },
  { code: 'en-GB', name: 'English (UK)', flag: '🇬🇧' },
  { code: 'ta-IN', name: 'Tamil (தமிழ்)', flag: '🇮🇳' },
  { code: 'hi-IN', name: 'Hindi (हिन्दी)', flag: '🇮🇳' },
  { code: 'te-IN', name: 'Telugu (తెలుగు)', flag: '🇮🇳' },
  { code: 'kn-IN', name: 'Kannada (ಕನ್ನಡ)', flag: '🇮🇳' },
  { code: 'mr-IN', name: 'Marathi (मराठी)', flag: '🇮🇳' },
];

// Quick toolroom & wire-cut EDM technical terms for quick tap insertion
const QUICK_TOOLROOM_TERMS = [
  { label: '± 0.005 mm', text: 'tolerance ±0.005mm' },
  { label: 'Taper 0.5°', text: 'taper cut 0.5 deg per side' },
  { label: 'D2 Hardened', text: 'D2 tool steel 58-62 HRC' },
  { label: 'Die Plate', text: 'progressive die punch plate' },
  { label: 'Contour EDM', text: 'precision contour wire EDM' },
  { label: 'Stripper Plate', text: 'guide stripper plate' },
  { label: 'Punch Insert', text: 'forming punch insert' },
  { label: 'Clearance 0.01', text: 'die clearance 0.01mm' },
  { label: '⏎ New Line', text: '\n' },
  { label: '· Comma ,', text: ', ' },
  { label: '· Period .', text: '. ' },
];

export const VoiceDescriptionController: React.FC<VoiceDescriptionControllerProps> = ({
  value,
  onChange,
  label = 'Description / Job Details',
  placeholder = 'Speak or type description (e.g. 12-cavity progressive punch die plate, D2 hardened steel...)',
  helperText,
  autoExpand = false,
}) => {
  // Voice & Audio States
  const [isExpanded, setIsExpanded] = useState<boolean>(autoExpand);
  const [isListening, setIsListening] = useState<boolean>(false);
  const [interimText, setInterimText] = useState<string>('');
  const [recognizedSessionText, setRecognizedSessionText] = useState<string>('');
  const [recordingSeconds, setRecordingSeconds] = useState<number>(0);
  const [selectedLanguage, setSelectedLanguage] = useState<string>('en-IN');
  const [writeMode, setWriteMode] = useState<'append' | 'replace'>('append');
  const [autoInsert, setAutoInsert] = useState<boolean>(true);
  const [audioLevel, setAudioLevel] = useState<number>(0);
  const [hasSpeechSupport, setHasSpeechSupport] = useState<boolean>(true);
  const [audioUrl, setAudioUrl] = useState<string | null>(null);
  const [isPlayingAudio, setIsPlayingAudio] = useState<boolean>(false);
  const [statusMessage, setStatusMessage] = useState<string>('Ready to dictate description');
  const [previousValue, setPreviousValue] = useState<string | null>(null);
  const [copied, setCopied] = useState<boolean>(false);

  // References
  const recognitionRef = useRef<any>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const audioContextRef = useRef<AudioContext | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);
  const animFrameRef = useRef<number | null>(null);
  const mediaStreamRef = useRef<MediaStream | null>(null);
  const audioPlayerRef = useRef<HTMLAudioElement | null>(null);
  const timerIntervalRef = useRef<any>(null);
  const textareaRef = useRef<HTMLTextAreaElement | null>(null);

  // Check Web Speech API support
  useEffect(() => {
    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      setHasSpeechSupport(false);
      setStatusMessage('Web Speech API not natively available in this browser. Microphone recording active.');
    }
  }, []);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      stopListening();
      if (audioUrl) {
        URL.revokeObjectURL(audioUrl);
      }
    };
  }, []);

  // Timer counter when recording
  useEffect(() => {
    if (isListening) {
      setRecordingSeconds(0);
      timerIntervalRef.current = setInterval(() => {
        setRecordingSeconds((prev) => prev + 1);
      }, 1000);
    } else {
      if (timerIntervalRef.current) {
        clearInterval(timerIntervalRef.current);
        timerIntervalRef.current = null;
      }
    }
    return () => {
      if (timerIntervalRef.current) {
        clearInterval(timerIntervalRef.current);
      }
    };
  }, [isListening]);

  // Audio level visualizer loop
  const startAudioVisualizer = (stream: MediaStream) => {
    try {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioCtx) return;
      const audioCtx = new AudioCtx();
      audioContextRef.current = audioCtx;
      const analyser = audioCtx.createAnalyser();
      analyser.fftSize = 64;
      analyserRef.current = analyser;
      const source = audioCtx.createMediaStreamSource(stream);
      source.connect(analyser);

      const bufferLength = analyser.frequencyBinCount;
      const dataArray = new Uint8Array(bufferLength);

      const updateVisualizer = () => {
        if (!analyserRef.current) return;
        analyserRef.current.getByteFrequencyData(dataArray);
        let sum = 0;
        for (let i = 0; i < bufferLength; i++) {
          sum += dataArray[i];
        }
        const avg = sum / bufferLength;
        // Normalize to 0-100
        const normalized = Math.min(100, Math.round((avg / 128) * 100));
        setAudioLevel(normalized);
        animFrameRef.current = requestAnimationFrame(updateVisualizer);
      };

      updateVisualizer();
    } catch (e) {
      console.warn('AudioContext visualizer not started:', e);
    }
  };

  const stopAudioVisualizer = () => {
    if (animFrameRef.current) {
      cancelAnimationFrame(animFrameRef.current);
      animFrameRef.current = null;
    }
    if (audioContextRef.current && audioContextRef.current.state !== 'closed') {
      audioContextRef.current.close().catch(() => {});
      audioContextRef.current = null;
    }
    setAudioLevel(0);
  };

  // Convert spoken text commands into proper formatting & punctuation
  const cleanSpokenText = (raw: string): string => {
    let text = raw.trim();
    if (!text) return '';

    // Replace spoken punctuation words
    text = text
      .replace(/\b(full stop|period|dot)\b/gi, '.')
      .replace(/\b(comma)\b/gi, ',')
      .replace(/\b(new line|next line)\b/gi, '\n')
      .replace(/\b(plus minus)\b/gi, '±')
      .replace(/\b(degree|degrees)\b/gi, '°')
      .replace(/\b(diameter)\b/gi, 'Ø')
      .replace(/\b(hrc|rockwell)\b/gi, 'HRC')
      .replace(/\b(edm)\b/gi, 'EDM')
      .replace(/\b(cnc)\b/gi, 'CNC')
      .replace(/\b(d2)\b/gi, 'D2')
      .replace(/\b(m m|m\.m\.)\b/gi, 'mm');

    // Capitalize first letter
    if (text.length > 0) {
      text = text.charAt(0).toUpperCase() + text.slice(1);
    }

    return text;
  };

  // Apply transcribed words to main description state
  const applyWordsToDescription = (textToApply: string) => {
    if (!textToApply.trim()) return;
    const formatted = cleanSpokenText(textToApply);

    setPreviousValue(value);

    if (writeMode === 'replace') {
      onChange(formatted);
    } else {
      // Append mode
      if (!value || value.trim() === '') {
        onChange(formatted);
      } else {
        const lastChar = value.trim().slice(-1);
        const separator = lastChar === '.' || lastChar === ',' || lastChar === '\n' ? ' ' : ', ';
        onChange(`${value.trim()}${separator}${formatted}`);
      }
    }
  };

  // Start Voice Recognition and Audio Recording
  const startListening = async () => {
    setStatusMessage('Requesting microphone access...');
    setInterimText('');
    setRecognizedSessionText('');

    try {
      // 1. Get Microphone stream for visualizer and audio recording
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      mediaStreamRef.current = stream;
      startAudioVisualizer(stream);

      // Setup MediaRecorder to save audio clip
      try {
        audioChunksRef.current = [];
        const mediaRecorder = new MediaRecorder(stream);
        mediaRecorderRef.current = mediaRecorder;
        mediaRecorder.ondataavailable = (event) => {
          if (event.data && event.data.size > 0) {
            audioChunksRef.current.push(event.data);
          }
        };
        mediaRecorder.onstop = () => {
          if (audioChunksRef.current.length > 0) {
            const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
            if (audioUrl) URL.revokeObjectURL(audioUrl);
            const url = URL.createObjectURL(audioBlob);
            setAudioUrl(url);
          }
        };
        mediaRecorder.start();
      } catch (recErr) {
        console.warn('MediaRecorder error:', recErr);
      }

      // 2. Setup Web Speech Recognition
      const SpeechRecognition =
        (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

      if (SpeechRecognition) {
        const recognition = new SpeechRecognition();
        recognitionRef.current = recognition;
        recognition.continuous = true;
        recognition.interimResults = true;
        recognition.lang = selectedLanguage;

        recognition.onstart = () => {
          setIsListening(true);
          setStatusMessage('Listening to your voice... Speak clearly.');
        };

        recognition.onresult = (event: any) => {
          let interim = '';
          let finalTranscript = '';

          for (let i = event.resultIndex; i < event.results.length; ++i) {
            const transcript = event.results[i][0].transcript;
            if (event.results[i].isFinal) {
              finalTranscript += transcript + ' ';
            } else {
              interim += transcript;
            }
          }

          if (interim) {
            setInterimText(interim);
          }

          if (finalTranscript) {
            const cleaned = cleanSpokenText(finalTranscript);
            setRecognizedSessionText((prev) => (prev ? `${prev} ${cleaned}` : cleaned));
            setInterimText('');
            setStatusMessage(`Captured: "${cleaned}"`);

            // If auto-insert is enabled, immediately inject into description
            if (autoInsert) {
              applyWordsToDescription(cleaned);
            }
          }
        };

        recognition.onerror = (event: any) => {
          console.warn('Speech recognition error:', event.error);
          if (event.error === 'no-speech') {
            setStatusMessage('No speech detected. Listening...');
          } else if (event.error === 'not-allowed') {
            setStatusMessage('Microphone permission blocked. Please enable it in browser settings.');
            stopListening();
          } else if (event.error === 'network') {
            setStatusMessage('Network error in speech service. Retrying or using manual speech input.');
          } else {
            setStatusMessage(`Speech note: ${event.error}. Speak again.`);
          }
        };

        recognition.onend = () => {
          // If still marked as listening, restart or close cleanly
          if (isListening) {
            try {
              recognition.start();
            } catch (e) {
              setIsListening(false);
            }
          }
        };

        recognition.start();
      } else {
        // Fallback if SpeechRecognition is missing in browser
        setIsListening(true);
        setStatusMessage('Recording audio (Web Speech API not present). Use technical term chips or type below.');
      }
    } catch (err: any) {
      console.error('Failed to access microphone:', err);
      setStatusMessage('Microphone access denied or not found. Check browser permissions.');
      setIsListening(false);
      stopAudioVisualizer();
    }
  };

  // Stop Voice Recognition and Audio Recording
  const stopListening = () => {
    setIsListening(false);
    setStatusMessage('Voice recording stopped.');

    // Stop Speech Recognition
    if (recognitionRef.current) {
      try {
        recognitionRef.current.stop();
      } catch (e) {}
      recognitionRef.current = null;
    }

    // Stop MediaRecorder
    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
      try {
        mediaRecorderRef.current.stop();
      } catch (e) {}
    }

    // Stop Media Stream Tracks
    if (mediaStreamRef.current) {
      mediaStreamRef.current.getTracks().forEach((track) => track.stop());
      mediaStreamRef.current = null;
    }

    stopAudioVisualizer();

    // If there was any pending interim text and auto-insert wasn't applied
    if (interimText && !autoInsert) {
      setRecognizedSessionText((prev) => (prev ? `${prev} ${interimText}` : interimText));
    }
    setInterimText('');
  };

  // Toggle voice recognition
  const handleToggleVoice = () => {
    if (isListening) {
      stopListening();
    } else {
      setIsExpanded(true);
      startListening();
    }
  };

  // Playback recorded audio
  const handleToggleAudioPlay = () => {
    if (!audioPlayerRef.current || !audioUrl) return;
    if (isPlayingAudio) {
      audioPlayerRef.current.pause();
      setIsPlayingAudio(false);
    } else {
      audioPlayerRef.current.play().then(() => {
        setIsPlayingAudio(true);
      }).catch((e) => console.warn('Audio play error:', e));
    }
  };

  // Quick chip click
  const handleInsertQuickTerm = (term: string) => {
    applyWordsToDescription(term);
  };

  // Undo last action
  const handleUndo = () => {
    if (previousValue !== null) {
      onChange(previousValue);
      setPreviousValue(null);
      setStatusMessage('Reverted last description change.');
    }
  };

  // Clear text
  const handleClearDescription = () => {
    if (value) {
      setPreviousValue(value);
      onChange('');
      setStatusMessage('Description cleared. (Click Undo to restore)');
    }
  };

  // Copy text to clipboard
  const handleCopy = () => {
    if (!value) return;
    navigator.clipboard.writeText(value);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  // Format seconds mm:ss
  const formatTime = (secs: number) => {
    const mins = Math.floor(secs / 60);
    const rem = secs % 60;
    return `${mins.toString().padStart(2, '0')}:${rem.toString().padStart(2, '0')}`;
  };

  return (
    <div className="space-y-2">
      {/* Top Header & Voice Controller Trigger Bar */}
      <div className="flex flex-wrap items-center justify-between gap-2">
        <label className="text-xs font-bold uppercase tracking-wider text-slate-700 flex items-center gap-1.5">
          <FileText className="w-3.5 h-3.5 text-slate-400" />
          <span>{label}</span>
        </label>

        {/* Tactical Voice Controller Buttons */}
        <div className="flex items-center gap-2">
          {/* Quick Mic Button */}
          <button
            type="button"
            onClick={handleToggleVoice}
            className={`inline-flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-bold transition-all shadow-xs ${
              isListening
                ? 'bg-rose-600 text-white animate-pulse ring-2 ring-rose-300'
                : 'bg-amber-500 hover:bg-amber-600 text-slate-950 font-black'
            }`}
            title={isListening ? 'Click to stop voice recording' : 'Click to speak and convert voice to words'}
          >
            {isListening ? (
              <>
                <Square className="w-3.5 h-3.5 fill-current" />
                <span>Stop Listening ({formatTime(recordingSeconds)})</span>
              </>
            ) : (
              <>
                <Mic className="w-3.5 h-3.5" />
                <span>Voice Controller (Audio to Words)</span>
              </>
            )}
          </button>

          {/* Expand / Minimize Deck */}
          <button
            type="button"
            onClick={() => setIsExpanded(!isExpanded)}
            className="p-1.5 rounded-lg border border-slate-200 text-slate-600 hover:bg-slate-100 transition-colors"
            title={isExpanded ? 'Collapse Voice Controller Deck' : 'Expand Voice Controller Deck'}
          >
            {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
          </button>
        </div>
      </div>

      {/* Expanded Voice Controller Deck */}
      {isExpanded && (
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-3.5 text-white shadow-md space-y-3 transition-all">
          {/* Deck Header: Status, Timer, Controls */}
          <div className="flex flex-wrap items-center justify-between gap-3 pb-2.5 border-b border-slate-800">
            <div className="flex items-center gap-2.5">
              <div
                className={`w-3 h-3 rounded-full ${
                  isListening
                    ? 'bg-rose-500 animate-ping'
                    : audioUrl
                    ? 'bg-emerald-400'
                    : 'bg-amber-400'
                }`}
              />
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-xs font-black tracking-wide uppercase text-slate-200">
                    Voice Dictation Deck
                  </span>
                  <span className="text-[10px] px-1.5 py-0.5 rounded bg-slate-800 text-amber-400 font-mono">
                    {isListening ? `REC ${formatTime(recordingSeconds)}` : 'STANDBY'}
                  </span>
                </div>
                <p className="text-[11px] text-slate-400 truncate max-w-xs sm:max-w-md">
                  {statusMessage}
                </p>
              </div>
            </div>

            {/* Language & Write Mode Selectors */}
            <div className="flex items-center gap-2 flex-wrap">
              {/* Language Selector */}
              <div className="flex items-center gap-1 bg-slate-800 rounded-md px-2 py-1 text-xs">
                <span className="text-[10px] text-slate-400 uppercase font-mono">Lang:</span>
                <select
                  value={selectedLanguage}
                  onChange={(e) => {
                    setSelectedLanguage(e.target.value);
                    if (isListening) {
                      stopListening();
                      setTimeout(() => startListening(), 200);
                    }
                  }}
                  className="bg-transparent text-xs text-white focus:outline-none cursor-pointer"
                  disabled={isListening}
                >
                  {SUPPORTED_LANGUAGES.map((lang) => (
                    <option key={lang.code} value={lang.code} className="bg-slate-900 text-white">
                      {lang.flag} {lang.name}
                    </option>
                  ))}
                </select>
              </div>

              {/* Mode: Append vs Replace */}
              <div className="flex items-center bg-slate-800 rounded-md p-0.5 text-[11px]">
                <button
                  type="button"
                  onClick={() => setWriteMode('append')}
                  className={`px-2 py-1 rounded font-medium transition-colors ${
                    writeMode === 'append' ? 'bg-amber-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-white'
                  }`}
                  title="Spoken words will append to existing text"
                >
                  Append
                </button>
                <button
                  type="button"
                  onClick={() => setWriteMode('replace')}
                  className={`px-2 py-1 rounded font-medium transition-colors ${
                    writeMode === 'replace' ? 'bg-amber-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-white'
                  }`}
                  title="Spoken words will overwrite existing text"
                >
                  Replace
                </button>
              </div>
            </div>
          </div>

          {/* Live Audio Visualizer & Waveform Bar */}
          <div className="bg-slate-950/70 rounded-lg p-2.5 border border-slate-800/80 flex items-center justify-between gap-3">
            {/* Visualizer bars */}
            <div className="flex-1 flex items-center gap-1 h-8 px-2">
              {[...Array(20)].map((_, i) => {
                // Generate dynamic height based on audio level and bar index
                const offset = (Math.sin((i / 20) * Math.PI) * audioLevel) / 100;
                const dynamicHeight = isListening ? Math.max(12, Math.min(100, Math.round(offset * 100))) : 10;
                return (
                  <div
                    key={i}
                    className={`flex-1 rounded-full transition-all duration-75 ${
                      isListening
                        ? dynamicHeight > 50
                          ? 'bg-rose-500'
                          : 'bg-amber-400'
                        : 'bg-slate-700'
                    }`}
                    style={{ height: `${dynamicHeight}%` }}
                  />
                );
              })}
            </div>

            {/* Audio Recorder Playback controls */}
            {audioUrl && (
              <div className="flex items-center gap-1.5 pl-2 border-l border-slate-800 shrink-0">
                <button
                  type="button"
                  onClick={handleToggleAudioPlay}
                  className="p-1.5 rounded-md bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs flex items-center gap-1"
                  title="Play back recorded voice audio"
                >
                  {isPlayingAudio ? (
                    <>
                      <Pause className="w-3.5 h-3.5 text-amber-400" />
                      <span className="text-[10px]">Pause</span>
                    </>
                  ) : (
                    <>
                      <Play className="w-3.5 h-3.5 text-amber-400" />
                      <span className="text-[10px]">Play Audio</span>
                    </>
                  )}
                </button>
                <audio
                  ref={audioPlayerRef}
                  src={audioUrl}
                  onEnded={() => setIsPlayingAudio(false)}
                  className="hidden"
                />
              </div>
            )}
          </div>

          {/* Live Words & Interim Transcription Display */}
          {(isListening || interimText || recognizedSessionText) && (
            <div className="bg-slate-950 border border-amber-500/30 rounded-lg p-2.5 text-xs font-mono">
              <div className="flex items-center justify-between text-[10px] text-amber-400 uppercase font-bold mb-1">
                <span className="flex items-center gap-1">
                  <Radio className="w-3 h-3 animate-pulse" />
                  Live Spoken Words Stream
                </span>
                <span>Auto-Insert: {autoInsert ? 'Active' : 'Off'}</span>
              </div>
              <div className="text-slate-100 min-h-[28px] break-words">
                {recognizedSessionText && (
                  <span className="text-slate-200">{recognizedSessionText} </span>
                )}
                {interimText && (
                  <span className="text-amber-400 italic bg-amber-950/60 px-1 rounded animate-pulse">
                    {interimText}...
                  </span>
                )}
                {!recognizedSessionText && !interimText && (
                  <span className="text-slate-500 italic">Listening for machine description...</span>
                )}
              </div>
            </div>
          )}

          {/* Quick Technical Terms & Punctuation Chips */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
                1-Tap Technical Keywords & Punctuations:
              </span>
              <span className="text-[10px] text-slate-400">Tap to add instantly</span>
            </div>
            <div className="flex flex-wrap gap-1.5">
              {QUICK_TOOLROOM_TERMS.map((term, index) => (
                <button
                  key={index}
                  type="button"
                  onClick={() => handleInsertQuickTerm(term.text)}
                  className="px-2 py-1 bg-slate-800 hover:bg-slate-700 active:bg-amber-500 active:text-slate-950 text-slate-300 rounded text-[11px] font-medium transition-colors border border-slate-700/60 hover:border-slate-600"
                >
                  {term.label}
                </button>
              ))}
            </div>
          </div>

          {/* Deck Action Bar: Apply, Undo, Clear, Auto-sync */}
          <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-slate-800 text-xs">
            <div className="flex items-center gap-2">
              <label className="flex items-center gap-1.5 cursor-pointer text-slate-400 hover:text-slate-200 select-none text-[11px]">
                <input
                  type="checkbox"
                  checked={autoInsert}
                  onChange={(e) => setAutoInsert(e.target.checked)}
                  className="rounded border-slate-700 text-amber-500 focus:ring-amber-400 bg-slate-800"
                />
                <span>Stream words directly into description box</span>
              </label>
            </div>

            <div className="flex items-center gap-1.5">
              {previousValue !== null && (
                <button
                  type="button"
                  onClick={handleUndo}
                  className="px-2 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded text-xs flex items-center gap-1"
                  title="Undo last change"
                >
                  <RotateCcw className="w-3 h-3 text-amber-400" />
                  <span>Undo</span>
                </button>
              )}

              {value && (
                <>
                  <button
                    type="button"
                    onClick={handleCopy}
                    className="px-2 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded text-xs flex items-center gap-1"
                    title="Copy description"
                  >
                    {copied ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                    <span>{copied ? 'Copied' : 'Copy'}</span>
                  </button>

                  <button
                    type="button"
                    onClick={handleClearDescription}
                    className="px-2 py-1 bg-slate-800 hover:bg-rose-950 text-rose-300 hover:text-rose-200 rounded text-xs flex items-center gap-1"
                    title="Clear description"
                  >
                    <Trash2 className="w-3 h-3" />
                    <span>Clear</span>
                  </button>
                </>
              )}

              <button
                type="button"
                onClick={() => setIsExpanded(false)}
                className="px-2.5 py-1 bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold rounded text-xs"
              >
                Done
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Main Description Textarea */}
      <div className="relative">
        <textarea
          ref={textareaRef}
          value={value}
          onChange={(e) => onChange(e.target.value)}
          rows={3}
          placeholder={placeholder}
          className="w-full bg-white border border-slate-300 rounded-lg p-3 text-sm text-slate-900 placeholder-slate-400 focus:outline-none focus:border-amber-500 focus:ring-1 focus:ring-amber-500 leading-relaxed"
        />

        {/* Floating Quick Mic Icon inside textarea (bottom-right) */}
        <div className="absolute right-2.5 bottom-2.5 flex items-center gap-1">
          <button
            type="button"
            onClick={handleToggleVoice}
            className={`p-1.5 rounded-md transition-all ${
              isListening
                ? 'bg-rose-600 text-white animate-pulse'
                : 'bg-slate-100 hover:bg-amber-100 text-slate-600 hover:text-amber-800'
            }`}
            title={isListening ? 'Stop voice recording' : 'Dictate with voice'}
          >
            <Mic className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Helper text or shortcut hints */}
      <div className="flex items-center justify-between text-[11px] text-slate-500">
        <span>
          {helperText ||
            'Tip: Say "comma", "period", "new line", "tolerance", "taper", or "die plate" while dictating.'}
        </span>
        <span className="font-mono text-slate-400">{value.length} chars</span>
      </div>
    </div>
  );
};
