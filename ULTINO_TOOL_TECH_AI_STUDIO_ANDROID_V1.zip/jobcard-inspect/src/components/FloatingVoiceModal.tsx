import React, { useState } from 'react';
import { Mic, X, Sparkles, Copy, Check, ArrowRight } from 'lucide-react';
import { VoiceDescriptionController } from './VoiceDescriptionController';

interface FloatingVoiceModalProps {
  isOpen: boolean;
  onClose: () => void;
  onApplyToNewJob: (transcribedDescription: string) => void;
}

export const FloatingVoiceModal: React.FC<FloatingVoiceModalProps> = ({
  isOpen,
  onClose,
  onApplyToNewJob,
}) => {
  const [descriptionText, setDescriptionText] = useState('');
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const handleCopy = () => {
    if (!descriptionText) return;
    navigator.clipboard.writeText(descriptionText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleCreateJob = () => {
    onApplyToNewJob(descriptionText);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/60 backdrop-blur-xs animate-in fade-in duration-150">
      <div className="bg-white border border-slate-200 rounded-2xl shadow-2xl max-w-lg w-full p-4 sm:p-5 relative animate-in zoom-in-95 duration-150">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 mb-3 border-b border-slate-100">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-amber-500 text-slate-950 flex items-center justify-center">
              <Mic className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-black text-slate-900 uppercase tracking-wide">
                Voice Controller · Audio to Words
              </h3>
              <p className="text-[11px] text-slate-500">
                Dictate machine job specs & descriptions hands-free
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Voice Controller Component with autoExpand=true */}
        <VoiceDescriptionController
          value={descriptionText}
          onChange={setDescriptionText}
          label="Spoken Description / Technical Notes"
          placeholder="Tap Start Listening to speak: e.g. 12-cavity progressive punch die plate, D2 hardened steel, tolerance ±0.005mm..."
          autoExpand={true}
        />

        {/* Footer Actions */}
        <div className="flex items-center justify-between pt-3 mt-3 border-t border-slate-100">
          <button
            type="button"
            onClick={onClose}
            className="px-3 py-1.5 text-xs font-semibold text-slate-600 hover:text-slate-900"
          >
            Close
          </button>

          <div className="flex items-center gap-2">
            {descriptionText && (
              <button
                type="button"
                onClick={handleCopy}
                className="px-3 py-1.5 rounded-lg border border-slate-200 text-slate-700 hover:bg-slate-50 text-xs font-bold flex items-center gap-1.5 transition-colors"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copied ? 'Copied' : 'Copy Words'}</span>
              </button>
            )}

            <button
              type="button"
              disabled={!descriptionText.trim()}
              onClick={handleCreateJob}
              className="px-3.5 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 disabled:opacity-50 disabled:cursor-not-allowed text-white text-xs font-bold flex items-center gap-1.5 shadow-sm transition-all"
            >
              <span>Apply to New Job</span>
              <ArrowRight className="w-3.5 h-3.5 text-amber-400" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
