import React from 'react';
import {
  X,
  Printer,
  Edit3,
  Calendar,
  Building2,
  Layers,
  FileText,
  Eye,
} from 'lucide-react';
import { Job } from '../types';
import { formatDateDisplay } from '../services/pdfGenerator';

interface JobViewModalProps {
  job: Job | null;
  onClose: () => void;
  onEdit: (job: Job) => void;
  onPrint: (job: Job) => void;
  onViewDrawing: (job: Job) => void;
}

export const JobViewModal: React.FC<JobViewModalProps> = ({
  job,
  onClose,
  onEdit,
  onPrint,
  onViewDrawing,
}) => {
  if (!job) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 backdrop-blur-xs p-3 sm:p-4">
      <div className="relative w-full max-w-2xl bg-white border border-slate-200 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh] text-slate-900">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 bg-slate-50 border-b border-slate-200">
          <div className="flex items-center gap-3">
            <div>
              <div className="flex items-center gap-2">
                <span className="px-2 py-0.5 text-xs font-black bg-slate-900 text-amber-400 rounded tracking-wider font-mono">
                  {job.jobNumber}
                </span>
                <span className="text-xs font-bold text-slate-500">DIGITAL JOB CARD</span>
              </div>
              <h2 className="text-base font-black text-slate-900">{job.itemName}</h2>
            </div>
          </div>

          <div className="flex items-center gap-1.5">
            <button
              onClick={() => onPrint(job)}
              className="p-2 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-lg transition"
              title="Print Travel Card"
            >
              <Printer className="w-4 h-4" />
            </button>
            <button
              onClick={() => {
                onClose();
                onEdit(job);
              }}
              className="p-2 text-slate-600 hover:text-amber-700 hover:bg-slate-100 rounded-lg transition"
              title="Edit Job"
            >
              <Edit3 className="w-4 h-4" />
            </button>
            <button
              onClick={onClose}
              className="p-2 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-lg transition"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto p-5 space-y-4 text-xs sm:text-sm">
          {/* Status & Date bar */}
          <div className="flex flex-wrap items-center justify-between gap-2 p-3 bg-slate-50 border border-slate-200 rounded-xl">
            <div className="flex items-center gap-2">
              <span className="text-slate-500 font-bold uppercase text-[10px]">
                Production Status:
              </span>
              <span
                className={`px-2.5 py-0.5 text-xs font-black uppercase rounded ${
                  job.productionStatus === 'Completed'
                    ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                    : job.productionStatus === 'Production'
                    ? 'bg-amber-100 text-amber-800 border border-amber-300'
                    : 'bg-slate-200 text-slate-700 border border-slate-300'
                }`}
              >
                {job.productionStatus}
              </span>
            </div>

            <div className="flex items-center gap-1.5 text-slate-600 font-mono text-xs">
              <Calendar className="w-4 h-4 text-slate-400" />
              <span>Date: {formatDateDisplay(job.date)}</span>
            </div>
          </div>

          {/* Customer & Item Details */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-xl">
              <div className="flex items-center gap-1.5 text-slate-500 font-bold uppercase text-[10px] mb-1">
                <Building2 className="w-3.5 h-3.5 text-amber-600" />
                <span>Customer</span>
              </div>
              <p className="text-sm font-bold text-slate-900">{job.customerName}</p>
            </div>

            <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-xl">
              <div className="flex items-center gap-1.5 text-slate-500 font-bold uppercase text-[10px] mb-1">
                <Layers className="w-3.5 h-3.5 text-amber-600" />
                <span>Item Name</span>
              </div>
              <p className="text-sm font-bold text-slate-900">{job.itemName}</p>
            </div>
          </div>

          {/* Description */}
          {job.description && (
            <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-xl">
              <span className="text-slate-500 font-bold uppercase text-[10px] block mb-1">
                Description / Spec
              </span>
              <p className="text-slate-700">{job.description}</p>
            </div>
          )}

          {/* Specs */}
          <div className="grid grid-cols-3 gap-2 text-center">
            <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl">
              <span className="text-slate-500 font-bold uppercase text-[10px] block mb-1">
                Path Length
              </span>
              <p className="text-sm font-mono font-bold text-slate-900">{job.pathLength || '-'}</p>
            </div>

            <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl">
              <span className="text-slate-500 font-bold uppercase text-[10px] block mb-1">
                Thickness
              </span>
              <p className="text-sm font-mono font-bold text-slate-900">{job.thickness || '-'}</p>
            </div>

            <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl">
              <span className="text-slate-500 font-bold uppercase text-[10px] block mb-1">
                Quantity
              </span>
              <p className="text-sm font-bold text-amber-700">{job.quantity} pcs</p>
            </div>
          </div>

          {/* Drawing Preview */}
          <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-xl">
            <div className="flex items-center justify-between mb-2">
              <span className="text-slate-500 font-bold uppercase text-[10px]">
                Attached Technical Drawing
              </span>
              {job.drawing && (
                <button
                  onClick={() => onViewDrawing(job)}
                  className="text-amber-700 hover:text-amber-800 text-xs font-bold flex items-center gap-1 underline"
                >
                  <Eye className="w-3.5 h-3.5" />
                  <span>Full Screen View</span>
                </button>
              )}
            </div>

            {job.drawing ? (
              <div
                onClick={() => onViewDrawing(job)}
                className="relative bg-white rounded-lg overflow-hidden border border-slate-200 h-44 flex items-center justify-center cursor-pointer group shadow-2xs"
              >
                {job.drawing.fileType === 'application/pdf' ? (
                  <div className="text-center p-4">
                    <FileText className="w-10 h-10 text-amber-600 mx-auto mb-2" />
                    <span className="text-xs font-bold text-slate-800 block">{job.drawing.fileName}</span>
                    <span className="text-[10px] text-amber-700 font-bold">CLICK TO VIEW PDF</span>
                  </div>
                ) : (
                  <img
                    src={job.drawing.dataUrl}
                    alt="Workpiece Drawing"
                    className="max-h-full max-w-full object-contain group-hover:scale-105 transition-transform"
                  />
                )}
                <div className="absolute inset-0 bg-slate-900/30 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity">
                  <span className="px-3 py-1 bg-white text-slate-900 font-bold text-xs uppercase rounded-md shadow">
                    Enlarge Drawing
                  </span>
                </div>
              </div>
            ) : (
              <p className="text-slate-400 text-xs italic py-2">No drawing attached to this job.</p>
            )}
          </div>

          {/* Machining Timings */}
          <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-xl space-y-2">
            <span className="text-slate-500 font-bold uppercase text-[10px] block">
              Machining Timings
            </span>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
              <div>
                <span className="text-[10px] text-slate-500 block">Start Time</span>
                <span className="text-xs font-mono font-bold text-slate-800">
                  {job.startTime ? new Date(job.startTime).toLocaleString() : 'Not Recorded'}
                </span>
              </div>
              <div>
                <span className="text-[10px] text-slate-500 block">End Time</span>
                <span className="text-xs font-mono font-bold text-slate-800">
                  {job.endTime ? new Date(job.endTime).toLocaleString() : 'Not Recorded'}
                </span>
              </div>
              <div>
                <span className="text-[10px] text-slate-500 block">Total Time</span>
                <span className="text-sm font-black text-amber-700 font-mono">
                  {job.totalTimeFormatted || '0 min'}
                </span>
              </div>
            </div>
          </div>

          {/* Remarks */}
          {job.remarks && (
            <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-xl">
              <span className="text-slate-500 font-bold uppercase text-[10px] block mb-1">
                Remarks / Special Instructions
              </span>
              <p className="text-slate-700">{job.remarks}</p>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between px-5 py-3 bg-slate-50 border-t border-slate-200">
          <span className="text-[11px] text-slate-500 font-mono">ID: {job.id}</span>
          <div className="flex items-center gap-2">
            <button
              onClick={() => onPrint(job)}
              className="px-3 py-1.5 bg-white hover:bg-slate-100 text-slate-800 font-bold text-xs uppercase rounded-lg border border-slate-300 flex items-center gap-1.5 transition shadow-2xs"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print Travel Card</span>
            </button>
            <button
              onClick={() => {
                onClose();
                onEdit(job);
              }}
              className="px-4 py-1.5 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 text-slate-950 font-black text-xs uppercase rounded-lg shadow-sm transition"
            >
              Edit Job
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
