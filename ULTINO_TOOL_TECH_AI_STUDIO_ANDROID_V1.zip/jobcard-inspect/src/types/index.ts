export type ProductionStatus = 'Not Started' | 'Pending' | 'Production' | 'Completed';

export interface Customer {
  id: string;
  name: string;
  phone?: string;
  contactPerson?: string;
  email?: string;
  address?: string;
  notes?: string;
  createdAt: string;
  updatedAt: string;
}

export interface Item {
  id: string;
  name: string;
  customerId: string;
  customerName: string;
  productionStatus: ProductionStatus;
  description?: string;
  defaultPathLength?: string;
  defaultThickness?: string;
  createdAt: string;
  updatedAt: string;
}

export interface JobDrawing {
  dataUrl: string;
  fileName: string;
  fileType: string;
  fileSize?: number;
  uploadedAt: string;
}

export interface Job {
  id: string;
  jobNumber: string; // e.g. "JOB 001"
  serialNumberIndex: number; // e.g. 1
  date: string; // YYYY-MM-DD
  customerId: string;
  customerName: string;
  itemId: string;
  itemName: string;
  description: string;
  pathLength: string;
  thickness: string;
  quantity: number;
  remarks: string;
  drawing?: JobDrawing;
  productionStatus: 'Pending' | 'Production' | 'Completed';
  startTime?: string; // ISO string
  endTime?: string; // ISO string
  totalTimeMinutes?: number;
  totalTimeFormatted?: string; // e.g. "4 hr 25 min"
  createdAt: string;
  updatedAt: string;
}

export interface BackupData {
  version: string;
  appName: string;
  exportedAt: string;
  customers: Customer[];
  items: Item[];
  jobs: Job[];
  nextJobSerial: number;
}
