import React, { useState, useEffect, useCallback } from 'react';
import { Customer, Item, Job, JobDrawing } from './types';
import { StorageService, calculateDuration } from './services/storage';
import { Navbar, NavTab } from './components/Navbar';
import { Dashboard } from './components/Dashboard';
import { JobCardForm } from './components/JobCardForm';
import { ProductionScreen } from './components/ProductionScreen';
import { JobHistory } from './components/JobHistory';
import { CustomerMaster } from './components/CustomerMaster';
import { ItemMaster } from './components/ItemMaster';
import { MonthlyLedger } from './components/MonthlyLedger';
import { BackupSettings } from './components/BackupSettings';
import { JobViewModal } from './components/JobViewModal';
import { DrawingViewerModal } from './components/DrawingViewerModal';
import { JobPrintView } from './components/JobPrintView';
import { FloatingVoiceModal } from './components/FloatingVoiceModal';
import { CheckCircle2, AlertCircle, Wrench, X, Mic } from 'lucide-react';

export default function App() {
  // Navigation
  const [activeTab, setActiveTab] = useState<NavTab>('dashboard');

  // Core Data State
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [items, setItems] = useState<Item[]>([]);
  const [jobs, setJobs] = useState<Job[]>([]);
  const [nextSerial, setNextSerial] = useState<{ serialIndex: number; formatted: string }>({
    serialIndex: 1,
    formatted: 'JOB 001',
  });
  const [isLoading, setIsLoading] = useState(true);

  // Active Modals & Form targets
  const [jobToEdit, setJobToEdit] = useState<Job | null>(null);
  const [jobToView, setJobToView] = useState<Job | null>(null);
  const [jobToPrint, setJobToPrint] = useState<Job | null>(null);
  const [activeDrawing, setActiveDrawing] = useState<{
    drawing: JobDrawing;
    title: string;
  } | null>(null);

  // Floating Voice Controller Modal
  const [isVoiceModalOpen, setIsVoiceModalOpen] = useState(false);

  // Toast notifications
  const [toast, setToast] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  const showToast = (type: 'success' | 'error', message: string) => {
    setToast({ type, message });
    setTimeout(() => {
      setToast((curr) => (curr?.message === message ? null : curr));
    }, 4000);
  };

  // Load all data from permanent IndexedDB database
  const loadDatabase = useCallback(async () => {
    try {
      await StorageService.init();
      const [allCustomers, allItems, allJobs, serialInfo] = await Promise.all([
        StorageService.getCustomers(),
        StorageService.getItems(),
        StorageService.getJobs(),
        StorageService.getNextJobSerialNumber(),
      ]);

      setCustomers(allCustomers);
      setItems(allItems);
      setJobs(allJobs);
      setNextSerial(serialInfo);
    } catch (err) {
      console.error('Failed to load storage:', err);
      showToast('error', 'Error reading database from storage.');
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    loadDatabase();
  }, [loadDatabase]);

  // Production Count for Navbar live badge
  const productionCount = jobs.filter((j) => j.productionStatus === 'Production').length;

  // Save Job Card (Create or Update)
  const handleSaveJob = async (job: Job) => {
    try {
      await StorageService.saveJob(job);
      await loadDatabase();
      setJobToEdit(null);
      showToast('success', `Job Card ${job.jobNumber} successfully saved!`);
      // Navigate to Production if in production, or Job History
      if (job.productionStatus === 'Production') {
        setActiveTab('production');
      } else {
        setActiveTab('job_history');
      }
    } catch (err: any) {
      showToast('error', err?.message || 'Failed to save job card.');
      throw err;
    }
  };

  // Delete Job Card
  const handleDeleteJob = async (jobId: string) => {
    try {
      await StorageService.deleteJob(jobId);
      await loadDatabase();
      showToast('success', 'Job Card deleted safely. Customer & item records preserved.');
    } catch (err: any) {
      showToast('error', err?.message || 'Failed to delete job.');
      throw err;
    }
  };

  // Save Customer Master
  const handleSaveCustomer = async (customer: Customer) => {
    try {
      await StorageService.saveCustomer(customer);
      await loadDatabase();
      showToast('success', `Customer "${customer.name}" saved in master database.`);
    } catch (err: any) {
      showToast('error', err?.message || 'Failed to save customer.');
      throw err;
    }
  };

  // Delete Customer Master (Safe check)
  const handleDeleteCustomer = async (customerId: string) => {
    try {
      const res = await StorageService.deleteCustomer(customerId);
      if (res.success) {
        await loadDatabase();
        showToast('success', 'Customer deleted from master.');
      }
      return res;
    } catch (err: any) {
      showToast('error', err?.message || 'Failed to delete customer.');
      throw err;
    }
  };

  // Save Item Master
  const handleSaveItem = async (item: Item) => {
    try {
      await StorageService.saveItem(item);
      await loadDatabase();
      showToast('success', `Item "${item.name}" saved in master catalog.`);
    } catch (err: any) {
      showToast('error', err?.message || 'Failed to save item.');
      throw err;
    }
  };

  // Delete Item Master (Safe check)
  const handleDeleteItem = async (itemId: string) => {
    try {
      const res = await StorageService.deleteItem(itemId);
      if (res.success) {
        await loadDatabase();
        showToast('success', 'Item deleted from master.');
      }
      return res;
    } catch (err: any) {
      showToast('error', err?.message || 'Failed to delete item.');
      throw err;
    }
  };

  // Quick Status Update
  const handleStatusChange = async (
    job: Job,
    newStatus: 'Pending' | 'Production' | 'Completed'
  ) => {
    try {
      const updatedJob = { ...job, productionStatus: newStatus };
      if (newStatus === 'Production' && !updatedJob.startTime) {
        updatedJob.startTime = new Date().toISOString();
      }
      if (newStatus === 'Completed') {
        if (!updatedJob.endTime) {
          updatedJob.endTime = new Date().toISOString();
        }
        if (updatedJob.startTime && updatedJob.endTime) {
          const { formatted, minutes } = calculateDuration(
            updatedJob.startTime,
            updatedJob.endTime
          );
          updatedJob.totalTimeFormatted = formatted;
          updatedJob.totalTimeMinutes = minutes;
        }
      }
      await StorageService.saveJob(updatedJob);
      await loadDatabase();
      showToast('success', `${job.jobNumber} status updated to ${newStatus}.`);
    } catch (err: any) {
      showToast('error', err?.message || 'Failed to update job status.');
    }
  };

  // Quick Start Job Handler
  const handleStartJob = async (job: Job) => {
    const nowIso = new Date().toISOString();
    const updatedJob: Job = {
      ...job,
      productionStatus: 'Production',
      startTime: nowIso,
      endTime: undefined,
    };
    await StorageService.saveJob(updatedJob);
    await loadDatabase();
    showToast('success', `Timer started for ${job.jobNumber}. Job moved to Production.`);
  };

  // Quick Stop Job Handler
  const handleStopJob = async (job: Job) => {
    const nowIso = new Date().toISOString();
    const startIso = job.startTime || nowIso;
    const { formatted, minutes } = calculateDuration(startIso, nowIso);
    const updatedJob: Job = {
      ...job,
      productionStatus: 'Completed',
      endTime: nowIso,
      totalTimeFormatted: formatted,
      totalTimeMinutes: minutes,
    };
    await StorageService.saveJob(updatedJob);
    await loadDatabase();
    showToast('success', `${job.jobNumber} marked Completed! Machining time: ${formatted}`);
  };

  // Trigger New Job with optional pre-filled customer/item
  const handleOpenNewJob = (prefillCustomer?: Customer, prefillItem?: Item) => {
    setJobToEdit(
      prefillCustomer || prefillItem
        ? ({
            id: '',
            jobNumber: nextSerial.formatted,
            serialNumberIndex: nextSerial.serialIndex,
            date: new Date().toISOString().split('T')[0],
            customerId: prefillCustomer?.id || prefillItem?.customerId || '',
            customerName: prefillCustomer?.name || prefillItem?.customerName || '',
            itemId: prefillItem?.id || '',
            itemName: prefillItem?.name || '',
            description: prefillItem?.description || '',
            pathLength: prefillItem?.defaultPathLength || '',
            thickness: prefillItem?.defaultThickness || '',
            quantity: 1,
            remarks: '',
            productionStatus: 'Pending',
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString(),
          } as Job)
        : null
    );
    setActiveTab('new_job');
  };

  // Create Job with Transcribed Voice Description
  const handleVoiceApplyToNewJob = (transcribedDescription: string) => {
    setJobToEdit({
      id: '',
      jobNumber: nextSerial.formatted,
      serialNumberIndex: nextSerial.serialIndex,
      date: new Date().toISOString().split('T')[0],
      customerId: '',
      customerName: '',
      itemId: '',
      itemName: '',
      description: transcribedDescription,
      pathLength: '',
      thickness: '',
      quantity: 1,
      remarks: '',
      productionStatus: 'Pending',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    } as Job);
    setActiveTab('new_job');
    showToast('success', 'Voice description applied to new job card!');
  };

  // View Drawing in Lightbox
  const handleViewDrawing = (job: Job) => {
    if (job.drawing) {
      setActiveDrawing({
        drawing: job.drawing,
        title: `${job.jobNumber} - ${job.customerName} (${job.itemName})`,
      });
    }
  };

  // Loading Screen
  if (isLoading) {
    return (
      <div className="min-h-screen bg-white flex flex-col items-center justify-center text-slate-900 p-4">
        <div className="w-14 h-14 rounded-2xl bg-slate-950 text-amber-400 border border-slate-800 flex items-center justify-center shadow-md animate-pulse mb-4 font-black text-2xl">
          U
        </div>
        <h2 className="text-xl font-black tracking-wider text-slate-900">ULTINO TOOL TECH</h2>
        <p className="text-xs text-slate-500 mt-1 font-semibold">Loading Workshop Database...</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white text-slate-900 flex flex-col font-sans selection:bg-amber-500 selection:text-white">
      {/* Toast Notification Banner */}
      {toast && (
        <div className="fixed top-20 right-4 z-50 max-w-sm animate-in slide-in-from-top-4 duration-200">
          <div
            className={`flex items-center justify-between gap-3 p-3.5 rounded-xl border shadow-xl text-xs sm:text-sm font-semibold ${
              toast.type === 'success'
                ? 'bg-emerald-50 border-emerald-300 text-emerald-900'
                : 'bg-red-50 border-red-300 text-red-900'
            }`}
          >
            <div className="flex items-center gap-2">
              {toast.type === 'success' ? (
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              ) : (
                <AlertCircle className="w-4 h-4 text-red-600 shrink-0" />
              )}
              <span>{toast.message}</span>
            </div>
            <button
              onClick={() => setToast(null)}
              className="text-slate-400 hover:text-slate-700 p-1"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* Main Navbar & Mobile App Bar */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        productionCount={productionCount}
        onNewJobClick={() => handleOpenNewJob()}
      />

      {/* Main Screen Content */}
      <main className="flex-1 w-full bg-white">
        {activeTab === 'dashboard' && (
          <Dashboard
            jobs={jobs}
            customers={customers}
            items={items}
            setActiveTab={setActiveTab}
            onNewJobClick={() => handleOpenNewJob()}
            onViewJob={(j) => setJobToView(j)}
            onEditJob={(j) => {
              setJobToEdit(j);
              setActiveTab('new_job');
            }}
            onStatusChange={handleStatusChange}
            onViewDrawing={handleViewDrawing}
          />
        )}

        {activeTab === 'new_job' && (
          <JobCardForm
            jobToEdit={jobToEdit}
            customers={customers}
            items={items}
            nextSerialNumberFormatted={nextSerial.formatted}
            nextSerialNumberIndex={nextSerial.serialIndex}
            onSaveJob={handleSaveJob}
            onCancel={() => {
              setJobToEdit(null);
              setActiveTab('dashboard');
            }}
            onSaveCustomer={handleSaveCustomer}
            onSaveItem={handleSaveItem}
          />
        )}

        {activeTab === 'production' && (
          <ProductionScreen
            jobs={jobs}
            onNewJobClick={() => handleOpenNewJob()}
            onEditJob={(j) => {
              setJobToEdit(j);
              setActiveTab('new_job');
            }}
            onViewJob={(j) => setJobToView(j)}
            onViewDrawing={handleViewDrawing}
            onStartJob={handleStartJob}
            onStopJob={handleStopJob}
            onStatusChange={handleStatusChange}
          />
        )}

        {activeTab === 'job_history' && (
          <JobHistory
            jobs={jobs}
            customers={customers}
            items={items}
            onNewJobClick={() => handleOpenNewJob()}
            onEditJob={(j) => {
              setJobToEdit(j);
              setActiveTab('new_job');
            }}
            onViewJob={(j) => setJobToView(j)}
            onDeleteJob={handleDeleteJob}
            onStatusChange={handleStatusChange}
            onViewDrawing={handleViewDrawing}
            onPrintJob={(j) => setJobToPrint(j)}
          />
        )}

        {activeTab === 'customers' && (
          <CustomerMaster
            customers={customers}
            items={items}
            jobs={jobs}
            onSaveCustomer={handleSaveCustomer}
            onDeleteCustomer={handleDeleteCustomer}
            onSelectCustomerForNewJob={(cust) => handleOpenNewJob(cust)}
          />
        )}

        {activeTab === 'items' && (
          <ItemMaster
            items={items}
            customers={customers}
            jobs={jobs}
            onSaveItem={handleSaveItem}
            onDeleteItem={handleDeleteItem}
            onSaveCustomer={handleSaveCustomer}
            onSelectCustomerForNewJob={(cust, item) => handleOpenNewJob(cust, item)}
          />
        )}

        {activeTab === 'monthly_ledger' && (
          <MonthlyLedger
            jobs={jobs}
            customers={customers}
            onViewJob={(j) => setJobToView(j)}
            onViewDrawing={handleViewDrawing}
          />
        )}

        {activeTab === 'backup' && (
          <BackupSettings
            customers={customers}
            items={items}
            jobs={jobs}
            onRefreshData={loadDatabase}
          />
        )}
      </main>

      {/* Complete Job Card View Modal */}
      {jobToView && (
        <JobViewModal
          job={jobToView}
          onClose={() => setJobToView(null)}
          onEdit={(j) => {
            setJobToView(null);
            setJobToEdit(j);
            setActiveTab('new_job');
          }}
          onPrint={(j) => {
            setJobToView(null);
            setJobToPrint(j);
          }}
          onViewDrawing={handleViewDrawing}
        />
      )}

      {/* Full-screen Technical Drawing Modal */}
      {activeDrawing && (
        <DrawingViewerModal
          drawing={activeDrawing.drawing}
          title={activeDrawing.title}
          onClose={() => setActiveDrawing(null)}
        />
      )}

      {/* Printable Work Order Travel Tag */}
      {jobToPrint && (
        <JobPrintView
          job={jobToPrint}
          onClose={() => setJobToPrint(null)}
        />
      )}

      {/* Floating Voice Controller Trigger Button */}
      <button
        type="button"
        onClick={() => setIsVoiceModalOpen(true)}
        className="fixed bottom-6 right-6 z-40 bg-slate-950 hover:bg-slate-900 text-white p-3.5 sm:px-4 sm:py-3 rounded-full shadow-2xl border-2 border-amber-500/80 flex items-center gap-2.5 group hover:scale-105 active:scale-95 transition-all cursor-pointer"
        title="Open Voice Controller (Audio to Words)"
      >
        <div className="w-6 h-6 rounded-full bg-amber-500 text-slate-950 flex items-center justify-center font-bold">
          <Mic className="w-3.5 h-3.5 group-hover:animate-pulse" />
        </div>
        <span className="hidden sm:inline-block text-xs font-black tracking-wide uppercase text-amber-400">
          Voice Controller
        </span>
      </button>

      {/* Floating Voice Controller Modal */}
      <FloatingVoiceModal
        isOpen={isVoiceModalOpen}
        onClose={() => setIsVoiceModalOpen(false)}
        onApplyToNewJob={handleVoiceApplyToNewJob}
      />
    </div>
  );
}
